/**
 * server.js
 * ────────────────────────────────────────────────────────────────
 * Application entry point.
 *
 * Responsibilities:
 *   1. Load + validate env config (fails fast if misconfigured)
 *   2. Verify database connectivity before accepting traffic
 *   3. Start the HTTP server
 *   4. Handle graceful shutdown (SIGTERM/SIGINT) and crash safety
 *      (uncaughtException / unhandledRejection)
 *
 * Run with: `npm start` (production) or `npm run dev` (nodemon).
 * ────────────────────────────────────────────────────────────────
 */

const config = require('./src/config/env.config');
const logger = require('./src/utils/logger');
const app = require('./src/app');
const { checkDatabaseConnection, disconnectDatabase } = require('./src/database/prisma.client');

let server;

async function startServer() {
  const dbConnected = await checkDatabaseConnection();

  if (!dbConnected) {
    logger.error('❌ Could not connect to the database. Check DATABASE_URL in .env.');
    process.exit(1);
  }

  logger.info('✅ Database connection established.');

  server = app.listen(config.port, () => {
    logger.info(`🚀 DEMS backend listening on port ${config.port} [${config.env}]`);
    logger.info(`   API base: http://localhost:${config.port}${config.apiPrefix}`);
    logger.info(`   Health:   http://localhost:${config.port}${config.apiPrefix}/health`);
  });
}

async function shutdown(signal) {
  logger.info(`${signal} received. Shutting down gracefully...`);

  if (server) {
    server.close(async () => {
      logger.info('HTTP server closed.');
      await disconnectDatabase();
      logger.info('Database connections closed. Goodbye.');
      process.exit(0);
    });

    // Force-exit if connections don't close in time.
    setTimeout(() => {
      logger.error('Forced shutdown after timeout.');
      process.exit(1);
    }, 10_000).unref();
  } else {
    process.exit(0);
  }
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

process.on('unhandledRejection', (reason) => {
  logger.error(`Unhandled Promise Rejection: ${reason instanceof Error ? reason.stack : reason}`);
  // Let the process keep running for operational errors elsewhere in
  // the app, but a rejection that escapes all the way here is almost
  // always a bug worth crashing loudly for in production.
  if (config.isProduction) shutdown('unhandledRejection');
});

process.on('uncaughtException', (err) => {
  logger.error(`Uncaught Exception: ${err.stack}`);
  shutdown('uncaughtException');
});

startServer();
