/**
 * tests/unit/constants/roles.test.js
 * Unit tests for src/constants/roles.js
 */

'use strict';

const { ROLES, ROLE_HIERARCHY, hasMinimumRole } = require('../../../src/constants/roles');

describe('roles constants', () => {
  describe('ROLES', () => {
    it('defines the four expected roles', () => {
      expect(ROLES.ADMIN).toBe('ADMIN');
      expect(ROLES.MANAGER).toBe('MANAGER');
      expect(ROLES.CASHIER).toBe('CASHIER');
      expect(ROLES.AUDITOR).toBe('AUDITOR');
    });

    it('is frozen (immutable)', () => {
      expect(Object.isFrozen(ROLES)).toBe(true);
    });
  });

  describe('ROLE_HIERARCHY', () => {
    it('lists ADMIN first', () => {
      expect(ROLE_HIERARCHY[0]).toBe(ROLES.ADMIN);
    });

    it('lists AUDITOR last', () => {
      expect(ROLE_HIERARCHY[ROLE_HIERARCHY.length - 1]).toBe(ROLES.AUDITOR);
    });

    it('is frozen', () => {
      expect(Object.isFrozen(ROLE_HIERARCHY)).toBe(true);
    });

    it('contains exactly 4 entries', () => {
      expect(ROLE_HIERARCHY).toHaveLength(4);
    });
  });

  describe('hasMinimumRole()', () => {
    // ADMIN is the most privileged
    it('ADMIN satisfies ADMIN requirement', () => {
      expect(hasMinimumRole(ROLES.ADMIN, ROLES.ADMIN)).toBe(true);
    });

    it('ADMIN satisfies MANAGER requirement', () => {
      expect(hasMinimumRole(ROLES.ADMIN, ROLES.MANAGER)).toBe(true);
    });

    it('ADMIN satisfies CASHIER requirement', () => {
      expect(hasMinimumRole(ROLES.ADMIN, ROLES.CASHIER)).toBe(true);
    });

    it('ADMIN satisfies AUDITOR requirement', () => {
      expect(hasMinimumRole(ROLES.ADMIN, ROLES.AUDITOR)).toBe(true);
    });

    it('MANAGER does NOT satisfy ADMIN requirement', () => {
      expect(hasMinimumRole(ROLES.MANAGER, ROLES.ADMIN)).toBe(false);
    });

    it('MANAGER satisfies MANAGER requirement', () => {
      expect(hasMinimumRole(ROLES.MANAGER, ROLES.MANAGER)).toBe(true);
    });

    it('CASHIER does NOT satisfy ADMIN requirement', () => {
      expect(hasMinimumRole(ROLES.CASHIER, ROLES.ADMIN)).toBe(false);
    });

    it('CASHIER does NOT satisfy MANAGER requirement', () => {
      expect(hasMinimumRole(ROLES.CASHIER, ROLES.MANAGER)).toBe(false);
    });

    it('CASHIER satisfies CASHIER requirement', () => {
      expect(hasMinimumRole(ROLES.CASHIER, ROLES.CASHIER)).toBe(true);
    });

    it('AUDITOR only satisfies AUDITOR requirement', () => {
      expect(hasMinimumRole(ROLES.AUDITOR, ROLES.AUDITOR)).toBe(true);
      expect(hasMinimumRole(ROLES.AUDITOR, ROLES.CASHIER)).toBe(false);
      expect(hasMinimumRole(ROLES.AUDITOR, ROLES.MANAGER)).toBe(false);
      expect(hasMinimumRole(ROLES.AUDITOR, ROLES.ADMIN)).toBe(false);
    });
  });
});
