/**
 * tests/unit/utils/ApiResponse.test.js
 * Unit tests for src/utils/ApiResponse.js
 */

'use strict';

const ApiResponse = require('../../../src/utils/ApiResponse');

/** Minimal Express-like res mock */
function makeRes() {
  const res = {
    _status: null,
    _body: null,
    status(code) {
      this._status = code;
      return this;
    },
    json(body) {
      this._body = body;
      return this;
    },
  };
  return res;
}

describe('ApiResponse', () => {
  describe('constructor', () => {
    it('sets statusCode, message, and data', () => {
      const r = new ApiResponse(200, 'OK', { id: 1 });
      expect(r.statusCode).toBe(200);
      expect(r.message).toBe('OK');
      expect(r.data).toEqual({ id: 1 });
    });

    it('success is true for 2xx codes', () => {
      expect(new ApiResponse(200, 'OK').success).toBe(true);
      expect(new ApiResponse(201, 'Created').success).toBe(true);
      expect(new ApiResponse(204, 'No content').success).toBe(true);
    });

    it('success is false for 4xx/5xx codes', () => {
      expect(new ApiResponse(400, 'Bad').success).toBe(false);
      expect(new ApiResponse(500, 'Error').success).toBe(false);
    });

    it('defaults data to null', () => {
      expect(new ApiResponse(200, 'OK').data).toBeNull();
    });

    it('defaults meta to null', () => {
      expect(new ApiResponse(200, 'OK').meta).toBeNull();
    });

    it('accepts a meta argument', () => {
      const meta = { page: 1, totalItems: 5 };
      const r = new ApiResponse(200, 'OK', [], meta);
      expect(r.meta).toEqual(meta);
    });
  });

  describe('send()', () => {
    it('calls res.status() with the status code', () => {
      const res = makeRes();
      new ApiResponse(201, 'Created', { id: 42 }).send(res);
      expect(res._status).toBe(201);
    });

    it('includes success, message, and data in the body', () => {
      const res = makeRes();
      new ApiResponse(200, 'OK', { x: 1 }).send(res);
      expect(res._body).toMatchObject({
        success: true,
        message: 'OK',
        data: { x: 1 },
      });
    });

    it('omits meta from body when meta is null', () => {
      const res = makeRes();
      new ApiResponse(200, 'OK', null, null).send(res);
      expect(res._body).not.toHaveProperty('meta');
    });

    it('includes meta in body when provided', () => {
      const res = makeRes();
      const meta = { page: 2, totalPages: 10 };
      new ApiResponse(200, 'OK', [], meta).send(res);
      expect(res._body.meta).toEqual(meta);
    });

    it('returns the result of res.json()', () => {
      const res = makeRes();
      const result = new ApiResponse(200, 'OK').send(res);
      // res.json returns `this` in the mock
      expect(result).toBe(res);
    });
  });
});
