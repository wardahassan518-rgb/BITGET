/**
 * tests/unit/utils/jwt.util.test.js
 * Unit tests for src/utils/jwt.util.js
 */

'use strict';

const {
  signAccessToken,
  signRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
} = require('../../../src/utils/jwt.util');

describe('jwt.util', () => {
  const payload = { sub: 'user-uuid-1234', role: 'ADMIN' };

  describe('signAccessToken / verifyAccessToken', () => {
    it('creates a string token', () => {
      const token = signAccessToken(payload);
      expect(typeof token).toBe('string');
      expect(token.split('.')).toHaveLength(3); // header.payload.sig
    });

    it('round-trips: sign then verify returns the original payload', () => {
      const token = signAccessToken(payload);
      const decoded = verifyAccessToken(token);
      expect(decoded.sub).toBe(payload.sub);
      expect(decoded.role).toBe(payload.role);
    });

    it('adds standard JWT claims (iss, aud, iat, exp)', () => {
      const token = signAccessToken(payload);
      const decoded = verifyAccessToken(token);
      expect(decoded.iss).toBeDefined();
      expect(decoded.aud).toBeDefined();
      expect(decoded.iat).toBeDefined();
      expect(decoded.exp).toBeDefined();
    });

    it('throws on a tampered token', () => {
      const token = signAccessToken(payload);
      const tampered = token.slice(0, -5) + 'XXXXX';
      expect(() => verifyAccessToken(tampered)).toThrow();
    });

    it('throws on an expired token', async () => {
      // Sign with a 1-second expiry, wait 1100ms, then verify
      const jwt = require('jsonwebtoken');
      const config = require('../../../src/config/jwt.config');
      const shortToken = jwt.sign(payload, config.accessToken.secret, {
        expiresIn: '1ms',
        issuer: config.issuer,
        audience: config.audience,
      });
      await new Promise((r) => setTimeout(r, 50));
      expect(() => verifyAccessToken(shortToken)).toThrow('jwt expired');
    });

    it('throws when an access token is passed to verifyRefreshToken', () => {
      const token = signAccessToken(payload);
      // The refresh secret is different, so this must fail
      expect(() => verifyRefreshToken(token)).toThrow();
    });
  });

  describe('signRefreshToken / verifyRefreshToken', () => {
    it('creates a string token', () => {
      const token = signRefreshToken(payload);
      expect(typeof token).toBe('string');
    });

    it('round-trips correctly', () => {
      const token = signRefreshToken(payload);
      const decoded = verifyRefreshToken(token);
      expect(decoded.sub).toBe(payload.sub);
    });

    it('throws when a refresh token is passed to verifyAccessToken', () => {
      const token = signRefreshToken(payload);
      expect(() => verifyAccessToken(token)).toThrow();
    });
  });
});
