/**
 * tests/unit/utils/hash.util.test.js
 * Unit tests for src/utils/hash.util.js
 */

'use strict';

const { sha256, sha256Buffer, randomHex } = require('../../../src/utils/hash.util');

describe('hash.util', () => {
  describe('sha256()', () => {
    it('returns a 64-character hex string', () => {
      const result = sha256('hello');
      expect(typeof result).toBe('string');
      expect(result).toHaveLength(64);
      expect(result).toMatch(/^[0-9a-f]{64}$/);
    });

    it('is deterministic for the same input', () => {
      expect(sha256('dems')).toBe(sha256('dems'));
    });

    it('produces different hashes for different inputs', () => {
      expect(sha256('abc')).not.toBe(sha256('xyz'));
    });

    it('matches the known SHA-256 of "hello"', () => {
      // Known value: echo -n "hello" | sha256sum
      expect(sha256('hello')).toBe(
        '2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824',
      );
    });

    it('handles an empty string', () => {
      // SHA-256 of "" is well-known
      expect(sha256('')).toBe(
        'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      );
    });

    it('handles unicode input without throwing', () => {
      expect(() => sha256('αβγδ — DEMS')).not.toThrow();
      expect(sha256('αβγδ')).toHaveLength(64);
    });
  });

  describe('sha256Buffer()', () => {
    it('hashes a Buffer and returns 64-char hex', () => {
      const buf = Buffer.from('hello', 'utf8');
      const result = sha256Buffer(buf);
      expect(result).toHaveLength(64);
      expect(result).toMatch(/^[0-9a-f]{64}$/);
    });

    it('produces the same digest as sha256() for the same bytes', () => {
      const input = 'consistent';
      expect(sha256Buffer(Buffer.from(input, 'utf8'))).toBe(sha256(input));
    });

    it('handles an empty buffer', () => {
      expect(sha256Buffer(Buffer.alloc(0))).toHaveLength(64);
    });
  });

  describe('randomHex()', () => {
    it('returns a hex string of double the requested byte length', () => {
      expect(randomHex(16)).toHaveLength(32);
      expect(randomHex(32)).toHaveLength(64);
    });

    it('defaults to 64-char hex (32 bytes)', () => {
      expect(randomHex()).toHaveLength(64);
    });

    it('returns different values on successive calls', () => {
      expect(randomHex()).not.toBe(randomHex());
    });

    it('output contains only hex characters', () => {
      expect(randomHex(8)).toMatch(/^[0-9a-f]+$/);
    });
  });
});
