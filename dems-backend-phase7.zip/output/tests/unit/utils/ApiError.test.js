/**
 * tests/unit/utils/ApiError.test.js
 * Unit tests for src/utils/ApiError.js
 */

'use strict';

const ApiError = require('../../../src/utils/ApiError');

describe('ApiError', () => {
  it('extends Error', () => {
    const err = new ApiError(400, 'Bad request');
    expect(err).toBeInstanceOf(Error);
    expect(err).toBeInstanceOf(ApiError);
  });

  it('sets statusCode, message, and name', () => {
    const err = new ApiError(404, 'Not found');
    expect(err.statusCode).toBe(404);
    expect(err.message).toBe('Not found');
    expect(err.name).toBe('ApiError');
  });

  it('defaults isOperational to true', () => {
    const err = new ApiError(500, 'Crash');
    expect(err.isOperational).toBe(true);
  });

  it('allows overriding isOperational', () => {
    const err = new ApiError(500, 'Crash', { isOperational: false });
    expect(err.isOperational).toBe(false);
  });

  it('defaults details to null', () => {
    const err = new ApiError(400, 'Validation failed');
    expect(err.details).toBeNull();
  });

  it('accepts details in options', () => {
    const details = { field: 'email', issue: 'required' };
    const err = new ApiError(422, 'Unprocessable', { details });
    expect(err.details).toEqual(details);
  });

  it('captures a stack trace', () => {
    const err = new ApiError(500, 'Server error');
    expect(err.stack).toBeDefined();
    expect(typeof err.stack).toBe('string');
  });

  it('works for 2xx status codes (unusual but valid)', () => {
    const err = new ApiError(200, 'Unusual');
    expect(err.statusCode).toBe(200);
  });

  it('stores the message on the Error prototype chain', () => {
    const err = new ApiError(403, 'Forbidden');
    expect(err.message).toBe('Forbidden');
  });
});
