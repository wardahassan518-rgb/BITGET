/**
 * tests/unit/utils/pagination.util.test.js
 * Unit tests for src/utils/pagination.util.js
 */

'use strict';

const { getPagination, buildMeta } = require('../../../src/utils/pagination.util');

describe('pagination.util', () => {
  describe('getPagination()', () => {
    it('returns default page=1, limit=20 for empty query', () => {
      const result = getPagination({});
      expect(result.page).toBe(1);
      expect(result.limit).toBe(20);
    });

    it('calculates skip correctly for page 1', () => {
      const { skip } = getPagination({ page: 1, limit: 20 });
      expect(skip).toBe(0);
    });

    it('calculates skip correctly for page 2', () => {
      const { skip } = getPagination({ page: 2, limit: 20 });
      expect(skip).toBe(20);
    });

    it('calculates skip correctly for page 3 with limit 10', () => {
      const { skip, take } = getPagination({ page: 3, limit: 10 });
      expect(skip).toBe(20);
      expect(take).toBe(10);
    });

    it('coerces string query params to numbers', () => {
      const { page, limit } = getPagination({ page: '3', limit: '15' });
      expect(page).toBe(3);
      expect(limit).toBe(15);
    });

    it('enforces minimum page of 1 for invalid values', () => {
      expect(getPagination({ page: 0 }).page).toBe(1);
      expect(getPagination({ page: -5 }).page).toBe(1);
      expect(getPagination({ page: 'abc' }).page).toBe(1);
    });

    it('enforces minimum limit of 1 for negative values', () => {
      // limit=0 falls back to DEFAULT (20) via the `|| DEFAULT_LIMIT` check
      // limit=-1 → parseInt gives -1 → Math.max(-1, 1) = 1
      expect(getPagination({ limit: -1 }).limit).toBe(1);
    });

    it('caps limit at MAX_LIMIT (100)', () => {
      expect(getPagination({ limit: 200 }).limit).toBe(100);
      expect(getPagination({ limit: 999 }).limit).toBe(100);
    });

    it('handles undefined query gracefully', () => {
      const result = getPagination();
      expect(result.page).toBe(1);
      expect(result.limit).toBe(20);
    });

    it('returns take equal to limit', () => {
      const { limit, take } = getPagination({ page: 1, limit: 50 });
      expect(take).toBe(limit);
    });
  });

  describe('buildMeta()', () => {
    it('returns correct structure', () => {
      const meta = buildMeta(1, 20, 100);
      expect(meta).toMatchObject({
        page: 1,
        limit: 20,
        totalItems: 100,
        totalPages: 5,
      });
    });

    it('rounds up totalPages', () => {
      expect(buildMeta(1, 20, 21).totalPages).toBe(2);
      expect(buildMeta(1, 3, 10).totalPages).toBe(4);
    });

    it('totalPages is at least 1 when totalItems is 0', () => {
      expect(buildMeta(1, 20, 0).totalPages).toBe(1);
    });

    it('totalPages is 1 when all items fit in one page', () => {
      expect(buildMeta(1, 20, 5).totalPages).toBe(1);
      expect(buildMeta(1, 20, 20).totalPages).toBe(1);
    });
  });
});
