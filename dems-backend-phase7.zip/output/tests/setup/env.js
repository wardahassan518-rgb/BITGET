/**
 * tests/setup/env.js
 * ────────────────────────────────────────────────────────────────
 * Jest `setupFiles` entry — runs in each test worker process BEFORE
 * any test file's `require()` calls are evaluated.
 *
 * This is deliberately the ONLY thing in setupFiles:  loading the
 * .env.test file so that `src/config/env.config.js` (which parses
 * process.env with Zod and calls process.exit(1) on failure) sees
 * valid values when the test app is first required.
 *
 * Do NOT add framework-level setup here (beforeAll, jest.mock, etc.)
 * — those belong in individual test files or in `setupFilesAfterFramework`.
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../../.env.test') });
