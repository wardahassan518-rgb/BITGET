/**
 * tests/integration/health.test.js
 * ────────────────────────────────────────────────────────────────
 * Integration tests for the health endpoints:
 *   GET /api/v1/health      — liveness probe
 *   GET /api/v1/health/db   — readiness probe
 *
 * Prisma is mocked so no real database is needed.
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const request = require('supertest');

// ── Mock Prisma BEFORE the app is required ─────────────────────
const { makeModule } = require('../helpers/mockPrisma');
const prismaModule = makeModule();

jest.mock('../../src/database/prisma.client', () => prismaModule);

// ── Now it's safe to load the app ──────────────────────────────
const app = require('../../src/app');

const BASE = '/api/v1/health';

describe('Health endpoints', () => {
  beforeEach(() => {
    // Default: DB is healthy
    prismaModule.checkDatabaseConnection.mockResolvedValue(true);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  // ── GET /health ──────────────────────────────────────────────

  describe('GET /api/v1/health (liveness)', () => {
    it('returns 200 with status=ok', async () => {
      const res = await request(app).get(BASE);
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.status).toBe('ok');
    });

    it('includes uptimeSeconds (non-negative number)', async () => {
      const res = await request(app).get(BASE);
      expect(typeof res.body.data.uptimeSeconds).toBe('number');
      expect(res.body.data.uptimeSeconds).toBeGreaterThanOrEqual(0);
    });

    it('includes a valid ISO timestamp', async () => {
      const res = await request(app).get(BASE);
      expect(() => new Date(res.body.data.timestamp)).not.toThrow();
    });

    it('responds with JSON content-type', async () => {
      const res = await request(app).get(BASE);
      expect(res.headers['content-type']).toMatch(/application\/json/);
    });
  });

  // ── GET /health/db ───────────────────────────────────────────

  describe('GET /api/v1/health/db (readiness)', () => {
    it('returns 200 when database is connected', async () => {
      prismaModule.checkDatabaseConnection.mockResolvedValue(true);
      const res = await request(app).get(`${BASE}/db`);
      expect(res.status).toBe(200);
      expect(res.body.data.database).toBe('connected');
      expect(res.body.data.status).toBe('ok');
    });

    it('returns 503 when database is unreachable', async () => {
      prismaModule.checkDatabaseConnection.mockResolvedValue(false);
      const res = await request(app).get(`${BASE}/db`);
      expect(res.status).toBe(503);
      expect(res.body.data.database).toBe('disconnected');
      expect(res.body.data.status).toBe('down');
    });

    it('calls checkDatabaseConnection exactly once', async () => {
      await request(app).get(`${BASE}/db`);
      expect(prismaModule.checkDatabaseConnection).toHaveBeenCalledTimes(1);
    });

    it('includes a timestamp in the response', async () => {
      const res = await request(app).get(`${BASE}/db`);
      expect(res.body.data.timestamp).toBeDefined();
    });
  });

  // ── Root ─────────────────────────────────────────────────────

  describe('GET / (root info endpoint)', () => {
    it('returns 200 with JSON info', async () => {
      const res = await request(app).get('/');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.apiPrefix).toBe('/api/v1');
    });
  });

  // ── 404 ──────────────────────────────────────────────────────

  describe('404 handler', () => {
    it('returns 404 for unknown routes', async () => {
      const res = await request(app).get('/api/v1/nonexistent-route');
      expect(res.status).toBe(404);
      expect(res.body.success).toBe(false);
    });
  });
});
