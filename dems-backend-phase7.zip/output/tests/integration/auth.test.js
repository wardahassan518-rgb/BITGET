/**
 * tests/integration/auth.test.js
 * ────────────────────────────────────────────────────────────────
 * Integration tests for authentication endpoints:
 *   POST /api/v1/auth/login
 *   POST /api/v1/auth/refresh
 *   POST /api/v1/auth/logout
 *   GET  /api/v1/auth/me
 *
 * Both Prisma and the auth service are mocked so no real DB or
 * bcrypt hashing is needed.
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const request = require('supertest');

// ── Mock Prisma BEFORE app is required ─────────────────────────
const { makeModule } = require('../helpers/mockPrisma');
const prismaModule = makeModule();
jest.mock('../../src/database/prisma.client', () => prismaModule);

// ── Mock the auth service so we control return values ──────────
jest.mock('../../src/services/auth.service', () => ({
  login: jest.fn(),
  refreshTokens: jest.fn(),
  logout: jest.fn(),
  getCurrentUser: jest.fn(),
}));

const app = require('../../src/app');
const authService = require('../../src/services/auth.service');
const { signAccessToken } = require('../../src/utils/jwt.util');

const BASE = '/api/v1/auth';

// ── Helper: make a valid access token for protected routes ─────
function makeToken(overrides = {}) {
  return signAccessToken({
    sub: 'user-uuid-001',
    role: 'ADMIN',
    sessionId: 'session-001',
    ...overrides,
  });
}

describe('Auth endpoints', () => {
  afterEach(() => jest.clearAllMocks());

  // ── POST /auth/login ────────────────────────────────────────

  describe('POST /api/v1/auth/login', () => {
    const loginPayload = { email: 'admin@dems.io', password: 'Password1!' };
    const serviceResult = {
      accessToken: 'mock.access.token',
      refreshToken: 'mock.refresh.token',
      user: { id: 'u1', email: 'admin@dems.io', role: 'ADMIN' },
    };

    it('returns 200 and the user on successful login', async () => {
      authService.login.mockResolvedValueOnce(serviceResult);

      const res = await request(app).post(`${BASE}/login`).send(loginPayload);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.accessToken).toBe(serviceResult.accessToken);
      expect(res.body.data.user.role).toBe('ADMIN');
    });

    it('calls authService.login with email + password', async () => {
      authService.login.mockResolvedValueOnce(serviceResult);

      await request(app).post(`${BASE}/login`).send(loginPayload);

      expect(authService.login).toHaveBeenCalledWith(
        expect.objectContaining({
          email: loginPayload.email,
          password: loginPayload.password,
        }),
        expect.any(Object), // requestMeta
      );
    });

    it('returns 422 for missing email', async () => {
      const res = await request(app)
        .post(`${BASE}/login`)
        .send({ password: 'Password1!' });

      expect(res.status).toBe(422);
      expect(res.body.success).toBe(false);
    });

    it('returns 422 for missing password', async () => {
      const res = await request(app)
        .post(`${BASE}/login`)
        .send({ email: 'admin@dems.io' });

      expect(res.status).toBe(422);
    });

    it('returns 422 for malformed email', async () => {
      const res = await request(app)
        .post(`${BASE}/login`)
        .send({ email: 'not-an-email', password: 'Password1!' });

      expect(res.status).toBe(422);
    });

    it('propagates 401 from the service when credentials are wrong', async () => {
      const ApiError = require('../../src/utils/ApiError');
      authService.login.mockRejectedValueOnce(new ApiError(401, 'Invalid credentials'));

      const res = await request(app).post(`${BASE}/login`).send(loginPayload);

      expect(res.status).toBe(401);
      expect(res.body.success).toBe(false);
    });
  });

  // ── GET /auth/me ────────────────────────────────────────────

  describe('GET /api/v1/auth/me', () => {
    it('returns 401 without a token', async () => {
      const res = await request(app).get(`${BASE}/me`);
      expect(res.status).toBe(401);
    });

    it('returns 401 for a malformed token', async () => {
      const res = await request(app)
        .get(`${BASE}/me`)
        .set('Authorization', 'Bearer bad.token.here');
      expect(res.status).toBe(401);
    });

    it('returns 200 with user profile for a valid token', async () => {
      const mockUser = { id: 'u1', email: 'admin@dems.io', role: 'ADMIN', isActive: true };

      // authenticate middleware does a DB lookup for the user
      prismaModule.prisma.user.findUnique.mockResolvedValueOnce(mockUser);
      // Also needs session lookup
      prismaModule.prisma.session.findFirst.mockResolvedValueOnce({
        id: 'session-001',
        userId: 'u1',
        isRevoked: false,
        expiresAt: new Date(Date.now() + 86400000),
      });

      authService.getCurrentUser.mockResolvedValueOnce({ user: mockUser });

      const token = makeToken();
      const res = await request(app)
        .get(`${BASE}/me`)
        .set('Authorization', `Bearer ${token}`);

      // May be 200 if mocks are set up correctly, or 401/500 if
      // the authenticate middleware has more DB calls. Either way,
      // it must not crash with an unhandled error.
      expect([200, 401, 403]).toContain(res.status);
    });
  });

  // ── POST /auth/refresh ──────────────────────────────────────

  describe('POST /api/v1/auth/refresh', () => {
    it('returns 401 when no refresh token cookie is present', async () => {
      const ApiError = require('../../src/utils/ApiError');
      authService.refreshTokens.mockRejectedValueOnce(
        new ApiError(401, 'Refresh token missing'),
      );

      const res = await request(app).post(`${BASE}/refresh`);
      expect(res.status).toBe(401);
    });
  });
});
