/**
 * tests/api/transactions.api.test.js
 * ────────────────────────────────────────────────────────────────
 * API contract tests for transaction endpoints.
 * Verifies HTTP status codes, response shapes, and auth guards
 * without a real database.
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const request = require('supertest');

// ── Mock Prisma BEFORE app is required ─────────────────────────
const { makeModule } = require('../helpers/mockPrisma');
const prismaModule = makeModule();
jest.mock('../../src/database/prisma.client', () => prismaModule);

// ── Mock service to isolate HTTP/middleware layer ───────────────
jest.mock('../../src/services/transaction.service', () => ({
  listTransactions: jest.fn(),
  getTransaction: jest.fn(),
  createTransaction: jest.fn(),
  updateTransaction: jest.fn(),
  deleteTransaction: jest.fn(),
}));

const app = require('../../src/app');
const txnService = require('../../src/services/transaction.service');
const { signAccessToken } = require('../../src/utils/jwt.util');

const BASE = '/api/v1/transactions';

// ── Shared fixtures ───────────────────────────────────────────
const mockUser = {
  id: 'user-001',
  email: 'manager@dems.io',
  role: 'MANAGER',
  isActive: true,
  name: 'Test Manager',
};

const mockSession = {
  id: 'session-001',
  userId: 'user-001',
  isRevoked: false,
  expiresAt: new Date(Date.now() + 86400000),
};

const mockTxn = {
  id: 'txn-001',
  amount: 500,
  type: 'DEPOSIT',
  status: 'COMPLETED',
  clientId: 'client-001',
  createdById: 'user-001',
  createdAt: new Date().toISOString(),
};

function makeToken(role = 'MANAGER') {
  return signAccessToken({ sub: 'user-001', role, sessionId: 'session-001' });
}

function authHeader(role = 'MANAGER') {
  return { Authorization: `Bearer ${makeToken(role)}` };
}

// ── Set up authenticate middleware DB mocks ───────────────────
function setupAuthMocks() {
  prismaModule.prisma.user.findUnique.mockResolvedValue(mockUser);
  prismaModule.prisma.session.findFirst.mockResolvedValue(mockSession);
}

describe('Transactions API', () => {
  beforeEach(() => {
    setupAuthMocks();
  });

  afterEach(() => jest.clearAllMocks());

  // ── Auth guard ───────────────────────────────────────────────

  describe('Auth guard', () => {
    it('returns 401 for unauthenticated requests', async () => {
      const res = await request(app).get(BASE);
      expect(res.status).toBe(401);
    });

    it('returns 401 for malformed token', async () => {
      const res = await request(app)
        .get(BASE)
        .set('Authorization', 'Bearer garbage');
      expect(res.status).toBe(401);
    });
  });

  // ── GET /transactions ────────────────────────────────────────

  describe('GET /api/v1/transactions', () => {
    it('returns 200 with paginated list', async () => {
      txnService.listTransactions.mockResolvedValueOnce({
        data: [mockTxn],
        meta: { page: 1, limit: 20, totalItems: 1, totalPages: 1 },
      });

      const res = await request(app)
        .get(BASE)
        .set(authHeader());

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
    });

    it('accepts pagination query params without error', async () => {
      txnService.listTransactions.mockResolvedValueOnce({
        data: [],
        meta: { page: 2, limit: 10, totalItems: 0, totalPages: 1 },
      });

      const res = await request(app)
        .get(`${BASE}?page=2&limit=10`)
        .set(authHeader());

      expect([200, 400]).toContain(res.status);
    });
  });

  // ── GET /transactions/:id ────────────────────────────────────

  describe('GET /api/v1/transactions/:id', () => {
    it('returns 200 with transaction data', async () => {
      txnService.getTransaction.mockResolvedValueOnce(mockTxn);

      const res = await request(app)
        .get(`${BASE}/txn-001`)
        .set(authHeader());

      expect(res.status).toBe(200);
    });

    it('propagates 404 from service', async () => {
      const ApiError = require('../../src/utils/ApiError');
      txnService.getTransaction.mockRejectedValueOnce(
        new ApiError(404, 'Transaction not found'),
      );

      const res = await request(app)
        .get(`${BASE}/nonexistent-id`)
        .set(authHeader());

      expect(res.status).toBe(404);
      expect(res.body.success).toBe(false);
    });
  });

  // ── POST /transactions ───────────────────────────────────────

  describe('POST /api/v1/transactions', () => {
    const body = {
      clientId: 'client-001',
      amount: 1000,
      type: 'DEPOSIT',
      currency: 'USD',
      exchangeRate: 1,
      convertedAmount: 1000,
      notes: 'Test deposit',
    };

    it('returns 401 for unauthenticated request', async () => {
      const res = await request(app).post(BASE).send(body);
      expect(res.status).toBe(401);
    });

    it('returns 403 for AUDITOR role (read-only)', async () => {
      prismaModule.prisma.user.findUnique.mockResolvedValue({
        ...mockUser,
        role: 'AUDITOR',
      });
      prismaModule.prisma.session.findFirst.mockResolvedValue(mockSession);

      const res = await request(app)
        .post(BASE)
        .set(authHeader('AUDITOR'))
        .send(body);

      expect(res.status).toBe(403);
    });

    it('returns 201 on successful creation', async () => {
      txnService.createTransaction.mockResolvedValueOnce(mockTxn);

      const res = await request(app)
        .post(BASE)
        .set(authHeader('MANAGER'))
        .send(body);

      // 200 or 201 depending on implementation
      expect([200, 201]).toContain(res.status);
    });
  });
});
