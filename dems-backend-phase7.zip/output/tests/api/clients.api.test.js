/**
 * tests/api/clients.api.test.js
 * ────────────────────────────────────────────────────────────────
 * API contract tests for client management endpoints.
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const request = require('supertest');

const { makeModule } = require('../helpers/mockPrisma');
const prismaModule = makeModule();
jest.mock('../../src/database/prisma.client', () => prismaModule);

jest.mock('../../src/services/client.service', () => ({
  listClients: jest.fn(),
  getClient: jest.fn(),
  createClient: jest.fn(),
  updateClient: jest.fn(),
  deleteClient: jest.fn(),
}));

const app = require('../../src/app');
const clientService = require('../../src/services/client.service');
const { signAccessToken } = require('../../src/utils/jwt.util');

const BASE = '/api/v1/clients';

const mockUser = {
  id: 'user-002',
  email: 'cashier@dems.io',
  role: 'CASHIER',
  isActive: true,
};

const mockSession = {
  id: 'session-002',
  userId: 'user-002',
  isRevoked: false,
  expiresAt: new Date(Date.now() + 86400000),
};

const mockClient = {
  id: 'client-001',
  name: 'Acme Corp',
  phone: '+1234567890',
  email: 'acme@example.com',
  createdAt: new Date().toISOString(),
};

function makeToken(role = 'CASHIER') {
  return signAccessToken({ sub: 'user-002', role, sessionId: 'session-002' });
}

function authHeader(role = 'CASHIER') {
  return { Authorization: `Bearer ${makeToken(role)}` };
}

function setupAuthMocks(role = 'CASHIER') {
  prismaModule.prisma.user.findUnique.mockResolvedValue({ ...mockUser, role });
  prismaModule.prisma.session.findFirst.mockResolvedValue(mockSession);
}

describe('Clients API', () => {
  afterEach(() => jest.clearAllMocks());

  // ── GET /clients ─────────────────────────────────────────────

  describe('GET /api/v1/clients', () => {
    it('returns 401 without auth', async () => {
      const res = await request(app).get(BASE);
      expect(res.status).toBe(401);
    });

    it('returns 200 with list for authenticated user', async () => {
      setupAuthMocks();
      clientService.listClients.mockResolvedValueOnce({
        data: [mockClient],
        meta: { page: 1, limit: 20, totalItems: 1, totalPages: 1 },
      });

      const res = await request(app).get(BASE).set(authHeader());
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
    });
  });

  // ── GET /clients/:id ─────────────────────────────────────────

  describe('GET /api/v1/clients/:id', () => {
    it('returns 200 with client detail', async () => {
      setupAuthMocks();
      clientService.getClient.mockResolvedValueOnce(mockClient);

      const res = await request(app).get(`${BASE}/client-001`).set(authHeader());
      expect(res.status).toBe(200);
    });

    it('returns 404 when client does not exist', async () => {
      setupAuthMocks();
      const ApiError = require('../../src/utils/ApiError');
      clientService.getClient.mockRejectedValueOnce(new ApiError(404, 'Client not found'));

      const res = await request(app).get(`${BASE}/nonexistent`).set(authHeader());
      expect(res.status).toBe(404);
    });
  });

  // ── POST /clients ────────────────────────────────────────────

  describe('POST /api/v1/clients', () => {
    const body = { name: 'New Client', phone: '+9876543210', email: 'new@example.com' };

    it('returns 401 without auth', async () => {
      const res = await request(app).post(BASE).send(body);
      expect(res.status).toBe(401);
    });

    it('returns 403 for AUDITOR role', async () => {
      setupAuthMocks('AUDITOR');

      const res = await request(app)
        .post(BASE)
        .set(authHeader('AUDITOR'))
        .send(body);

      expect(res.status).toBe(403);
    });

    it('returns 201 on successful creation', async () => {
      setupAuthMocks('CASHIER');
      clientService.createClient.mockResolvedValueOnce(mockClient);

      const res = await request(app)
        .post(BASE)
        .set(authHeader('CASHIER'))
        .send(body);

      expect([200, 201]).toContain(res.status);
    });
  });

  // ── DELETE /clients/:id ───────────────────────────────────────

  describe('DELETE /api/v1/clients/:id', () => {
    it('returns 403 for CASHIER role', async () => {
      setupAuthMocks('CASHIER');

      const res = await request(app)
        .delete(`${BASE}/client-001`)
        .set(authHeader('CASHIER'));

      expect(res.status).toBe(403);
    });

    it('returns 200 for ADMIN role', async () => {
      setupAuthMocks('ADMIN');
      clientService.deleteClient.mockResolvedValueOnce({ deleted: true });

      const res = await request(app)
        .delete(`${BASE}/client-001`)
        .set(authHeader('ADMIN'));

      expect([200, 204]).toContain(res.status);
    });
  });
});
