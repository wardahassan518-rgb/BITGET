/**
 * tests/helpers/testApp.js
 * ────────────────────────────────────────────────────────────────
 * Returns the Express `app` configured for testing.
 *
 * Call this AFTER `jest.mock('../../src/database/prisma.client', ...)`
 * has been set up in the test file so the mock is in place before
 * the app module (and all its dependencies) are required.
 *
 * The function is lazy (called inside tests, not at import time) to
 * avoid a timing issue where jest.mock() hasn't yet replaced the
 * module when the top-level `require('./src/app')` fires.
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

/**
 * @returns {import('express').Application}
 */
function getApp() {
  // Require fresh on each call so module-level state is isolated.
  // In practice, Node's module cache means it's the same instance
  // within a single test file — which is what we want.
  return require('../../src/app');
}

module.exports = { getApp };
