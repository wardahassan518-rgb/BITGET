/**
 * tests/helpers/mockPrisma.js
 * ────────────────────────────────────────────────────────────────
 * Factory that returns a jest-mocked version of the Prisma singleton.
 *
 * Usage in a test file:
 *
 *   jest.mock('../../src/database/prisma.client', () =>
 *     require('../helpers/mockPrisma').makeModule()
 *   );
 *
 * Then in tests:
 *
 *   const { prisma } = require('../../src/database/prisma.client');
 *   prisma.user.findUnique.mockResolvedValueOnce({ id: '1', ... });
 *
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

/**
 * Builds one mock model object with the Prisma CRUD methods.
 * @returns {object}
 */
function makeModel() {
  return {
    findMany:      jest.fn(),
    findUnique:    jest.fn(),
    findFirst:     jest.fn(),
    create:        jest.fn(),
    createMany:    jest.fn(),
    update:        jest.fn(),
    updateMany:    jest.fn(),
    upsert:        jest.fn(),
    delete:        jest.fn(),
    deleteMany:    jest.fn(),
    count:         jest.fn(),
    aggregate:     jest.fn(),
    groupBy:       jest.fn(),
  };
}

/**
 * Returns the full mocked prisma.client module shape, ready for
 * `jest.mock(...)`.
 */
function makeModule() {
  const prisma = {
    // Models
    user:            makeModel(),
    session:         makeModel(),
    client:          makeModel(),
    transaction:     makeModel(),
    integrityBlock:  makeModel(),
    auditLog:        makeModel(),
    receipt:         makeModel(),
    receiptAttachment: makeModel(),
    verificationLog: makeModel(),

    // Raw / meta
    $queryRaw:    jest.fn().mockResolvedValue([{ '?column?': 1 }]),
    $transaction: jest.fn((fn) => (typeof fn === 'function' ? fn(prisma) : Promise.resolve(fn))),
    $connect:     jest.fn().mockResolvedValue(undefined),
    $disconnect:  jest.fn().mockResolvedValue(undefined),
  };

  return {
    prisma,
    checkDatabaseConnection: jest.fn().mockResolvedValue(true),
    disconnectDatabase:      jest.fn().mockResolvedValue(undefined),
  };
}

/**
 * Resets all mock implementations on a prisma module's models so
 * state doesn't bleed between tests. Call in `beforeEach`.
 *
 * @param {ReturnType<makeModule>} mockModule
 */
function resetMocks(mockModule) {
  const { prisma } = mockModule;
  const modelNames = [
    'user', 'session', 'client', 'transaction',
    'integrityBlock', 'auditLog', 'receipt',
    'receiptAttachment', 'verificationLog',
  ];

  for (const name of modelNames) {
    if (prisma[name]) {
      Object.values(prisma[name]).forEach((fn) => {
        if (typeof fn === 'function' && fn.mockReset) fn.mockReset();
      });
    }
  }

  if (prisma.$queryRaw?.mockReset) prisma.$queryRaw.mockReset();
  if (prisma.$transaction?.mockReset) prisma.$transaction.mockReset();
}

module.exports = { makeModel, makeModule, resetMocks };
