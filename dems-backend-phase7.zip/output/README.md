# DEMS Backend — Phase 7: Production Readiness

Production-grade backend for the **Digital Exchange Management System (DEMS)** — a secure, tamper-proof, offline-first currency exchange record-keeping system compliant with SECP and financial audit rules.

---

## Table of Contents

- [Tech Stack](#tech-stack)
- [Architecture Overview](#architecture-overview)
- [Quick Start (Local Dev)](#quick-start-local-dev)
- [Environment Variables](#environment-variables)
- [Running Tests](#running-tests)
- [Swagger / API Docs](#swagger--api-docs)
- [Docker](#docker)
- [GitHub Actions CI](#github-actions-ci)
- [Production Deployment](#production-deployment)
- [Health Monitoring](#health-monitoring)
- [Project Structure](#project-structure)
- [API Reference Summary](#api-reference-summary)

---

## Tech Stack

| Concern             | Technology                          |
|---------------------|-------------------------------------|
| Runtime             | Node.js ≥ 18 (LTS 20 recommended)  |
| Web framework       | Express.js 4                        |
| Database            | PostgreSQL 15                       |
| ORM                 | Prisma 5                            |
| Auth                | JWT (jsonwebtoken)                  |
| Password hashing    | bcrypt                              |
| Validation          | Zod                                 |
| Logging             | Winston + DailyRotateFile           |
| API Docs            | Swagger UI (swagger-ui-express)     |
| Testing             | Jest + Supertest                    |
| Containerisation    | Docker + docker-compose             |
| CI                  | GitHub Actions                      |

---

## Architecture Overview

```
src/
├── config/        Environment + middleware configs (CORS, Helmet, rate-limit)
├── constants/     Frozen enums: roles, audit actions, receipt states
├── controllers/   Thin HTTP layer — validates, calls service, sends ApiResponse
├── database/      Prisma singleton client
├── docs/          OpenAPI 3.0 spec (served as Swagger UI at /api-docs)
├── middlewares/   authenticate, authorize, error handler, requestId, logger
├── repositories/  One repository per Prisma model; base class for shared ops
├── routes/        Express routers — one per domain
├── services/      Business logic; coordinates repositories + utils
├── utils/         ApiError, ApiResponse, jwt, bcrypt, hash, pagination, logger
└── validators/    Zod schemas used by validate.middleware

tests/
├── unit/          Pure function tests — no I/O, no mocking required
├── integration/   HTTP-layer tests; Prisma and services mocked
├── api/           End-to-end API contract tests; Prisma and services mocked
├── helpers/       mockPrisma factory, testApp loader
└── setup/         env.js — loads .env.test before any test module runs
```

Request lifecycle: `requestId → Helmet → CORS → compression → hpp → JSON parser → cookieParser → requestLogger → rateLimiter → router → [authenticate → authorize →] controller → service → repository → Prisma → response`

---

## Quick Start (Local Dev)

### Prerequisites

- Node.js ≥ 18
- PostgreSQL 15 running locally (or use Docker Compose below)

### 1. Clone & install

```bash
git clone <your-repo-url> dems-backend
cd dems-backend
npm install
```

### 2. Configure environment

```bash
cp .env.example .env
# Edit .env — at minimum set DATABASE_URL, JWT_SECRET, JWT_REFRESH_SECRET, CHAIN_SALT
```

Minimum required values in `.env`:

```dotenv
NODE_ENV=development
DATABASE_URL="postgresql://user:password@localhost:5432/dems_db?schema=public"
JWT_SECRET="at_least_16_chars_long_secret_here"
JWT_REFRESH_SECRET="different_at_least_16_chars_secret"
CHAIN_SALT="your_chain_salt_here"
```

### 3. Initialise the database

```bash
# Create and apply migrations
npx prisma migrate dev --name init

# Seed the database with initial admin user
npm run db:seed
```

### 4. Start the dev server

```bash
npm run dev          # nodemon — auto-restarts on file changes
# or
npm start            # node — production-style start
```

The server starts on `http://localhost:5000`.  
Swagger UI is available at `http://localhost:5000/api-docs`.

---

## Environment Variables

All variables are validated at startup by Zod in `src/config/env.config.js`. The process exits immediately with a clear error if any required variable is missing or malformed.

| Variable                  | Required | Default                              | Description                              |
|---------------------------|----------|--------------------------------------|------------------------------------------|
| `NODE_ENV`                | No       | `development`                        | `development`, `test`, or `production`   |
| `PORT`                    | No       | `5000`                               | HTTP port                                |
| `API_PREFIX`              | No       | `/api/v1`                            | Route prefix                             |
| `DATABASE_URL`            | **Yes**  | —                                    | Prisma connection string (PostgreSQL)    |
| `JWT_SECRET`              | **Yes**  | —                                    | Access-token signing secret (≥ 16 chars) |
| `JWT_EXPIRES_IN`          | No       | `15m`                                | Access token TTL                         |
| `JWT_REFRESH_SECRET`      | **Yes**  | —                                    | Refresh-token signing secret (≥ 16 chars)|
| `JWT_REFRESH_EXPIRES_IN`  | No       | `7d`                                 | Refresh token TTL                        |
| `BCRYPT_SALT_ROUNDS`      | No       | `12`                                 | bcrypt cost factor (8–15)                |
| `CORS_ORIGIN`             | No       | `http://localhost:5173,...`          | Comma-separated allowed origins          |
| `CORS_CREDENTIALS`        | No       | `true`                               | Allow credentials in CORS                |
| `RATE_LIMIT_WINDOW_MS`    | No       | `900000` (15 min)                    | Rate limiter window                      |
| `RATE_LIMIT_MAX_REQUESTS` | No       | `300`                                | Max requests per window per IP           |
| `UPLOAD_DIR`              | No       | `uploads`                            | Absolute or relative upload path         |
| `MAX_FILE_SIZE_MB`        | No       | `5`                                  | Max upload size in MB                    |
| `ALLOWED_FILE_TYPES`      | No       | `image/jpeg,image/png,...`           | Comma-separated allowed MIME types       |
| `LOG_LEVEL`               | No       | `info`                               | Winston level: error/warn/info/http/debug|
| `LOG_DIR`                 | No       | `logs`                               | Directory for rotating log files         |
| `LOG_MAX_FILES`           | No       | `14d`                                | Log retention period (e.g. `7d`, `30d`)  |
| `TRUST_PROXY`             | No       | `false`                              | Set `true` behind Nginx/ALB/Cloudflare   |
| `CHAIN_SALT`              | No       | `CHANGE_ME_CHAIN_SALT`               | Salt for hash-chain integrity (≥ 16 chars)|

See `.env.example` for a development template and `.env.production.example` for a production template.

---

## Running Tests

### Run all tests

```bash
npm test
```

### Run with coverage report

```bash
npm run test:coverage
```

Coverage thresholds (configured in `jest.config.js`):
- Branches: 60%
- Functions: 65%
- Lines: 65%
- Statements: 65%

### Run a specific suite

```bash
npm run test:unit           # tests/unit/**
npm run test:integration    # tests/integration/**
npm run test:api            # tests/api/**
```

### Watch mode (TDD)

```bash
npm run test:watch
```

### Test environment

Tests use `.env.test` (committed, safe dummy values). Prisma is mocked at the module level — **no real database connection is needed** to run the unit/integration/API test suites.

The test suite is structured in three layers:

| Layer         | Location              | What it tests                                      |
|---------------|-----------------------|----------------------------------------------------|
| Unit          | `tests/unit/`         | Pure utility functions, constants — no I/O         |
| Integration   | `tests/integration/`  | HTTP endpoints with mocked Prisma + services       |
| API contract  | `tests/api/`          | Full route → controller → (mocked) service layer   |

---

## Swagger / API Docs

Interactive API documentation is served via Swagger UI at:

```
http://localhost:5000/api-docs
```

- All routes, request bodies, query params, and response schemas are documented.
- Click **Authorize** and paste a `Bearer <token>` to test protected endpoints.
- Swagger UI is **disabled in `test` environment** to keep test output clean.

The spec lives in `src/docs/openapi.js` — a plain JavaScript object (no JSDoc scanning required). Update it alongside routes to keep it in sync.

---

## Docker

### Development / smoke test

```bash
# Build and run app + PostgreSQL
docker compose up --build

# App:      http://localhost:5000
# Swagger:  http://localhost:5000/api-docs
# DB:       localhost:5432 (dems_user / dems_password / dems_db)
```

### Run tests inside Docker

```bash
docker compose -f docker-compose.test.yml up --build --exit-code-from app
```

This spins up a throwaway PostgreSQL, applies migrations, runs the full Jest suite, then exits with the test runner's exit code.

### Build the production image

```bash
docker build --target runner -t dems-backend:latest .
```

The Dockerfile uses a **4-stage multi-stage build**:

| Stage     | Purpose                                              |
|-----------|------------------------------------------------------|
| `base`    | Alpine + OS deps (openssl, python3 for bcrypt)      |
| `deps`    | `npm ci` + `npm rebuild bcrypt`                      |
| `builder` | `prisma generate`                                    |
| `test`    | Copies src + tests, runs `npm test` (CI use only)    |
| `runner`  | Lean production image — non-root user, no dev deps  |

The production image:
- Runs as a non-root user (`dems:dems`, uid/gid 1001)
- Exposes port `5000`
- Has a built-in Docker HEALTHCHECK (`wget` on `/api/v1/health`)
- Expects persistent volumes at `/data/uploads` and `/data/logs`

---

## GitHub Actions CI

CI runs on every push and pull request to `main` or `develop`.

**Workflow: `.github/workflows/ci.yml`**

| Job      | Trigger               | What it does                                          |
|----------|-----------------------|-------------------------------------------------------|
| `lint`   | All pushes/PRs        | ESLint (placeholder — wire in ESLint config to enable)|
| `test`   | After lint            | Spins up Postgres service, runs `npm test --coverage`|
| `docker` | Push to `main` only   | Builds Docker image (push disabled until registry configured)|

To enable Docker pushes, uncomment the `docker/login-action` and `push: true` steps in `.github/workflows/ci.yml` and add the relevant repository secrets (`DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN` or `GITHUB_TOKEN` for GHCR).

To enable Codecov coverage upload, add `CODECOV_TOKEN` to repository secrets and uncomment the `env` block under the Codecov step.

---

## Production Deployment

### Server requirements

- OS: Ubuntu 22.04 LTS or equivalent
- Docker Engine ≥ 24 + Docker Compose v2
- 1 vCPU / 512 MB RAM minimum (2 vCPU / 1 GB recommended)
- Ports 80/443 open (put Nginx in front of the app container)

### Step-by-step

#### 1. Provision secrets

```bash
# Generate JWT secrets
openssl rand -hex 32   # → JWT_SECRET
openssl rand -hex 32   # → JWT_REFRESH_SECRET
openssl rand -hex 32   # → CHAIN_SALT

# Generate DB password
openssl rand -base64 24  # → POSTGRES_PASSWORD
```

#### 2. Create `.env` from the template

```bash
cp .env.production.example .env
# Fill in all CHANGE_ME values
```

#### 3. Deploy with Docker Compose

```bash
# Pull / build and start in detached mode
docker compose up -d --build

# Verify all services are healthy
docker compose ps

# Tail logs
docker compose logs -f app
```

#### 4. Apply database migrations

Migrations run automatically on every `docker compose up` via the `command` in `docker-compose.yml`. To run them manually:

```bash
docker compose exec app npx prisma migrate deploy
```

#### 5. Seed the initial admin user (first deploy only)

```bash
docker compose exec app node prisma/seed.js
```

#### 6. Set up Nginx reverse proxy (recommended)

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass         http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header   Upgrade $http_upgrade;
        proxy_set_header   Connection 'upgrade';
        proxy_set_header   Host $host;
        proxy_set_header   X-Real-IP $remote_addr;
        proxy_set_header   X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Set `TRUST_PROXY=true` in `.env` when using Nginx so Express reads the correct client IP from `X-Forwarded-For`.

#### 7. Configure TLS with Certbot

```bash
sudo certbot --nginx -d your-domain.com
```

### Zero-downtime updates

```bash
# Pull latest image / rebuild
docker compose pull   # if using a registry
# or
docker compose build app

# Restart only the app container (DB stays up)
docker compose up -d --no-deps app
```

### Rollback

```bash
# Restart with the previous image tag
docker compose down app
docker run --rm -d --name dems_app dems-backend:<previous-sha>
```

---

## Health Monitoring

Two health endpoints are provided for load balancer / orchestrator probes:

| Endpoint              | Auth | Purpose                                           |
|-----------------------|------|---------------------------------------------------|
| `GET /api/v1/health`  | None | **Liveness** — is the Node process alive?        |
| `GET /api/v1/health/db` | None | **Readiness** — can we reach the database?     |

Example liveness response:

```json
{
  "success": true,
  "message": "DEMS backend is running",
  "data": {
    "status": "ok",
    "uptimeSeconds": 3621,
    "timestamp": "2025-06-01T12:00:00.000Z"
  }
}
```

Example readiness response (healthy):

```json
{
  "success": true,
  "message": "Database reachable",
  "data": {
    "status": "ok",
    "database": "connected",
    "timestamp": "2025-06-01T12:00:00.000Z"
  }
}
```

Example readiness response (unhealthy — returns HTTP 503):

```json
{
  "success": false,
  "message": "Database unreachable",
  "data": {
    "status": "down",
    "database": "disconnected",
    "timestamp": "2025-06-01T12:00:00.000Z"
  }
}
```

### Docker HEALTHCHECK

The `Dockerfile` and `docker-compose.yml` include a built-in Docker health check:

```dockerfile
HEALTHCHECK --interval=30s --timeout=5s --start-period=30s --retries=3 \
  CMD wget -qO- http://localhost:5000/api/v1/health || exit 1
```

### Recommended monitoring stack

- **Uptime**: UptimeRobot / Better Uptime pinging `/api/v1/health` every 60 s
- **Logs**: Ship `/data/logs/dems-*.log` to Papertrail, Logtail, or CloudWatch Logs
- **Metrics**: Expose a `/metrics` Prometheus endpoint in a future phase
- **Alerts**: PagerDuty / Slack webhook on `status != ok` or 5xx rate spike

---

## Project Structure

```
dems-backend/
├── .env.example                  Development environment template
├── .env.production.example       Production environment template
├── .env.test                     Test environment (safe dummy values, committed)
├── .dockerignore
├── .gitignore
├── .github/
│   └── workflows/
│       └── ci.yml                GitHub Actions CI pipeline
├── Dockerfile                    Multi-stage build (deps / builder / test / runner)
├── docker-compose.yml            Dev/production compose
├── docker-compose.test.yml       Isolated test compose
├── jest.config.js
├── nodemon.json
├── package.json
├── server.js                     Process entry point
├── prisma/
│   ├── schema.prisma
│   └── seed.js
├── src/
│   ├── app.js                    Express app (middleware + routes + Swagger)
│   ├── config/
│   ├── constants/
│   ├── controllers/
│   ├── database/
│   ├── docs/
│   │   └── openapi.js            OpenAPI 3.0 specification
│   ├── middlewares/
│   ├── repositories/
│   ├── routes/
│   ├── services/
│   ├── utils/
│   └── validators/
├── tests/
│   ├── api/
│   │   ├── clients.api.test.js
│   │   └── transactions.api.test.js
│   ├── helpers/
│   │   ├── mockPrisma.js
│   │   └── testApp.js
│   ├── integration/
│   │   ├── auth.test.js
│   │   └── health.test.js
│   ├── setup/
│   │   └── env.js
│   └── unit/
│       ├── constants/
│       │   └── roles.test.js
│       └── utils/
│           ├── ApiError.test.js
│           ├── ApiResponse.test.js
│           ├── hash.util.test.js
│           ├── jwt.util.test.js
│           └── pagination.util.test.js
├── uploads/
│   └── .gitkeep
└── logs/
    └── .gitkeep
```

---

## API Reference Summary

Full interactive docs at `/api-docs`. Summary below:

| Method   | Path                                          | Auth | Roles                    | Description                            |
|----------|-----------------------------------------------|------|--------------------------|----------------------------------------|
| `GET`    | `/api/v1/health`                              | No   | —                        | Liveness probe                         |
| `GET`    | `/api/v1/health/db`                           | No   | —                        | Readiness probe                        |
| `POST`   | `/api/v1/auth/login`                          | No   | —                        | Login → access + refresh tokens        |
| `POST`   | `/api/v1/auth/refresh`                        | No   | —                        | Rotate access token via cookie         |
| `POST`   | `/api/v1/auth/logout`                         | Yes  | All                      | Revoke session                         |
| `GET`    | `/api/v1/auth/me`                             | Yes  | All                      | Current user profile                   |
| `GET`    | `/api/v1/clients`                             | Yes  | All                      | Paginated client list                  |
| `POST`   | `/api/v1/clients`                             | Yes  | Admin/Manager/Cashier    | Create client                          |
| `GET`    | `/api/v1/clients/:id`                         | Yes  | All                      | Client detail                          |
| `PUT`    | `/api/v1/clients/:id`                         | Yes  | Admin/Manager/Cashier    | Update client                          |
| `DELETE` | `/api/v1/clients/:id`                         | Yes  | Admin/Manager            | Delete client                          |
| `GET`    | `/api/v1/transactions`                        | Yes  | All                      | Paginated transaction list             |
| `POST`   | `/api/v1/transactions`                        | Yes  | Admin/Manager/Cashier    | Create transaction (auto hash-chain)   |
| `GET`    | `/api/v1/transactions/:id`                    | Yes  | All                      | Transaction + integrity block          |
| `PUT`    | `/api/v1/transactions/:id`                    | Yes  | Admin/Manager            | Update transaction                     |
| `DELETE` | `/api/v1/transactions/:id`                    | Yes  | Admin/Manager            | Void transaction                       |
| `GET`    | `/api/v1/integrity/transaction/:id`           | Yes  | All                      | Verify single transaction hash         |
| `GET`    | `/api/v1/integrity/chain`                     | Yes  | Admin/Auditor            | Full hash-chain scan                   |
| `GET`    | `/api/v1/dashboard/summary`                   | Yes  | All                      | Period statistics                      |
| `GET`    | `/api/v1/dashboard/charts`                    | Yes  | All                      | Time-series chart data                 |
| `GET`    | `/api/v1/dashboard/recent-transactions`       | Yes  | All                      | Recent N transactions                  |
| `GET`    | `/api/v1/dashboard/recent-audit-logs`         | Yes  | Admin/Manager/Auditor    | Recent audit log entries               |
| `GET`    | `/api/v1/reports/daily`                       | Yes  | All                      | Daily report                           |
| `GET`    | `/api/v1/reports/monthly`                     | Yes  | All                      | Monthly report                         |
| `GET`    | `/api/v1/reports/custom`                      | Yes  | All                      | Custom date range report               |
| `GET`    | `/api/v1/reports/clients`                     | Yes  | All                      | Client analytics                       |
| `GET`    | `/api/v1/reports/transactions`                | Yes  | All                      | Transaction analytics                  |
| `GET`    | `/api/v1/reports/audit`                       | Yes  | Admin/Auditor            | Audit log report                       |
| `GET`    | `/api/v1/reports/statistics`                  | Yes  | All                      | Statistical aggregates                 |
| `GET`    | `/api/v1/receipts`                            | Yes  | Admin/Manager/Auditor    | Paginated receipt list                 |
| `POST`   | `/api/v1/receipts/ensure/:transactionId`      | Yes  | Admin/Manager/Cashier    | Idempotent receipt create/fetch        |
| `GET`    | `/api/v1/receipts/:receiptNumber`             | Yes  | All                      | Receipt detail                         |
| `POST`   | `/api/v1/receipts/:receiptNumber/pdf`         | Yes  | All                      | Generate PDF                           |
| `GET`    | `/api/v1/receipts/:receiptNumber/pdf`         | Yes  | All                      | Download PDF                           |
| `POST`   | `/api/v1/receipts/:receiptNumber/qr`          | Yes  | All                      | Generate QR code                       |
| `POST`   | `/api/v1/receipts/:receiptNumber/print`       | Yes  | All                      | Log print event                        |
| `POST`   | `/api/v1/receipts/:receiptNumber/share`       | Yes  | All                      | Log share event                        |
| `POST`   | `/api/v1/receipts/transactions/:txnId/attachments` | Yes | Admin/Manager/Cashier | Upload attachment                 |
| `GET`    | `/api/v1/receipts/transactions/:txnId/attachments` | Yes | All              | List attachments                       |
| `GET`    | `/api/v1/receipts/attachments/:attachmentId`  | Yes  | All                      | Download attachment                    |
| `DELETE` | `/api/v1/receipts/attachments/:attachmentId`  | Yes  | Admin/Manager            | Delete attachment                      |
| `GET`    | `/api/v1/verification`                        | Yes  | All                      | Verification audit log                 |
| `GET`    | `/api/v1/verification/:receiptNumber`         | Yes  | All                      | Enriched verification detail           |
| `GET`    | `/api/verify/:receipt`                        | No   | —                        | **Public** receipt verification        |

---

## Useful Scripts

```bash
npm start                    # Production server
npm run dev                  # Dev server with nodemon
npm test                     # All tests
npm run test:coverage        # Tests + coverage report
npm run test:unit            # Unit tests only
npm run test:integration     # Integration tests only
npm run test:api             # API contract tests only
npm run prisma:generate      # Regenerate Prisma client
npm run prisma:migrate       # Create + apply dev migration
npm run prisma:migrate:deploy # Apply pending migrations (production)
npm run prisma:studio        # Open Prisma Studio (DB GUI)
npm run db:seed              # Seed initial admin user
```

---

## Roles & Permissions

| Role      | Description                               | Can mutate data |
|-----------|-------------------------------------------|-----------------|
| `ADMIN`   | Full access including user management     | Yes             |
| `MANAGER` | Operational access — all domains          | Yes             |
| `CASHIER` | Day-to-day transactions and clients       | Yes (limited)   |
| `AUDITOR` | Read-only access to all data + audit logs | No              |

Role hierarchy: `ADMIN > MANAGER > CASHIER > AUDITOR`

---

## Logging

Log files are written to `LOG_DIR` (default: `./logs`) in JSON format, daily-rotated, retained for `LOG_MAX_FILES` (default: `14d`).

| File                        | Contents                     |
|-----------------------------|------------------------------|
| `dems-combined-YYYY-MM-DD.log` | All log levels              |
| `dems-error-YYYY-MM-DD.log`    | Error level only            |

Console output is colorized in development and silenced in test mode.

Each request log entry includes: `requestId`, `method`, `url`, `statusCode`, `responseTimeMs`, `ip`, `userAgent`.

---

## Security Headers

Helmet is configured with:
- `X-Frame-Options: DENY`
- `X-Content-Type-Options: nosniff`
- `Strict-Transport-Security` (prod only)
- `Content-Security-Policy` (API-appropriate — no scripts/styles)
- `X-XSS-Protection` disabled (modern browsers handle this)

Rate limiting: 300 requests / 15 minutes per IP by default. Configurable via `RATE_LIMIT_*` env vars.

---

*DEMS Backend — Phase 7: Production Readiness. Architecture frozen from Phase 6.*
