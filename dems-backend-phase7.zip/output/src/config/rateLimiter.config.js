/**
 * src/config/rateLimiter.config.js
 * ────────────────────────────────────────────────────────────────
 * Global API rate limiter (express-rate-limit).
 *
 * This protects the foundation itself (e.g. the /health endpoint and
 * whatever routes future phases add) from basic abuse. Endpoint-
 * specific limits (e.g. a stricter limiter for a future login route)
 * belong to the phase that builds that endpoint.
 * ────────────────────────────────────────────────────────────────
 */

const rateLimit = require('express-rate-limit');
const config = require('./env.config');
const ApiError = require('../utils/ApiError');

const globalRateLimiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.maxRequests,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res, next) => {
    next(new ApiError(429, 'Too many requests. Please try again later.'));
  },
});

module.exports = globalRateLimiter;
