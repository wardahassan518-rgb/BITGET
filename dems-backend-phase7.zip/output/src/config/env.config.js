/**
 * src/config/env.config.js
 * ────────────────────────────────────────────────────────────────
 * Single source of truth for environment variables.
 *
 * Every variable the application depends on is parsed and validated
 * here with Zod, ONCE, at boot. If a required variable is missing or
 * malformed, the process fails fast with a clear error instead of
 * crashing later (or silently misbehaving) deep inside the app.
 *
 * Nothing else in the codebase should call `process.env` directly —
 * import `config` from this file instead.
 * ────────────────────────────────────────────────────────────────
 */

const path = require('path');
const dotenv = require('dotenv');
const { z } = require('zod');

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

const envSchema = z.object({
  // ── Core ────────────────────────────────────────────────
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().positive().default(5000),
  API_PREFIX: z.string().default('/api/v1'),

  // ── Database (PostgreSQL via Prisma) ────────────────────
  DATABASE_URL: z
    .string()
    .min(1, 'DATABASE_URL is required, e.g. postgresql://user:pass@host:5432/dems_db'),

  // ── JWT (config reserved for Phase 2 — Authentication) ──
  JWT_SECRET: z.string().min(16, 'JWT_SECRET must be at least 16 characters'),
  JWT_EXPIRES_IN: z.string().default('15m'),
  JWT_REFRESH_SECRET: z.string().min(16, 'JWT_REFRESH_SECRET must be at least 16 characters'),
  JWT_REFRESH_EXPIRES_IN: z.string().default('7d'),

  // ── bcrypt (config reserved for Phase 2 — Authentication) ──
  BCRYPT_SALT_ROUNDS: z.coerce.number().int().min(8).max(15).default(12),

  // ── CORS ─────────────────────────────────────────────────
  CORS_ORIGIN: z.string().default('http://localhost:5173,http://localhost:3000'),
  CORS_CREDENTIALS: z.coerce.boolean().default(true),

  // ── Rate limiting ────────────────────────────────────────
  RATE_LIMIT_WINDOW_MS: z.coerce.number().int().positive().default(15 * 60 * 1000),
  RATE_LIMIT_MAX_REQUESTS: z.coerce.number().int().positive().default(300),

  // ── File uploads (Multer) ───────────────────────────────
  UPLOAD_DIR: z.string().default('uploads'),
  MAX_FILE_SIZE_MB: z.coerce.number().positive().default(5),
  ALLOWED_FILE_TYPES: z.string().default('image/jpeg,image/png,image/webp,application/pdf'),

  // ── Logging ──────────────────────────────────────────────
  LOG_LEVEL: z.enum(['error', 'warn', 'info', 'http', 'debug']).default('info'),
  LOG_DIR: z.string().default('logs'),
  LOG_MAX_FILES: z.string().default('14d'),

  // ── Security / misc ──────────────────────────────────────
  TRUST_PROXY: z.coerce.boolean().default(false),
  CHAIN_SALT: z.string().default('CHANGE_ME_CHAIN_SALT'),
});

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  // Intentionally bypass the Winston logger here — it may depend on
  // config that failed to parse. Fail loudly and exit immediately.
  // eslint-disable-next-line no-console
  console.error('\n❌ Invalid or missing environment variables:\n');
  // eslint-disable-next-line no-console
  console.error(parsed.error.flatten().fieldErrors);
  process.exit(1);
}

const env = parsed.data;

const config = {
  env: env.NODE_ENV,
  isProduction: env.NODE_ENV === 'production',
  isDevelopment: env.NODE_ENV === 'development',
  isTest: env.NODE_ENV === 'test',

  port: env.PORT,
  apiPrefix: env.API_PREFIX,

  database: {
    url: env.DATABASE_URL,
  },

  jwt: {
    secret: env.JWT_SECRET,
    expiresIn: env.JWT_EXPIRES_IN,
    refreshSecret: env.JWT_REFRESH_SECRET,
    refreshExpiresIn: env.JWT_REFRESH_EXPIRES_IN,
  },

  bcrypt: {
    saltRounds: env.BCRYPT_SALT_ROUNDS,
  },

  cors: {
    origins: env.CORS_ORIGIN.split(',').map((o) => o.trim()).filter(Boolean),
    credentials: env.CORS_CREDENTIALS,
  },

  rateLimit: {
    windowMs: env.RATE_LIMIT_WINDOW_MS,
    maxRequests: env.RATE_LIMIT_MAX_REQUESTS,
  },

  upload: {
    dir: env.UPLOAD_DIR,
    maxFileSizeBytes: env.MAX_FILE_SIZE_MB * 1024 * 1024,
    allowedMimeTypes: env.ALLOWED_FILE_TYPES.split(',').map((t) => t.trim()).filter(Boolean),
  },

  logging: {
    level: env.LOG_LEVEL,
    dir: env.LOG_DIR,
    maxFiles: env.LOG_MAX_FILES,
  },

  security: {
    trustProxy: env.TRUST_PROXY,
    chainSalt: env.CHAIN_SALT,
  },
};

module.exports = config;
