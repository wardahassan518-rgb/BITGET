/**
 * src/config/cors.config.js
 * ────────────────────────────────────────────────────────────────
 * Builds the options object passed to the `cors` middleware.
 *
 * Allowed origins come from CORS_ORIGIN (comma-separated) in .env so
 * the same code works across local dev, staging, and production
 * without code changes — only env var changes.
 * ────────────────────────────────────────────────────────────────
 */

const config = require('./env.config');
const logger = require('../utils/logger');

/**
 * @type {import('cors').CorsOptions}
 */
const corsOptions = {
  origin(origin, callback) {
    // Allow non-browser tools (curl, Postman, server-to-server) which
    // send no Origin header at all.
    if (!origin) return callback(null, true);

    if (config.cors.origins.includes('*') || config.cors.origins.includes(origin)) {
      return callback(null, true);
    }

    logger.warn(`CORS blocked request from disallowed origin: ${origin}`);
    return callback(new Error(`Origin '${origin}' is not allowed by CORS policy.`));
  },
  credentials: config.cors.credentials,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-Id'],
  exposedHeaders: ['X-Request-Id'],
  maxAge: 86400, // cache preflight response for 24h
};

module.exports = corsOptions;
