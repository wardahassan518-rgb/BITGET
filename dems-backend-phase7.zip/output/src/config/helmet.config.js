/**
 * src/config/helmet.config.js
 * ────────────────────────────────────────────────────────────────
 * Security HTTP headers via Helmet.
 *
 * This is a pure JSON API backend (the frontend is static HTML served
 * separately / by a CDN), so we keep Helmet's defaults for most
 * directives and only tune Content-Security-Policy + cross-origin
 * resource policy for an API-only context.
 * ────────────────────────────────────────────────────────────────
 */

/**
 * @type {import('helmet').HelmetOptions}
 */
const helmetOptions = {
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'none'"],
      frameAncestors: ["'none'"],
    },
  },
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  referrerPolicy: { policy: 'no-referrer' },
  hsts: {
    maxAge: 31536000, // 1 year
    includeSubDomains: true,
    preload: true,
  },
};

module.exports = helmetOptions;
