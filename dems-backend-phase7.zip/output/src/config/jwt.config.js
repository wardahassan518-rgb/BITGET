/**
 * src/config/jwt.config.js
 * ────────────────────────────────────────────────────────────────
 * JWT settings, pulled from validated env config.
 *
 * Reserved for Phase 2 (Authentication). This file exposes ONLY the
 * configuration values + a thin sign/verify utility (see
 * `src/utils/jwt.util.js`) — no login/register/refresh endpoints,
 * no middleware that protects routes, and no token blacklist/rotation
 * strategy are implemented yet.
 * ────────────────────────────────────────────────────────────────
 */

const config = require('../config/env.config');

module.exports = {
  accessToken: {
    secret: config.jwt.secret,
    expiresIn: config.jwt.expiresIn,
  },
  refreshToken: {
    secret: config.jwt.refreshSecret,
    expiresIn: config.jwt.refreshExpiresIn,
  },
  issuer: 'dems-backend',
  audience: 'dems-frontend',
};
