/**
 * src/config/multer.config.js
 * ────────────────────────────────────────────────────────────────
 * Generic Multer disk-storage configuration.
 *
 * This ONLY configures how files are accepted and stored on disk —
 * it does not define any upload endpoint, controller, or business
 * rule about what an "attachment" or "receipt screenshot" is. That
 * belongs to a later phase (Transactions). Routes can import
 * `upload` from here and call `.single('file')` / `.array('files')`
 * when that phase is built.
 * ────────────────────────────────────────────────────────────────
 */

const fs = require('fs');
const path = require('path');
const multer = require('multer');
const config = require('./env.config');
const ApiError = require('../utils/ApiError');

const UPLOAD_ROOT = path.resolve(process.cwd(), config.upload.dir);

// Ensure the upload directory tree exists before Multer tries to write to it.
['', 'screenshots', 'temp'].forEach((sub) => {
  const dir = path.join(UPLOAD_ROOT, sub);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

const storage = multer.diskStorage({
  destination(req, file, cb) {
    cb(null, path.join(UPLOAD_ROOT, 'temp'));
  },
  filename(req, file, cb) {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    const ext = path.extname(file.originalname);
    cb(null, `${file.fieldname}-${uniqueSuffix}${ext}`);
  },
});

function fileFilter(req, file, cb) {
  if (config.upload.allowedMimeTypes.includes(file.mimetype)) {
    return cb(null, true);
  }
  return cb(
    new ApiError(
      415,
      `Unsupported file type '${file.mimetype}'. Allowed types: ${config.upload.allowedMimeTypes.join(', ')}`,
    ),
  );
}

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: config.upload.maxFileSizeBytes,
    files: 5,
  },
});

module.exports = { upload, UPLOAD_ROOT };
