/**
 * src/database/prisma.client.js
 * ────────────────────────────────────────────────────────────────
 * Single, shared PrismaClient instance for the whole application.
 *
 * Why a singleton: creating a new PrismaClient per request (or per
 * file) opens a new connection pool each time, which exhausts
 * PostgreSQL's max_connections under load and is the #1 cause of
 * "too many connections" errors in Node + Prisma apps. Every
 * repository/service should `require('../database/prisma.client')`
 * and reuse this instance.
 *
 * In development, Node's module cache already gives us a singleton
 * across normal `require()`s — the extra guard below only matters
 * if something triggers hot-reloading (e.g. nodemon restarts share
 * the same process in rare setups, or ts-node-dev style watchers).
 * ────────────────────────────────────────────────────────────────
 */

const { PrismaClient } = require('@prisma/client');
const config = require('../config/env.config');
const logger = require('../utils/logger');

const logLevels = config.isProduction
  ? [{ level: 'error', emit: 'event' }, { level: 'warn', emit: 'event' }]
  : [
      { level: 'query', emit: 'event' },
      { level: 'error', emit: 'event' },
      { level: 'warn', emit: 'event' },
    ];

function createPrismaClient() {
  const client = new PrismaClient({
    datasources: { db: { url: config.database.url } },
    log: logLevels,
  });

  client.$on('error', (e) => logger.error(`Prisma error: ${e.message}`));
  client.$on('warn', (e) => logger.warn(`Prisma warn: ${e.message}`));
  if (!config.isProduction) {
    client.$on('query', (e) => {
      logger.debug(`Prisma query (${e.duration}ms): ${e.query}`);
    });
  }

  return client;
}

// Reuse a global instance across hot-reloads in dev to avoid exhausting
// the connection pool; in production this is just a normal module-level
// singleton.
const globalForPrisma = globalThis;

const prisma = globalForPrisma.__demsPrisma || createPrismaClient();

if (!config.isProduction) {
  globalForPrisma.__demsPrisma = prisma;
}

/**
 * Verifies the database is reachable. Used by server startup and by
 * the /health/db readiness endpoint.
 * @returns {Promise<boolean>}
 */
async function checkDatabaseConnection() {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return true;
  } catch (err) {
    logger.error(`Database connectivity check failed: ${err.message}`);
    return false;
  }
}

/**
 * Gracefully closes the Prisma connection pool. Call during shutdown.
 */
async function disconnectDatabase() {
  await prisma.$disconnect();
}

module.exports = { prisma, checkDatabaseConnection, disconnectDatabase };
