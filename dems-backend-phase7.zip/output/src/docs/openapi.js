/**
 * src/docs/openapi.js
 * ────────────────────────────────────────────────────────────────
 * OpenAPI 3.0 specification for the DEMS backend.
 * Served as Swagger UI at GET /api-docs
 *
 * Structure mirrors the existing route architecture — no JSDoc
 * scanning is needed; the spec is declared inline and stays in
 * sync with the routes defined in src/routes/.
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const config = require('../config/env.config');

const spec = {
  openapi: '3.0.3',
  info: {
    title: 'DEMS Backend API',
    version: '6.0.0',
    description:
      'Digital Exchange Management System — REST API. ' +
      'Phase 6: Receipts, PDF generation, QR codes, Verification & Audit.',
    contact: {
      name: 'DEMS Engineering',
    },
  },
  servers: [
    {
      url: `http://localhost:${config.port}${config.apiPrefix}`,
      description: 'Local development',
    },
    {
      url: `https://your-domain.com${config.apiPrefix}`,
      description: 'Production',
    },
  ],

  // ── Security ────────────────────────────────────────────────
  components: {
    securitySchemes: {
      BearerAuth: {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
        description: 'Access token obtained from POST /auth/login',
      },
    },

    // ── Reusable response schemas ───────────────────────────
    schemas: {
      // ── Generic wrappers ──────────────────────────────────
      SuccessResponse: {
        type: 'object',
        properties: {
          success:   { type: 'boolean', example: true },
          message:   { type: 'string',  example: 'OK' },
          data:      { },
        },
      },
      ErrorResponse: {
        type: 'object',
        properties: {
          success:   { type: 'boolean', example: false },
          message:   { type: 'string',  example: 'Not found' },
          requestId: { type: 'string',  example: 'req-uuid-123' },
          details:   { nullable: true },
        },
      },
      PaginationMeta: {
        type: 'object',
        properties: {
          page:       { type: 'integer', example: 1 },
          limit:      { type: 'integer', example: 20 },
          totalItems: { type: 'integer', example: 150 },
          totalPages: { type: 'integer', example: 8 },
        },
      },

      // ── Domain models ─────────────────────────────────────
      User: {
        type: 'object',
        properties: {
          id:        { type: 'string', format: 'uuid' },
          email:     { type: 'string', format: 'email' },
          name:      { type: 'string' },
          role:      { type: 'string', enum: ['ADMIN', 'MANAGER', 'CASHIER', 'AUDITOR'] },
          isActive:  { type: 'boolean' },
          createdAt: { type: 'string', format: 'date-time' },
        },
      },
      Client: {
        type: 'object',
        properties: {
          id:        { type: 'string', format: 'uuid' },
          name:      { type: 'string', example: 'Acme Corp' },
          phone:     { type: 'string', example: '+1234567890' },
          email:     { type: 'string', format: 'email', nullable: true },
          address:   { type: 'string', nullable: true },
          isActive:  { type: 'boolean' },
          createdAt: { type: 'string', format: 'date-time' },
        },
      },
      Transaction: {
        type: 'object',
        properties: {
          id:              { type: 'string', format: 'uuid' },
          clientId:        { type: 'string', format: 'uuid' },
          amount:          { type: 'number', example: 500.00 },
          currency:        { type: 'string', example: 'USD' },
          type:            { type: 'string', enum: ['DEPOSIT', 'WITHDRAWAL', 'EXCHANGE', 'TRANSFER'] },
          status:          { type: 'string', enum: ['PENDING', 'COMPLETED', 'VOIDED'] },
          exchangeRate:    { type: 'number', example: 1.25 },
          convertedAmount: { type: 'number', example: 625.00 },
          notes:           { type: 'string', nullable: true },
          receiptNumber:   { type: 'string', nullable: true },
          hash:            { type: 'string', example: 'sha256hex...' },
          createdAt:       { type: 'string', format: 'date-time' },
        },
      },
      Receipt: {
        type: 'object',
        properties: {
          id:            { type: 'string', format: 'uuid' },
          receiptNumber: { type: 'string', example: 'RCP-2025-001234' },
          transactionId: { type: 'string', format: 'uuid' },
          pdfPath:       { type: 'string', nullable: true },
          qrCodePath:    { type: 'string', nullable: true },
          printCount:    { type: 'integer', example: 1 },
          shareCount:    { type: 'integer', example: 0 },
          createdAt:     { type: 'string', format: 'date-time' },
        },
      },
    },

    // ── Reusable parameters ────────────────────────────────
    parameters: {
      PageParam: {
        name: 'page',
        in: 'query',
        schema: { type: 'integer', default: 1, minimum: 1 },
        description: 'Page number (1-based)',
      },
      LimitParam: {
        name: 'limit',
        in: 'query',
        schema: { type: 'integer', default: 20, minimum: 1, maximum: 100 },
        description: 'Items per page',
      },
      IdParam: {
        name: 'id',
        in: 'path',
        required: true,
        schema: { type: 'string', format: 'uuid' },
        description: 'Record UUID',
      },
    },
  },

  // ── Default security: Bearer on all routes ──────────────
  security: [{ BearerAuth: [] }],

  // ── Tags ────────────────────────────────────────────────
  tags: [
    { name: 'Health',         description: 'Liveness & readiness probes' },
    { name: 'Auth',           description: 'Authentication & token management' },
    { name: 'Clients',        description: 'Client management' },
    { name: 'Transactions',   description: 'Transaction ledger' },
    { name: 'Integrity',      description: 'Hash-chain integrity engine' },
    { name: 'Dashboard',      description: 'Dashboard summary & charts' },
    { name: 'Reports',        description: 'Analytical reports & exports' },
    { name: 'Receipts',       description: 'Receipt generation, PDF, QR & attachments' },
    { name: 'Verification',   description: 'Enriched verification & audit log' },
  ],

  // ── Paths ────────────────────────────────────────────────
  paths: {

    // ═══════════════════════════════════════════════════════
    // HEALTH
    // ═══════════════════════════════════════════════════════

    '/health': {
      get: {
        tags: ['Health'],
        summary: 'Liveness probe',
        description: 'Returns 200 if the Node process is up. No database check.',
        security: [],
        responses: {
          200: {
            description: 'Service is alive',
            content: {
              'application/json': {
                example: {
                  success: true,
                  message: 'DEMS backend is running',
                  data: { status: 'ok', uptimeSeconds: 3620, timestamp: '2025-01-01T00:00:00.000Z' },
                },
              },
            },
          },
        },
      },
    },

    '/health/db': {
      get: {
        tags: ['Health'],
        summary: 'Readiness probe',
        description: 'Returns 200 if the database is reachable, 503 if not.',
        security: [],
        responses: {
          200: {
            description: 'Database is connected',
            content: {
              'application/json': {
                example: {
                  success: true,
                  message: 'Database reachable',
                  data: { status: 'ok', database: 'connected', timestamp: '2025-01-01T00:00:00.000Z' },
                },
              },
            },
          },
          503: { description: 'Database unreachable' },
        },
      },
    },

    // ═══════════════════════════════════════════════════════
    // AUTH
    // ═══════════════════════════════════════════════════════

    '/auth/login': {
      post: {
        tags: ['Auth'],
        summary: 'Login',
        security: [],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['email', 'password'],
                properties: {
                  email:    { type: 'string', format: 'email', example: 'admin@dems.io' },
                  password: { type: 'string', example: 'Password1!' },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: 'Login successful — access token returned; refresh token set as httpOnly cookie',
            content: {
              'application/json': {
                example: {
                  success: true,
                  message: 'Login successful',
                  data: {
                    accessToken: 'eyJhbGc...',
                    user: { id: 'uuid', email: 'admin@dems.io', role: 'ADMIN' },
                  },
                },
              },
            },
          },
          400: { description: 'Validation error' },
          401: { description: 'Invalid credentials' },
        },
      },
    },

    '/auth/refresh': {
      post: {
        tags: ['Auth'],
        summary: 'Refresh access token',
        security: [],
        description: 'Reads the refresh token from the `refreshToken` httpOnly cookie.',
        responses: {
          200: { description: 'New access token issued' },
          401: { description: 'Refresh token missing, expired, or revoked' },
        },
      },
    },

    '/auth/logout': {
      post: {
        tags: ['Auth'],
        summary: 'Logout',
        description: 'Revokes the current session and clears the refresh-token cookie.',
        responses: {
          200: { description: 'Logged out successfully' },
          401: { description: 'Not authenticated' },
        },
      },
    },

    '/auth/me': {
      get: {
        tags: ['Auth'],
        summary: 'Get current user profile',
        responses: {
          200: {
            description: 'Current user',
            content: {
              'application/json': {
                schema: { $ref: '#/components/schemas/User' },
              },
            },
          },
          401: { description: 'Not authenticated' },
        },
      },
    },

    // ═══════════════════════════════════════════════════════
    // CLIENTS
    // ═══════════════════════════════════════════════════════

    '/clients': {
      get: {
        tags: ['Clients'],
        summary: 'List clients',
        parameters: [
          { $ref: '#/components/parameters/PageParam' },
          { $ref: '#/components/parameters/LimitParam' },
          { name: 'search', in: 'query', schema: { type: 'string' }, description: 'Name/phone/email search' },
          { name: 'isActive', in: 'query', schema: { type: 'boolean' }, description: 'Filter by active status' },
        ],
        responses: {
          200: {
            description: 'Paginated client list',
            content: {
              'application/json': {
                schema: {
                  allOf: [
                    { $ref: '#/components/schemas/SuccessResponse' },
                    {
                      properties: {
                        data: { type: 'array', items: { $ref: '#/components/schemas/Client' } },
                        meta: { $ref: '#/components/schemas/PaginationMeta' },
                      },
                    },
                  ],
                },
              },
            },
          },
          401: { description: 'Not authenticated' },
        },
      },
      post: {
        tags: ['Clients'],
        summary: 'Create client',
        description: 'Roles: ADMIN, MANAGER, CASHIER',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['name', 'phone'],
                properties: {
                  name:    { type: 'string' },
                  phone:   { type: 'string' },
                  email:   { type: 'string', format: 'email' },
                  address: { type: 'string' },
                },
              },
            },
          },
        },
        responses: {
          201: { description: 'Client created' },
          400: { description: 'Validation error' },
          403: { description: 'Insufficient role (AUDITOR)' },
          409: { description: 'Duplicate phone/email' },
        },
      },
    },

    '/clients/{id}': {
      get: {
        tags: ['Clients'],
        summary: 'Get client by ID',
        parameters: [{ $ref: '#/components/parameters/IdParam' }],
        responses: {
          200: { description: 'Client detail' },
          404: { description: 'Client not found' },
        },
      },
      put: {
        tags: ['Clients'],
        summary: 'Update client',
        description: 'Roles: ADMIN, MANAGER, CASHIER',
        parameters: [{ $ref: '#/components/parameters/IdParam' }],
        requestBody: {
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  name:     { type: 'string' },
                  phone:    { type: 'string' },
                  email:    { type: 'string', format: 'email' },
                  address:  { type: 'string' },
                  isActive: { type: 'boolean' },
                },
              },
            },
          },
        },
        responses: {
          200: { description: 'Client updated' },
          403: { description: 'Insufficient role' },
          404: { description: 'Client not found' },
        },
      },
      delete: {
        tags: ['Clients'],
        summary: 'Delete client',
        description: 'Roles: ADMIN, MANAGER',
        parameters: [{ $ref: '#/components/parameters/IdParam' }],
        responses: {
          200: { description: 'Client deleted' },
          403: { description: 'Insufficient role' },
          404: { description: 'Client not found' },
        },
      },
    },

    // ═══════════════════════════════════════════════════════
    // TRANSACTIONS
    // ═══════════════════════════════════════════════════════

    '/transactions': {
      get: {
        tags: ['Transactions'],
        summary: 'List transactions',
        parameters: [
          { $ref: '#/components/parameters/PageParam' },
          { $ref: '#/components/parameters/LimitParam' },
          { name: 'clientId', in: 'query', schema: { type: 'string', format: 'uuid' } },
          { name: 'type', in: 'query', schema: { type: 'string', enum: ['DEPOSIT', 'WITHDRAWAL', 'EXCHANGE', 'TRANSFER'] } },
          { name: 'status', in: 'query', schema: { type: 'string', enum: ['PENDING', 'COMPLETED', 'VOIDED'] } },
          { name: 'startDate', in: 'query', schema: { type: 'string', format: 'date' } },
          { name: 'endDate', in: 'query', schema: { type: 'string', format: 'date' } },
        ],
        responses: {
          200: {
            description: 'Paginated transaction list',
            content: {
              'application/json': {
                schema: {
                  properties: {
                    data: { type: 'array', items: { $ref: '#/components/schemas/Transaction' } },
                    meta: { $ref: '#/components/schemas/PaginationMeta' },
                  },
                },
              },
            },
          },
        },
      },
      post: {
        tags: ['Transactions'],
        summary: 'Create transaction',
        description: 'Roles: ADMIN, MANAGER, CASHIER',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['clientId', 'amount', 'type', 'currency', 'exchangeRate', 'convertedAmount'],
                properties: {
                  clientId:        { type: 'string', format: 'uuid' },
                  amount:          { type: 'number', minimum: 0.01 },
                  currency:        { type: 'string', example: 'USD' },
                  type:            { type: 'string', enum: ['DEPOSIT', 'WITHDRAWAL', 'EXCHANGE', 'TRANSFER'] },
                  exchangeRate:    { type: 'number', example: 1.25 },
                  convertedAmount: { type: 'number' },
                  notes:           { type: 'string' },
                },
              },
            },
          },
        },
        responses: {
          201: { description: 'Transaction created with hash-chain entry' },
          400: { description: 'Validation error' },
          403: { description: 'Insufficient role' },
          404: { description: 'Client not found' },
        },
      },
    },

    '/transactions/{id}': {
      get: {
        tags: ['Transactions'],
        summary: 'Get transaction by ID',
        parameters: [{ $ref: '#/components/parameters/IdParam' }],
        responses: {
          200: { description: 'Transaction detail with integrity block' },
          404: { description: 'Transaction not found' },
        },
      },
      put: {
        tags: ['Transactions'],
        summary: 'Update transaction',
        description: 'Roles: ADMIN, MANAGER',
        parameters: [{ $ref: '#/components/parameters/IdParam' }],
        responses: {
          200: { description: 'Transaction updated' },
          403: { description: 'Insufficient role' },
          404: { description: 'Not found' },
        },
      },
      delete: {
        tags: ['Transactions'],
        summary: 'Void/delete transaction',
        description: 'Roles: ADMIN, MANAGER',
        parameters: [{ $ref: '#/components/parameters/IdParam' }],
        responses: {
          200: { description: 'Transaction voided' },
          403: { description: 'Insufficient role' },
        },
      },
    },

    // ═══════════════════════════════════════════════════════
    // INTEGRITY
    // ═══════════════════════════════════════════════════════

    '/integrity/transaction/{id}': {
      get: {
        tags: ['Integrity'],
        summary: 'Verify a single transaction hash',
        parameters: [{ $ref: '#/components/parameters/IdParam' }],
        responses: {
          200: { description: 'Integrity result with tamper status' },
          404: { description: 'Transaction not found' },
        },
      },
    },

    '/integrity/chain': {
      get: {
        tags: ['Integrity'],
        summary: 'Scan the full hash chain',
        description: 'Roles: ADMIN, AUDITOR',
        responses: {
          200: { description: 'Chain scan result — broken links listed' },
          403: { description: 'Insufficient role' },
        },
      },
    },

    // ═══════════════════════════════════════════════════════
    // DASHBOARD
    // ═══════════════════════════════════════════════════════

    '/dashboard/summary': {
      get: {
        tags: ['Dashboard'],
        summary: 'Overall & period statistics',
        parameters: [
          { name: 'period', in: 'query', schema: { type: 'string', enum: ['today', 'week', 'month', 'year'] } },
        ],
        responses: { 200: { description: 'Dashboard summary data' } },
      },
    },

    '/dashboard/charts': {
      get: {
        tags: ['Dashboard'],
        summary: 'Time-series chart data',
        responses: { 200: { description: 'Chart series for volume/revenue over time' } },
      },
    },

    '/dashboard/recent-transactions': {
      get: {
        tags: ['Dashboard'],
        summary: 'Recent N transactions',
        parameters: [
          { name: 'limit', in: 'query', schema: { type: 'integer', default: 10 } },
        ],
        responses: { 200: { description: 'List of most recent transactions' } },
      },
    },

    '/dashboard/recent-audit-logs': {
      get: {
        tags: ['Dashboard'],
        summary: 'Recent N audit log entries',
        description: 'Roles: ADMIN, MANAGER, AUDITOR',
        responses: { 200: { description: 'Audit log entries' } },
      },
    },

    // ═══════════════════════════════════════════════════════
    // REPORTS
    // ═══════════════════════════════════════════════════════

    '/reports/daily': {
      get: {
        tags: ['Reports'],
        summary: 'Single-day summary & hourly breakdown',
        parameters: [
          { name: 'date', in: 'query', required: true, schema: { type: 'string', format: 'date' } },
        ],
        responses: { 200: { description: 'Daily report data' } },
      },
    },

    '/reports/monthly': {
      get: {
        tags: ['Reports'],
        summary: 'Single-month summary & daily breakdown',
        parameters: [
          { name: 'year', in: 'query', required: true, schema: { type: 'integer' } },
          { name: 'month', in: 'query', required: true, schema: { type: 'integer', minimum: 1, maximum: 12 } },
        ],
        responses: { 200: { description: 'Monthly report data' } },
      },
    },

    '/reports/custom': {
      get: {
        tags: ['Reports'],
        summary: 'Arbitrary date-range report',
        parameters: [
          { name: 'startDate', in: 'query', required: true, schema: { type: 'string', format: 'date' } },
          { name: 'endDate', in: 'query', required: true, schema: { type: 'string', format: 'date' } },
        ],
        responses: { 200: { description: 'Custom range report' } },
      },
    },

    '/reports/clients': {
      get: {
        tags: ['Reports'],
        summary: 'Paginated client list with top-N leaders',
        responses: { 200: { description: 'Client analytics' } },
      },
    },

    '/reports/transactions': {
      get: {
        tags: ['Reports'],
        summary: 'Paginated transaction list with totals',
        responses: { 200: { description: 'Transaction analytics' } },
      },
    },

    '/reports/audit': {
      get: {
        tags: ['Reports'],
        summary: 'Paginated audit log',
        description: 'Roles: ADMIN, AUDITOR',
        responses: { 200: { description: 'Audit log report' } },
      },
    },

    '/reports/statistics': {
      get: {
        tags: ['Reports'],
        summary: 'Aggregates, rates, busy periods & period comparisons',
        responses: { 200: { description: 'Statistical analytics' } },
      },
    },

    // ═══════════════════════════════════════════════════════
    // RECEIPTS
    // ═══════════════════════════════════════════════════════

    '/receipts': {
      get: {
        tags: ['Receipts'],
        summary: 'List receipts',
        description: 'Roles: ADMIN, MANAGER, AUDITOR',
        parameters: [
          { $ref: '#/components/parameters/PageParam' },
          { $ref: '#/components/parameters/LimitParam' },
        ],
        responses: { 200: { description: 'Paginated receipt list' } },
      },
    },

    '/receipts/ensure/{transactionId}': {
      post: {
        tags: ['Receipts'],
        summary: 'Create or fetch receipt for a transaction',
        description: 'Idempotent — returns the existing receipt if already generated. Roles: ADMIN, MANAGER, CASHIER',
        parameters: [
          { name: 'transactionId', in: 'path', required: true, schema: { type: 'string', format: 'uuid' } },
        ],
        responses: {
          200: { description: 'Receipt returned (already existed)' },
          201: { description: 'Receipt created' },
          403: { description: 'Insufficient role' },
          404: { description: 'Transaction not found' },
        },
      },
    },

    '/receipts/{receiptNumber}': {
      get: {
        tags: ['Receipts'],
        summary: 'Get receipt detail by receipt number',
        parameters: [
          { name: 'receiptNumber', in: 'path', required: true, schema: { type: 'string', example: 'RCP-2025-001234' } },
        ],
        responses: {
          200: { description: 'Full receipt detail' },
          404: { description: 'Receipt not found' },
        },
      },
    },

    '/receipts/{receiptNumber}/pdf': {
      post: {
        tags: ['Receipts'],
        summary: 'Generate PDF for receipt',
        parameters: [
          { name: 'receiptNumber', in: 'path', required: true, schema: { type: 'string' } },
        ],
        responses: {
          200: { description: 'PDF generated successfully' },
          404: { description: 'Receipt not found' },
        },
      },
      get: {
        tags: ['Receipts'],
        summary: 'Download PDF for receipt',
        parameters: [
          { name: 'receiptNumber', in: 'path', required: true, schema: { type: 'string' } },
        ],
        responses: {
          200: { description: 'PDF file stream', content: { 'application/pdf': {} } },
          404: { description: 'PDF not yet generated — call POST first' },
        },
      },
    },

    '/receipts/{receiptNumber}/qr': {
      post: {
        tags: ['Receipts'],
        summary: 'Generate QR code PNG for receipt',
        parameters: [
          { name: 'receiptNumber', in: 'path', required: true, schema: { type: 'string' } },
        ],
        responses: {
          200: { description: 'QR code generated — returns PNG URL path' },
        },
      },
    },

    '/receipts/{receiptNumber}/print': {
      post: {
        tags: ['Receipts'],
        summary: 'Log a print event for the receipt',
        parameters: [
          { name: 'receiptNumber', in: 'path', required: true, schema: { type: 'string' } },
        ],
        responses: { 200: { description: 'Print count incremented' } },
      },
    },

    '/receipts/{receiptNumber}/share': {
      post: {
        tags: ['Receipts'],
        summary: 'Log a share event for the receipt',
        parameters: [
          { name: 'receiptNumber', in: 'path', required: true, schema: { type: 'string' } },
        ],
        responses: { 200: { description: 'Share count incremented' } },
      },
    },

    '/receipts/transactions/{txnId}/attachments': {
      post: {
        tags: ['Receipts'],
        summary: 'Upload attachment for a transaction',
        description: 'Roles: ADMIN, MANAGER, CASHIER. Multipart/form-data, field name: `file`',
        parameters: [
          { name: 'txnId', in: 'path', required: true, schema: { type: 'string', format: 'uuid' } },
        ],
        requestBody: {
          required: true,
          content: {
            'multipart/form-data': {
              schema: {
                type: 'object',
                properties: {
                  file: { type: 'string', format: 'binary' },
                },
              },
            },
          },
        },
        responses: {
          201: { description: 'File uploaded' },
          400: { description: 'No file provided or invalid file type' },
        },
      },
      get: {
        tags: ['Receipts'],
        summary: 'List attachments for a transaction',
        parameters: [
          { name: 'txnId', in: 'path', required: true, schema: { type: 'string', format: 'uuid' } },
        ],
        responses: { 200: { description: 'Attachment list' } },
      },
    },

    '/receipts/attachments/{attachmentId}': {
      get: {
        tags: ['Receipts'],
        summary: 'Download an attachment',
        parameters: [
          { name: 'attachmentId', in: 'path', required: true, schema: { type: 'string', format: 'uuid' } },
        ],
        responses: {
          200: { description: 'File stream' },
          404: { description: 'Attachment not found' },
        },
      },
      delete: {
        tags: ['Receipts'],
        summary: 'Delete an attachment',
        description: 'Roles: ADMIN, MANAGER',
        parameters: [
          { name: 'attachmentId', in: 'path', required: true, schema: { type: 'string', format: 'uuid' } },
        ],
        responses: {
          200: { description: 'Attachment deleted' },
          403: { description: 'Insufficient role' },
          404: { description: 'Attachment not found' },
        },
      },
    },

    // ═══════════════════════════════════════════════════════
    // VERIFICATION
    // ═══════════════════════════════════════════════════════

    '/verification': {
      get: {
        tags: ['Verification'],
        summary: 'Paginated verification audit log',
        parameters: [
          { $ref: '#/components/parameters/PageParam' },
          { $ref: '#/components/parameters/LimitParam' },
          { name: 'receiptNumber', in: 'query', schema: { type: 'string' } },
          { name: 'result', in: 'query', schema: { type: 'string', enum: ['VALID', 'TAMPERED', 'NOT_FOUND'] } },
        ],
        responses: { 200: { description: 'Verification log entries' } },
      },
    },

    '/verification/{receiptNumber}': {
      get: {
        tags: ['Verification'],
        summary: 'Enriched verification detail for a receipt',
        parameters: [
          { name: 'receiptNumber', in: 'path', required: true, schema: { type: 'string' } },
        ],
        responses: {
          200: { description: 'Full verification result with integrity + receipt + transaction data' },
          404: { description: 'Receipt not found' },
        },
      },
    },
  },
};

// Public verify endpoint is mounted at /api/verify (outside the
// versioned prefix) so we document it separately for display purposes.
spec['x-public-endpoints'] = [
  {
    method: 'GET',
    path: '/api/verify/:receipt',
    summary: 'Public receipt verification (no auth required)',
    description:
      'Verifies a receipt number against the hash chain and returns ' +
      'tamper status. Used by verify.html and QR scanner flows.',
  },
];

module.exports = spec;
