/**
 * src/middlewares/authorize.middleware.js
 * ────────────────────────────────────────────────────────────────
 * Role-based access control (RBAC) middleware factory.
 *
 * Must be applied AFTER the `authenticate` middleware (which sets
 * `req.user`).  Calling `authorize` without `authenticate` first
 * will always throw 403 because `req.user` will be undefined.
 *
 * Usage — allow a single role:
 *   router.post('/users', authenticate, authorize(ROLES.ADMIN), createUser);
 *
 * Usage — allow several roles:
 *   router.get('/reports', authenticate, authorize(ROLES.ADMIN, ROLES.MANAGER), getReport);
 *
 * Errors thrown:
 *   403 — authenticated but lacking the required role
 * ────────────────────────────────────────────────────────────────
 */

const ApiError = require('../utils/ApiError');
const { ROLES } = require('../constants/roles');

/**
 * Factory function — returns Express middleware that permits only
 * users whose role is in the provided allow-list.
 *
 * @param {...string} allowedRoles  One or more values from `ROLES`.
 * @returns {import('express').RequestHandler}
 */
function authorize(...allowedRoles) {
  if (allowedRoles.length === 0) {
    throw new Error('authorize() requires at least one role argument');
  }

  // Validate that only known roles are passed (catches typos at boot time).
  const knownRoles = Object.values(ROLES);
  for (const role of allowedRoles) {
    if (!knownRoles.includes(role)) {
      throw new Error(`authorize(): unknown role "${role}"`);
    }
  }

  return (req, _res, next) => {
    if (!req.user) {
      // Developer misuse: authorize called without authenticate.
      return next(new ApiError(401, 'Authentication required.'));
    }

    if (!allowedRoles.includes(req.user.role)) {
      return next(
        new ApiError(
          403,
          `Access denied. Required role(s): ${allowedRoles.join(', ')}. Your role: ${req.user.role}.`,
        ),
      );
    }

    return next();
  };
}

module.exports = authorize;
