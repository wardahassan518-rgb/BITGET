/**
 * src/middlewares/error.middleware.js
 * ────────────────────────────────────────────────────────────────
 * Single place where every error in the app ends up — thrown
 * ApiErrors, unexpected exceptions, Prisma errors, Zod errors that
 * slipped through, etc. Must be registered LAST in `app.js`, after
 * all routes.
 *
 * Response shape:
 *   { success: false, message, details? }
 * Stack traces are only included outside production.
 * ────────────────────────────────────────────────────────────────
 */

const config = require('../config/env.config');
const logger = require('../utils/logger');
const ApiError = require('../utils/ApiError');

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  let { statusCode, message, details } = normalizeError(err);

  const logPayload = {
    requestId: req.id,
    method: req.method,
    path: req.originalUrl,
    statusCode,
  };

  if (statusCode >= 500) {
    logger.error(`${message}`, { ...logPayload, stack: err.stack });
  } else {
    logger.warn(`${message}`, logPayload);
  }

  const body = { success: false, message };
  if (details) body.details = details;
  if (!config.isProduction && statusCode >= 500) body.stack = err.stack;
  if (req.id) body.requestId = req.id;

  res.status(statusCode).json(body);
}

function normalizeError(err) {
  if (err instanceof ApiError) {
    return { statusCode: err.statusCode, message: err.message, details: err.details };
  }

  // JWT errors (jsonwebtoken library).
  if (err.name === 'TokenExpiredError') {
    return { statusCode: 401, message: 'Token has expired', details: null };
  }
  if (err.name === 'JsonWebTokenError') {
    return { statusCode: 401, message: 'Invalid token', details: null };
  }
  if (err.name === 'NotBeforeError') {
    return { statusCode: 401, message: 'Token not yet active', details: null };
  }

  // Prisma "record not found" / known request errors get a friendlier status.
  if (err.code === 'P2025') {
    return { statusCode: 404, message: 'Resource not found', details: null };
  }
  if (err.code === 'P2002') {
    return {
      statusCode: 409,
      message: 'A record with this value already exists',
      details: err.meta,
    };
  }

  // Multer file-size/type errors.
  if (err.name === 'MulterError') {
    return { statusCode: 400, message: err.message, details: null };
  }

  // Fallback: unexpected/programmer error.
  return {
    statusCode: err.statusCode || 500,
    message: err.message || 'Internal Server Error',
    details: null,
  };
}

module.exports = errorHandler;
