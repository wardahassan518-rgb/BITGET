/**
 * src/middlewares/requestId.middleware.js
 * ────────────────────────────────────────────────────────────────
 * Attaches a unique ID to every incoming request (`req.id`) and
 * echoes it back as the `X-Request-Id` response header. Every log
 * line written during that request (via `requestLogger.middleware`
 * or manual `logger.info(..., { requestId: req.id })` calls) can
 * then be correlated back to a single HTTP call — invaluable once
 * multiple services/controllers are involved in later phases.
 * ────────────────────────────────────────────────────────────────
 */

const crypto = require('crypto');

function requestId(req, res, next) {
  const incomingId = req.headers['x-request-id'];
  req.id = incomingId || crypto.randomUUID();
  res.setHeader('X-Request-Id', req.id);
  next();
}

module.exports = requestId;
