/**
 * src/middlewares/authenticate.middleware.js
 * ────────────────────────────────────────────────────────────────
 * Verifies the JWT access token on every protected route.
 *
 * On success, attaches a `req.user` object so downstream controllers
 * and the `authorize` middleware can read identity/role without
 * hitting the database a second time.
 *
 * Expects the token in the `Authorization: Bearer <token>` header.
 *
 * Errors thrown:
 *   401 — missing token, expired token, malformed token
 *   403 — account deactivated
 * ────────────────────────────────────────────────────────────────
 */

const { verifyAccessToken } = require('../utils/jwt.util');
const ApiError = require('../utils/ApiError');
const userRepository = require('../repositories/user.repository');
const { AUTH } = require('../constants/auth');

/**
 * Express middleware. Use on any route that requires authentication:
 *
 *   router.get('/me', authenticate, authController.me);
 *
 * @type {import('express').RequestHandler}
 */
async function authenticate(req, res, next) {
  try {
    // ── 1. Extract token ──────────────────────────────────────
    const authHeader = req.headers.authorization ?? '';

    if (!authHeader.startsWith(`${AUTH.BEARER_SCHEME} `)) {
      throw new ApiError(401, 'Authentication required. Provide a Bearer token.');
    }

    const token = authHeader.slice(AUTH.BEARER_SCHEME.length + 1);

    if (!token) {
      throw new ApiError(401, 'Authentication required. Token is empty.');
    }

    // ── 2. Verify signature + expiry ──────────────────────────
    let payload;
    try {
      payload = verifyAccessToken(token);
    } catch (err) {
      if (err.name === 'TokenExpiredError') {
        throw new ApiError(401, 'Access token has expired. Please refresh your session.');
      }
      throw new ApiError(401, 'Invalid access token.');
    }

    // ── 3. Validate payload shape ─────────────────────────────
    if (!payload.sub || !payload.role || !payload.sessionId) {
      throw new ApiError(401, 'Malformed token payload.');
    }

    // ── 4. Active-account guard ───────────────────────────────
    // Lightweight check: only queries users table (no session join).
    // Full session validity is checked on the /auth/refresh route.
    const user = await userRepository.findById(payload.sub);
    if (!user || !user.isActive) {
      throw new ApiError(403, 'Your account has been deactivated. Contact an administrator.');
    }

    // ── 5. Attach identity to request ─────────────────────────
    req.user = {
      id: payload.sub,
      email: payload.email,
      role: payload.role,
      sessionId: payload.sessionId,
    };

    return next();
  } catch (err) {
    return next(err);
  }
}

module.exports = authenticate;
