/**
 * src/middlewares/validate.middleware.js
 * ────────────────────────────────────────────────────────────────
 * Generic factory that turns any Zod schema into Express middleware.
 *
 * Usage (future phase):
 *   router.get(
 *     '/clients/:id',
 *     validate(idParamSchema, 'params'),
 *     clientController.getById,
 *   );
 * ────────────────────────────────────────────────────────────────
 */

const ApiError = require('../utils/ApiError');

/**
 * @param {import('zod').ZodSchema} schema
 * @param {'body'|'query'|'params'} [source='body']
 */
function validate(schema, source = 'body') {
  return (req, res, next) => {
    const result = schema.safeParse(req[source]);

    if (!result.success) {
      return next(
        new ApiError(422, 'Validation failed', {
          details: result.error.flatten().fieldErrors,
        }),
      );
    }

    req[source] = result.data;
    return next();
  };
}

module.exports = validate;
