/**
 * src/middlewares/notFound.middleware.js
 * ────────────────────────────────────────────────────────────────
 * Catches any request that didn't match a route and forwards a 404
 * ApiError to the global error handler, instead of Express's default
 * plain-text "Cannot GET /foo" response.
 * ────────────────────────────────────────────────────────────────
 */

const ApiError = require('../utils/ApiError');

function notFound(req, res, next) {
  next(new ApiError(404, `Route not found: ${req.method} ${req.originalUrl}`));
}

module.exports = notFound;
