/**
 * src/middlewares/requestLogger.middleware.js
 * ────────────────────────────────────────────────────────────────
 * HTTP access logging via morgan, piped into Winston (so access
 * logs end up in the same rotated files as everything else instead
 * of a separate stream).
 * ────────────────────────────────────────────────────────────────
 */

const morgan = require('morgan');
const config = require('../config/env.config');
const logger = require('../utils/logger');

morgan.token('id', (req) => req.id);

const format = config.isProduction
  ? ':id :remote-addr :method :url :status :res[content-length] - :response-time ms'
  : ':id :method :url :status :response-time ms';

const requestLogger = morgan(format, { stream: logger.stream });

module.exports = requestLogger;
