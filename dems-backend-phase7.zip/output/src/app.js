/**
 * src/app.js
 * ────────────────────────────────────────────────────────────────
 * Express application configuration.
 *
 * Order matters here:
 *   1. Trust proxy (if behind a load balancer/reverse proxy)
 *   2. Request ID                → every request gets traceable id
 *   3. Security headers (Helmet)
 *   4. CORS
 *   5. Compression
 *   6. HTTP parameter pollution guard
 *   7. Body parsers (JSON / urlencoded)
 *   8. HTTP access logging
 *   9. Global rate limiter
 *  10. API routes (mounted at config.apiPrefix)
 *  11. 404 handler
 *  12. Global error handler           ← must be LAST
 * ────────────────────────────────────────────────────────────────
 */

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const hpp = require('hpp');
const cookieParser = require('cookie-parser');

const config = require('./config/env.config');
const corsOptions = require('./config/cors.config');
const helmetOptions = require('./config/helmet.config');
const globalRateLimiter = require('./config/rateLimiter.config');

const requestId = require('./middlewares/requestId.middleware');
const requestLogger = require('./middlewares/requestLogger.middleware');
const notFound = require('./middlewares/notFound.middleware');
const errorHandler = require('./middlewares/error.middleware');

const routes = require('./routes');
const { publicIntegrityRouter } = require('./routes/integrity.routes');

// ── Phase 7: Swagger / OpenAPI docs ───────────────────────────
// Served at /api-docs — disabled in test to keep test output clean.
const swaggerUi   = require('swagger-ui-express');
const openApiSpec = require('./docs/openapi');

const app = express();

// Required for correct client IPs / secure cookies behind a reverse
// proxy (Nginx, AWS ALB, etc.) in production.
if (config.security.trustProxy) {
  app.set('trust proxy', 1);
}

app.use(requestId);
app.use(helmet(helmetOptions));
app.use(cors(corsOptions));
app.use(compression());
app.use(hpp());
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use(cookieParser());
app.use(requestLogger);
app.use(globalRateLimiter);

// ── Swagger UI ──────────────────────────────────────────────
// Served at /api-docs in non-test environments.
// Does not interfere with any API routes.
if (!config.isTest) {
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(openApiSpec, {
    customSiteTitle: 'DEMS API Docs',
    swaggerOptions: { persistAuthorization: true },
  }));
}

app.use(config.apiPrefix, routes);

// Phase 4 — Public receipt verification endpoint.
// Mounted at /api/verify (outside the versioned prefix) so the URL is
// exactly GET /api/verify/:receipt as required by the specification.
// No authentication is required — this is the public-facing tamper
// detection endpoint consumed by verify.html and QR scanner flows.
app.use('/api/verify', publicIntegrityRouter);

// Convenience root endpoint so hitting the bare host isn't a confusing 404.
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'DEMS backend — Phase 6 (Verification & Receipt)',
    apiPrefix: config.apiPrefix,
    health:       `${config.apiPrefix}/health`,
    verify:       '/api/verify/:receipt',
    receipts:     `${config.apiPrefix}/receipts`,
    verification: `${config.apiPrefix}/verification`,
  });
});

app.use(notFound);
app.use(errorHandler);

module.exports = app;
