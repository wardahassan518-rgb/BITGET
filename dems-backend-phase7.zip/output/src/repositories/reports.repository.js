/**
 * src/repositories/reports.repository.js
 * ────────────────────────────────────────────────────────────────
 * Data-access layer for the Reports module (Phase 5).
 *
 * Responsibilities:
 *   • Paginated transaction lists with rich filtering for the
 *     Transaction Report endpoint.
 *   • Aggregate totals (sum, count, avg) scoped to any filter set.
 *   • Per-day breakdown within a month for the Monthly Report.
 *   • Client leaderboard / ranked list for the Client Report.
 *   • Paginated audit-log retrieval for the Audit Report.
 *   • Statistical queries (top currencies, busiest hours, etc.)
 *     for the Statistics endpoint.
 *
 * All filtering decisions are made in the service layer, which
 * passes pre-built `where` objects down here.  This file only
 * executes queries.
 * ────────────────────────────────────────────────────────────────
 */

const { prisma } = require('../database/prisma.client');
const { Prisma } = require('@prisma/client');

class ReportsRepository {

  // ── Transaction Report ─────────────────────────────────────────

  /**
   * Paginated list of transactions matching a pre-built filter.
   *
   * @param {{ where: object, skip: number, take: number, orderBy: object }} params
   * @returns {Promise<import('@prisma/client').Transaction[]>}
   */
  getTransactionList({ where, skip, take, orderBy }) {
    return prisma.transaction.findMany({
      where,
      skip,
      take,
      orderBy,
      include: {
        client: {
          select: { id: true, fullName: true, cnic: true, isVerified: true, isFlagged: true },
        },
      },
    });
  }

  /**
   * Count of transactions matching a pre-built filter (for pagination).
   *
   * @param {object} where
   * @returns {Promise<number>}
   */
  countTransactions(where) {
    return prisma.transaction.count({ where });
  }

  /**
   * Aggregate PKR/USDT volume and profit for any where clause.
   *
   * @param {object} where
   * @returns {Promise<{
   *   count: number,
   *   totalPkr: Prisma.Decimal|null,
   *   totalUsdt: Prisma.Decimal|null,
   *   totalProfit: Prisma.Decimal|null,
   *   avgRate: Prisma.Decimal|null,
   *   maxPkr: Prisma.Decimal|null,
   *   minPkr: Prisma.Decimal|null,
   * }>}
   */
  async getTransactionAggregates(where) {
    const agg = await prisma.transaction.aggregate({
      where,
      _count: { id: true },
      _sum:   { amountPkr: true, amountUsdt: true, profitPkr: true },
      _avg:   { exchangeRate: true, amountPkr: true },
      _max:   { amountPkr: true },
      _min:   { amountPkr: true },
    });

    return {
      count:       agg._count.id,
      totalPkr:    agg._sum.amountPkr,
      totalUsdt:   agg._sum.amountUsdt,
      totalProfit: agg._sum.profitPkr,
      avgRate:     agg._avg.exchangeRate,
      avgPkr:      agg._avg.amountPkr,
      maxPkr:      agg._max.amountPkr,
      minPkr:      agg._min.amountPkr,
    };
  }

  /**
   * Buy vs Sell split for a given where clause.
   *
   * @param {object} where - base where (without txnType)
   * @returns {Promise<{ buy: object, sell: object }>}
   */
  async getTypeSplit(where) {
    const [buyAgg, sellAgg] = await Promise.all([
      prisma.transaction.aggregate({
        where: { ...where, txnType: 'BUY' },
        _count: { id: true },
        _sum:   { amountPkr: true, amountUsdt: true, profitPkr: true },
        _avg:   { exchangeRate: true },
      }),
      prisma.transaction.aggregate({
        where: { ...where, txnType: 'SELL' },
        _count: { id: true },
        _sum:   { amountPkr: true, amountUsdt: true, profitPkr: true },
        _avg:   { exchangeRate: true },
      }),
    ]);

    return {
      buy: {
        count:      buyAgg._count.id,
        totalPkr:   buyAgg._sum.amountPkr,
        totalUsdt:  buyAgg._sum.amountUsdt,
        totalProfit:buyAgg._sum.profitPkr,
        avgRate:    buyAgg._avg.exchangeRate,
      },
      sell: {
        count:      sellAgg._count.id,
        totalPkr:   sellAgg._sum.amountPkr,
        totalUsdt:  sellAgg._sum.amountUsdt,
        totalProfit:sellAgg._sum.profitPkr,
        avgRate:    sellAgg._avg.exchangeRate,
      },
    };
  }

  // ── Daily breakdown (per-hour) ─────────────────────────────────

  /**
   * Per-hour breakdown for a single calendar day.
   * Returns a sparse array — hours with no transactions are omitted.
   *
   * @param {Date} dayStart
   * @param {Date} dayEnd
   * @returns {Promise<Array>}
   */
  getDailyHourlyBreakdown(dayStart, dayEnd) {
    return prisma.$queryRaw`
      SELECT
        EXTRACT(HOUR FROM "timestamp")::int  AS hour,
        COUNT(*)::int                        AS count,
        COALESCE(SUM("amount_pkr"),  0)      AS pkr_volume,
        COALESCE(SUM("amount_usdt"), 0)      AS usdt_volume,
        COALESCE(SUM("profit_pkr"),  0)      AS profit_pkr,
        COUNT(*) FILTER (WHERE "txn_type" = 'BUY')::int  AS buy_count,
        COUNT(*) FILTER (WHERE "txn_type" = 'SELL')::int AS sell_count
      FROM transactions
      WHERE
        "is_void"   = false
        AND "timestamp" >= ${dayStart}
        AND "timestamp" <= ${dayEnd}
      GROUP BY EXTRACT(HOUR FROM "timestamp")
      ORDER BY hour ASC
    `;
  }

  // ── Monthly breakdown (per-day) ────────────────────────────────

  /**
   * Per-day breakdown within a calendar month.
   *
   * @param {Date} monthStart
   * @param {Date} monthEnd
   * @returns {Promise<Array>}
   */
  getMonthlyDailyBreakdown(monthStart, monthEnd) {
    return prisma.$queryRaw`
      SELECT
        DATE_TRUNC('day', "timestamp")  AS day,
        COUNT(*)::int                   AS count,
        COALESCE(SUM("amount_pkr"),  0) AS pkr_volume,
        COALESCE(SUM("amount_usdt"), 0) AS usdt_volume,
        COALESCE(SUM("profit_pkr"),  0) AS profit_pkr,
        COUNT(*) FILTER (WHERE "txn_type" = 'BUY')::int  AS buy_count,
        COUNT(*) FILTER (WHERE "txn_type" = 'SELL')::int AS sell_count
      FROM transactions
      WHERE
        "is_void"   = false
        AND "timestamp" >= ${monthStart}
        AND "timestamp" <= ${monthEnd}
      GROUP BY DATE_TRUNC('day', "timestamp")
      ORDER BY day ASC
    `;
  }

  /**
   * Per-day breakdown for a custom date range.
   *
   * @param {Date} from
   * @param {Date} to
   * @param {object} [extraWhere] - optional extra filter (e.g. txnType)
   * @returns {Promise<Array>}
   */
  getCustomDailyBreakdown(from, to) {
    return prisma.$queryRaw`
      SELECT
        DATE_TRUNC('day', "timestamp")  AS day,
        COUNT(*)::int                   AS count,
        COALESCE(SUM("amount_pkr"),  0) AS pkr_volume,
        COALESCE(SUM("amount_usdt"), 0) AS usdt_volume,
        COALESCE(SUM("profit_pkr"),  0) AS profit_pkr,
        COUNT(*) FILTER (WHERE "txn_type" = 'BUY')::int  AS buy_count,
        COUNT(*) FILTER (WHERE "txn_type" = 'SELL')::int AS sell_count
      FROM transactions
      WHERE
        "is_void"   = false
        AND "timestamp" >= ${from}
        AND "timestamp" <= ${to}
      GROUP BY DATE_TRUNC('day', "timestamp")
      ORDER BY day ASC
    `;
  }

  // ── Client Report ──────────────────────────────────────────────

  /**
   * Paginated client list with optional search/filter.
   *
   * @param {{ where: object, skip: number, take: number, orderBy: object }} params
   * @returns {Promise<import('@prisma/client').Client[]>}
   */
  getClientList({ where, skip, take, orderBy }) {
    return prisma.client.findMany({
      where,
      skip,
      take,
      orderBy,
      select: {
        id:             true,
        fullName:       true,
        cnic:           true,
        phone:          true,
        isVerified:     true,
        isFlagged:      true,
        totalTxns:      true,
        totalVolumePkr: true,
        firstTxnDate:   true,
        lastTxnDate:    true,
        createdAt:      true,
      },
    });
  }

  /**
   * @param {object} where
   * @returns {Promise<number>}
   */
  countClients(where) {
    return prisma.client.count({ where });
  }

  /**
   * Top N clients by PKR volume in a date range.
   * Uses a raw query so we can scope volume to the given window
   * rather than relying on the pre-aggregated `totalVolumePkr` field
   * (which is all-time).
   *
   * @param {Date}   from
   * @param {Date}   to
   * @param {number} limit
   * @returns {Promise<Array>}
   */
  getTopClientsByVolume(from, to, limit) {
    // Prisma raw doesn't support JS template `limit` directly in
    // the tagged template — wrap it in Prisma.sql.
    return prisma.$queryRaw`
      SELECT
        c.id,
        c.full_name    AS "fullName",
        c.cnic,
        c.phone,
        c.is_verified  AS "isVerified",
        c.is_flagged   AS "isFlagged",
        COUNT(t.id)::int                   AS txn_count,
        COALESCE(SUM(t.amount_pkr),  0)   AS pkr_volume,
        COALESCE(SUM(t.amount_usdt), 0)   AS usdt_volume,
        COUNT(*) FILTER (WHERE t.txn_type = 'BUY')::int  AS buy_count,
        COUNT(*) FILTER (WHERE t.txn_type = 'SELL')::int AS sell_count
      FROM clients c
      INNER JOIN transactions t ON t.client_id = c.id
      WHERE
        t.is_void   = false
        AND t.timestamp >= ${from}
        AND t.timestamp <= ${to}
      GROUP BY c.id, c.full_name, c.cnic, c.phone, c.is_verified, c.is_flagged
      ORDER BY pkr_volume DESC
      LIMIT ${limit}
    `;
  }

  // ── Audit Log Report ───────────────────────────────────────────

  /**
   * Paginated audit log with optional filters.
   *
   * @param {{ where: object, skip: number, take: number, orderBy: object }} params
   * @returns {Promise<import('@prisma/client').AuditLog[]>}
   */
  getAuditList({ where, skip, take, orderBy }) {
    return prisma.auditLog.findMany({
      where,
      skip,
      take,
      orderBy,
      include: {
        user: {
          select: { id: true, fullName: true, email: true, role: true },
        },
      },
    });
  }

  /**
   * @param {object} where
   * @returns {Promise<number>}
   */
  countAuditLogs(where) {
    return prisma.auditLog.count({ where });
  }

  /**
   * Action frequency breakdown — how many times each action type
   * appears in the given date window.
   *
   * @param {Date} from
   * @param {Date} to
   * @returns {Promise<Array<{ action: string, count: bigint }>>}
   */
  getActionFrequency(from, to) {
    return prisma.$queryRaw`
      SELECT
        action,
        COUNT(*)::int AS count
      FROM audit_log
      WHERE
        "timestamp" >= ${from}
        AND "timestamp" <= ${to}
      GROUP BY action
      ORDER BY count DESC
    `;
  }

  // ── Statistics ─────────────────────────────────────────────────

  /**
   * Busiest hour-of-day by transaction count in a date range.
   *
   * @param {Date} from
   * @param {Date} to
   * @returns {Promise<Array<{ hour: number, count: bigint }>>}
   */
  getBusiestHours(from, to) {
    return prisma.$queryRaw`
      SELECT
        EXTRACT(HOUR FROM "timestamp")::int AS hour,
        COUNT(*)::int                       AS count
      FROM transactions
      WHERE
        "is_void"   = false
        AND "timestamp" >= ${from}
        AND "timestamp" <= ${to}
      GROUP BY EXTRACT(HOUR FROM "timestamp")
      ORDER BY count DESC
      LIMIT 5
    `;
  }

  /**
   * Busiest day-of-week by transaction count in a date range.
   * 0=Sunday … 6=Saturday (PostgreSQL DOW convention).
   *
   * @param {Date} from
   * @param {Date} to
   * @returns {Promise<Array<{ dow: number, count: bigint }>>}
   */
  getBusiestDaysOfWeek(from, to) {
    return prisma.$queryRaw`
      SELECT
        EXTRACT(DOW FROM "timestamp")::int AS dow,
        COUNT(*)::int                      AS count
      FROM transactions
      WHERE
        "is_void"   = false
        AND "timestamp" >= ${from}
        AND "timestamp" <= ${to}
      GROUP BY EXTRACT(DOW FROM "timestamp")
      ORDER BY count DESC
    `;
  }

  /**
   * Min, max, avg exchange rate (buy and sell) over a period.
   *
   * @param {Date} from
   * @param {Date} to
   * @returns {Promise<{ buy: object, sell: object }>}
   */
  async getRateStats(from, to) {
    const base = { isVoid: false, timestamp: { gte: from, lte: to } };

    const [buyAgg, sellAgg] = await Promise.all([
      prisma.transaction.aggregate({
        where: { ...base, txnType: 'BUY' },
        _avg:  { exchangeRate: true },
        _max:  { exchangeRate: true },
        _min:  { exchangeRate: true },
      }),
      prisma.transaction.aggregate({
        where: { ...base, txnType: 'SELL' },
        _avg:  { exchangeRate: true },
        _max:  { exchangeRate: true },
        _min:  { exchangeRate: true },
      }),
    ]);

    return {
      buy: {
        avg: buyAgg._avg.exchangeRate,
        max: buyAgg._max.exchangeRate,
        min: buyAgg._min.exchangeRate,
      },
      sell: {
        avg: sellAgg._avg.exchangeRate,
        max: sellAgg._max.exchangeRate,
        min: sellAgg._min.exchangeRate,
      },
    };
  }

  /**
   * Month-over-month comparison: current period vs same period of previous year.
   *
   * @param {Date} from
   * @param {Date} to
   * @returns {Promise<{ current: object, previous: object }>}
   */
  async getPeriodComparison(from, to) {
    const durationMs = to.getTime() - from.getTime();
    const prevFrom   = new Date(from.getTime() - durationMs);
    const prevTo     = new Date(to.getTime()   - durationMs);

    const [current, previous] = await Promise.all([
      this.getTransactionAggregates({
        isVoid:    false,
        timestamp: { gte: from, lte: to },
      }),
      this.getTransactionAggregates({
        isVoid:    false,
        timestamp: { gte: prevFrom, lte: prevTo },
      }),
    ]);

    return { current, previous, prevFrom, prevTo };
  }

  /**
   * Verification log summary — counts by result type in a date range.
   *
   * @param {Date} from
   * @param {Date} to
   * @returns {Promise<Array<{ result: string, count: bigint }>>}
   */
  getVerificationSummary(from, to) {
    return prisma.$queryRaw`
      SELECT
        result::text,
        COUNT(*)::int AS count
      FROM verification_log
      WHERE
        "verified_at" >= ${from}
        AND "verified_at" <= ${to}
      GROUP BY result
    `;
  }
}

module.exports = new ReportsRepository();
