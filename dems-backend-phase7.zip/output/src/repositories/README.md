# Repositories Layer

Repositories are the **only** layer allowed to talk to Prisma directly.
They translate domain calls (`findByReceiptNumber('EXC-2026-000001')`)
into Prisma queries and return plain data — no HTTP concerns
(`req`/`res`), no validation, no business rules.

## Phase 1

Only `base.repository.js`: a generic CRUD wrapper around any Prisma
model delegate.

## Phase 2 (Authentication)

- `user.repository.js`
- `session.repository.js`

## Phase 3 (this phase) — Client & Transaction Management

- `client.repository.js` — CNIC lookup, search/list, and
  `recomputeStats()` (aggregates a client's linked transactions to
  refresh `totalTxns`/`totalVolumePkr`/`firstTxnDate`/`lastTxnDate`).
- `transaction.repository.js` — receipt-number lookup, search/list
  (with a thin client projection included), detail-by-id.

## Future phases

- `receipt.repository.js`
- `auditLog.repository.js` (currently written to directly via
  `prisma.auditLog` / the `writeAuditLog` helpers in each service —
  promote to a dedicated repository if audit-log *reads* grow beyond
  what the future Reports phase needs)
