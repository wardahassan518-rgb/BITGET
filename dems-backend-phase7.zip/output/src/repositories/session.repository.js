/**
 * src/repositories/session.repository.js
 * ────────────────────────────────────────────────────────────────
 * Data-access layer for the `sessions` table.
 * Handles all read/write operations for refresh-token sessions.
 *
 * The repository works exclusively with the SHA-256 *hash* of the
 * raw refresh token.  The plaintext JWT is never persisted — only
 * the hash is stored, so a database breach cannot yield usable tokens.
 * ────────────────────────────────────────────────────────────────
 */

const BaseRepository = require('./base.repository');
const { prisma } = require('../database/prisma.client');

class SessionRepository extends BaseRepository {
  constructor() {
    super(prisma.session);
  }

  /**
   * Look up a session by its token hash.
   *
   * @param {string} tokenHash
   * @returns {Promise<import('@prisma/client').Session | null>}
   */
  findByTokenHash(tokenHash) {
    return this.model.findUnique({ where: { tokenHash } });
  }

  /**
   * Create a new session record.
   *
   * @param {{ userId: string, tokenHash: string, expiresAt: Date, userAgent?: string, ipAddress?: string }} data
   * @returns {Promise<import('@prisma/client').Session>}
   */
  createSession({ userId, tokenHash, expiresAt, userAgent, ipAddress }) {
    return this.model.create({
      data: { userId, tokenHash, expiresAt, userAgent, ipAddress },
    });
  }

  /**
   * Mark a session as revoked (soft-delete; the row is kept for
   * audit purposes and cleaned up by a background job later).
   *
   * @param {string} id
   * @returns {Promise<import('@prisma/client').Session>}
   */
  revokeById(id) {
    return this.model.update({
      where: { id },
      data: { isRevoked: true },
    });
  }

  /**
   * Revoke all active sessions for a user (e.g. "logout everywhere").
   *
   * @param {string} userId
   * @returns {Promise<{ count: number }>}
   */
  revokeAllForUser(userId) {
    return this.model.updateMany({
      where: { userId, isRevoked: false },
      data: { isRevoked: true },
    });
  }

  /**
   * Replace an existing session's token hash (token rotation on refresh).
   *
   * @param {string} id
   * @param {{ tokenHash: string, expiresAt: Date }} data
   * @returns {Promise<import('@prisma/client').Session>}
   */
  rotateToken(id, { tokenHash, expiresAt }) {
    return this.model.update({
      where: { id },
      data: { tokenHash, expiresAt, isRevoked: false },
    });
  }
}

module.exports = new SessionRepository();
