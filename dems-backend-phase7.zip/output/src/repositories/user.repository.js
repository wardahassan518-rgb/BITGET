/**
 * src/repositories/user.repository.js
 * ────────────────────────────────────────────────────────────────
 * Data-access layer for the `users` table.
 * Extends BaseRepository (Phase 1) with User-specific queries.
 * Business logic (password hashing, token generation, lockout rules)
 * belongs in `services/auth.service.js` — NOT here.
 * ────────────────────────────────────────────────────────────────
 */

const BaseRepository = require('./base.repository');
const { prisma } = require('../database/prisma.client');

class UserRepository extends BaseRepository {
  constructor() {
    super(prisma.user);
  }

  /**
   * Find a user by email address (case-insensitive match handled at
   * the DB level because the `email` column stores lower-cased values
   * written by the auth service before persisting).
   *
   * @param {string} email
   * @returns {Promise<import('@prisma/client').User | null>}
   */
  findByEmail(email) {
    return this.model.findUnique({
      where: { email: email.toLowerCase().trim() },
    });
  }

  /**
   * Returns the user with only the safe-to-expose fields
   * (excludes passwordHash).
   *
   * @param {string} id
   * @returns {Promise<object | null>}
   */
  findByIdSafe(id) {
    return this.model.findUnique({
      where: { id },
      select: {
        id: true,
        fullName: true,
        email: true,
        role: true,
        isActive: true,
        lastLoginAt: true,
        createdAt: true,
        updatedAt: true,
      },
    });
  }

  /**
   * Stamps the `last_login_at` column after a successful login.
   *
   * @param {string} id
   * @returns {Promise<import('@prisma/client').User>}
   */
  stampLastLogin(id) {
    return this.model.update({
      where: { id },
      data: { lastLoginAt: new Date() },
    });
  }
}

module.exports = new UserRepository();
