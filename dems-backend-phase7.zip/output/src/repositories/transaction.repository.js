/**
 * src/repositories/transaction.repository.js
 * ────────────────────────────────────────────────────────────────
 * Data-access layer for the `transactions` table.
 * Extends BaseRepository with Transaction-specific lookups. Like
 * `client.repository.js`, search/filter/sort *decisions* belong to
 * `services/transaction.service.js` — this file just executes them.
 * ────────────────────────────────────────────────────────────────
 */

const BaseRepository = require('./base.repository');
const { prisma } = require('../database/prisma.client');

class TransactionRepository extends BaseRepository {
  constructor() {
    super(prisma.transaction);
  }

  /**
   * Find a transaction by its unique receipt number.
   *
   * @param {string} receiptNumber
   * @returns {Promise<import('@prisma/client').Transaction | null>}
   */
  findByReceiptNumber(receiptNumber) {
    return this.model.findUnique({ where: { receiptNumber } });
  }

  /**
   * List transactions matching a pre-built filter, with pagination + sort.
   * Includes a thin `client` projection so list/detail responses can
   * show current client verification status alongside the historical
   * snapshot (`clientName`/`clientCnic`) stored on the transaction itself.
   *
   * @param {{ where: object, skip: number, take: number, orderBy: object }} params
   * @returns {Promise<import('@prisma/client').Transaction[]>}
   */
  search({ where, skip, take, orderBy }) {
    return this.model.findMany({
      where,
      skip,
      take,
      orderBy,
      include: {
        client: {
          select: { id: true, fullName: true, cnic: true, isVerified: true, isFlagged: true },
        },
      },
    });
  }

  /**
   * Count transactions matching a pre-built filter (for pagination meta).
   *
   * @param {object} where
   * @returns {Promise<number>}
   */
  countMatching(where) {
    return this.model.count({ where });
  }

  /**
   * Find a transaction by id with the same client projection as `search()`.
   *
   * @param {string} id
   * @returns {Promise<import('@prisma/client').Transaction | null>}
   */
  findByIdWithClient(id) {
    return this.model.findUnique({
      where: { id },
      include: {
        client: {
          select: { id: true, fullName: true, cnic: true, isVerified: true, isFlagged: true },
        },
      },
    });
  }
}

module.exports = new TransactionRepository();
