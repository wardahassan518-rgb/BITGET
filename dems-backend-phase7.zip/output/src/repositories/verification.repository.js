/**
 * src/repositories/verification.repository.js
 * ────────────────────────────────────────────────────────────────
 * Data-access layer for the VerificationLog model (Phase 6).
 *
 * Note: The IntegrityRepository (Phase 4) also writes VerificationLog
 * rows.  This repository provides the READ side needed by the Phase 6
 * Verification module — history lookup, stats, recent scans — without
 * touching any Phase 4 code.
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const BaseRepository = require('./base.repository');
const { prisma }     = require('../database/prisma.client');
const { Prisma }     = require('@prisma/client');

class VerificationRepository extends BaseRepository {
  constructor() {
    super(prisma.verificationLog);
  }

  // ── Writes ─────────────────────────────────────────────────────

  /**
   * Persist one verification-log entry.
   * Accepts either the shared prisma client or a transaction handle
   * so the write can be made atomic with an audit-log insert.
   *
   * @param {import('@prisma/client').PrismaClient | object} db
   * @param {{
   *   receiptNumber: string,
   *   result:        'ORIGINAL' | 'TAMPERED' | 'NOT_FOUND',
   *   verifierIp?:   string | null,
   *   userAgent?:    string | null,
   * }} entry
   * @returns {Promise<import('@prisma/client').VerificationLog>}
   */
  writeLog(db, { receiptNumber, result, verifierIp, userAgent }) {
    return db.verificationLog.create({
      data: {
        receiptNumber,
        result,
        verifierIp: verifierIp ?? null,
        userAgent:  userAgent  ?? null,
      },
    });
  }

  // ── Reads ──────────────────────────────────────────────────────

  /**
   * Get the most recent N verification log entries for a receipt number.
   *
   * @param {string} receiptNumber
   * @param {number} [limit=50]
   * @returns {Promise<import('@prisma/client').VerificationLog[]>}
   */
  getHistory(receiptNumber, limit = 50) {
    return this.model.findMany({
      where:   { receiptNumber },
      orderBy: { verifiedAt: 'desc' },
      take:    limit,
    });
  }

  /**
   * Count verification attempts by result type for a given receipt.
   *
   * @param {string} receiptNumber
   * @returns {Promise<Array<{ result: string, count: bigint }>>}
   */
  getResultCounts(receiptNumber) {
    return prisma.$queryRaw`
      SELECT result::text, COUNT(*)::int AS count
      FROM verification_log
      WHERE receipt_number = ${receiptNumber}
      GROUP BY result
      ORDER BY count DESC
    `;
  }

  /**
   * Paginated list of verification log entries with optional filters.
   *
   * @param {{ where: object, skip: number, take: number }} params
   * @returns {Promise<import('@prisma/client').VerificationLog[]>}
   */
  list({ where = {}, skip = 0, take = 20 }) {
    return this.model.findMany({
      where,
      skip,
      take,
      orderBy: { verifiedAt: 'desc' },
    });
  }

  /**
   * Count log entries matching the given where clause.
   *
   * @param {object} where
   * @returns {Promise<number>}
   */
  countList(where = {}) {
    return this.model.count({ where });
  }

  /**
   * Result-type aggregate over a date window.
   *
   * @param {Date} from
   * @param {Date} to
   * @returns {Promise<Array<{ result: string, count: number }>>}
   */
  getSummaryByResult(from, to) {
    return prisma.$queryRaw`
      SELECT result::text, COUNT(*)::int AS count
      FROM verification_log
      WHERE verified_at >= ${from}
        AND verified_at <= ${to}
      GROUP BY result
      ORDER BY count DESC
    `;
  }

  /**
   * Most-verified receipt numbers in a date window.
   *
   * @param {Date}   from
   * @param {Date}   to
   * @param {number} [limit=10]
   * @returns {Promise<Array<{ receipt_number: string, count: number, last_result: string }>>}
   */
  getTopVerified(from, to, limit = 10) {
    return prisma.$queryRaw`
      SELECT
        receipt_number,
        COUNT(*)::int                                             AS count,
        (ARRAY_AGG(result::text ORDER BY verified_at DESC))[1]  AS last_result
      FROM verification_log
      WHERE verified_at >= ${from}
        AND verified_at <= ${to}
      GROUP BY receipt_number
      ORDER BY count DESC
      LIMIT ${Prisma.sql`${limit}`}
    `;
  }
}

module.exports = new VerificationRepository();
