/**
 * src/repositories/integrity.repository.js
 * ────────────────────────────────────────────────────────────────
 * Data-access layer for the Integrity Engine (Phase 4).
 *
 * Responsibilities:
 *   • Write VerificationLog rows (one per public or authenticated
 *     verification call — the audit trail).
 *   • Fetch the tail of the hash chain so the Integrity Service can
 *     determine the correct chainIndex and prevHash for a new seal.
 *   • Retrieve a single Transaction by receipt number for verification.
 *   • Count / iterate the full chain for chain-integrity scans.
 *
 * This repository intentionally owns NO business logic — no hash
 * computation, no chain rules.  It only reads and writes data.
 * ────────────────────────────────────────────────────────────────
 */

const BaseRepository = require('./base.repository');
const { prisma } = require('../database/prisma.client');

class IntegrityRepository extends BaseRepository {
  constructor() {
    // BaseRepository wraps prisma.verificationLog
    super(prisma.verificationLog);
  }

  // ────────────────────────────────────────────────────────────
  //  Verification Log writes
  // ────────────────────────────────────────────────────────────

  /**
   * Persist one verification attempt.  Accepts either the shared
   * Prisma client or an active `$transaction` handle so the insert
   * can be made atomic with the audit-log write when needed.
   *
   * @param {import('@prisma/client').PrismaClient | import('@prisma/client').Prisma.TransactionClient} db
   * @param {{
   *   receiptNumber: string,
   *   result:        import('@prisma/client').VerificationResult,
   *   verifierIp?:   string | null,
   *   userAgent?:    string | null,
   * }} entry
   * @returns {Promise<import('@prisma/client').VerificationLog>}
   */
  async writeVerificationLog(db, { receiptNumber, result, verifierIp, userAgent }) {
    return db.verificationLog.create({
      data: {
        receiptNumber,
        result,
        verifierIp:  verifierIp  ?? null,
        userAgent:   userAgent   ?? null,
      },
    });
  }

  /**
   * Return the most recent VerificationLog rows for a given receipt
   * number, newest first.  Used by authenticated detail views.
   *
   * @param {string} receiptNumber
   * @param {number} [limit=20]
   * @returns {Promise<import('@prisma/client').VerificationLog[]>}
   */
  findVerificationHistory(receiptNumber, limit = 20) {
    return prisma.verificationLog.findMany({
      where:   { receiptNumber },
      orderBy: { verifiedAt: 'desc' },
      take:    limit,
    });
  }

  // ────────────────────────────────────────────────────────────
  //  Chain tail — used when sealing a new transaction
  // ────────────────────────────────────────────────────────────

  /**
   * Returns the highest `chainIndex` transaction that has already been
   * sealed (i.e. `hash IS NOT NULL`).  The service uses this to compute
   * the next chainIndex and to obtain the prevHash for the new record.
   *
   * Uses `tx` (a Prisma transaction handle) so the tail read and the
   * subsequent UPDATE are executed inside the same serialisable unit
   * and cannot race against a concurrent seal.
   *
   * @param {import('@prisma/client').Prisma.TransactionClient} tx
   * @returns {Promise<import('@prisma/client').Transaction | null>}
   */
  findChainTail(tx) {
    return tx.transaction.findFirst({
      where:   { hash: { not: null } },
      orderBy: { chainIndex: 'desc' },
      select:  {
        id:         true,
        chainIndex: true,
        hash:       true,
      },
    });
  }

  // ────────────────────────────────────────────────────────────
  //  Transaction look-ups for verification
  // ────────────────────────────────────────────────────────────

  /**
   * Fetch a full transaction row by receipt number.  Returns null if
   * no transaction exists with that receipt number.
   *
   * @param {string} receiptNumber
   * @returns {Promise<import('@prisma/client').Transaction | null>}
   */
  findTransactionByReceipt(receiptNumber) {
    return prisma.transaction.findUnique({
      where:   { receiptNumber },
      include: {
        client: {
          select: { id: true, fullName: true, isVerified: true, isFlagged: true },
        },
      },
    });
  }

  /**
   * Return every sealed transaction ordered by chainIndex ascending.
   * Used by the chain-integrity scan (authenticated endpoint).
   *
   * NOTE: For large chains call this in batches; for Phase 4 a full
   * scan is acceptable given typical exchange transaction volumes.
   *
   * @param {{ skip?: number, take?: number }} [pagination]
   * @returns {Promise<import('@prisma/client').Transaction[]>}
   */
  findChain({ skip = 0, take = 500 } = {}) {
    return prisma.transaction.findMany({
      where:   { hash: { not: null } },
      orderBy: { chainIndex: 'asc' },
      skip,
      take,
      select: {
        id:            true,
        chainIndex:    true,
        receiptNumber: true,
        txnType:       true,
        amountPkr:     true,
        exchangeRate:  true,
        amountUsdt:    true,
        costRate:      true,
        profitPkr:     true,
        clientId:      true,
        clientName:    true,
        clientCnic:    true,
        bankName:      true,
        bankLast4:     true,
        paymentRef:    true,
        notes:         true,
        timestamp:     true,
        hash:          true,
        prevHash:      true,
        hashVersion:   true,
      },
    });
  }

  /**
   * Count all sealed (hashed) transactions — used for progress
   * reporting during a chain scan.
   *
   * @returns {Promise<number>}
   */
  countChain() {
    return prisma.transaction.count({ where: { hash: { not: null } } });
  }
}

module.exports = new IntegrityRepository();
