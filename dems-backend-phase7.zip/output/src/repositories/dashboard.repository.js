/**
 * src/repositories/dashboard.repository.js
 * ────────────────────────────────────────────────────────────────
 * Data-access layer for the Dashboard module (Phase 5).
 *
 * This repository contains ONLY queries — no business logic,
 * formatting, or metric computation.  The service layer assembles
 * and shapes results.
 *
 * Time-series queries (getDailyChartData, getMonthlyChartData) use
 * `prisma.$queryRaw` with PostgreSQL's `DATE_TRUNC` because Prisma's
 * standard `groupBy` API does not support date-part truncation.
 * All other queries use the standard Prisma client API.
 * ────────────────────────────────────────────────────────────────
 */

const { prisma } = require('../database/prisma.client');
const { Prisma } = require('@prisma/client');

class DashboardRepository {

  // ── Overall totals ─────────────────────────────────────────────

  /**
   * Aggregate totals across ALL non-void transactions.
   * @returns {Promise<{
   *   totalTxns: number,
   *   totalPkr:  Prisma.Decimal | null,
   *   totalUsdt: Prisma.Decimal | null,
   *   buyCount:  number,
   *   sellCount: number,
   * }>}
   */
  async getOverallTotals() {
    const [agg, buyCount, sellCount] = await Promise.all([
      prisma.transaction.aggregate({
        where:  { isVoid: false },
        _count: { id: true },
        _sum:   { amountPkr: true, amountUsdt: true },
      }),
      prisma.transaction.count({ where: { isVoid: false, txnType: 'BUY' } }),
      prisma.transaction.count({ where: { isVoid: false, txnType: 'SELL' } }),
    ]);

    return {
      totalTxns: agg._count.id,
      totalPkr:  agg._sum.amountPkr,
      totalUsdt: agg._sum.amountUsdt,
      buyCount,
      sellCount,
    };
  }

  /**
   * Count of active (non-deleted) clients.
   * @returns {Promise<number>}
   */
  getTotalClients() {
    return prisma.client.count();
  }

  // ── Period-scoped stats ────────────────────────────────────────

  /**
   * Aggregate stats for transactions within [from, to].
   *
   * @param {Date} from
   * @param {Date} to
   * @returns {Promise<{
   *   count:     number,
   *   pkrVolume: Prisma.Decimal | null,
   *   usdtVolume:Prisma.Decimal | null,
   *   profitPkr: Prisma.Decimal | null,
   *   buyCount:  number,
   *   sellCount: number,
   * }>}
   */
  async getPeriodStats(from, to) {
    const where = {
      isVoid:    false,
      timestamp: { gte: from, lte: to },
    };

    const [agg, buyCount, sellCount] = await Promise.all([
      prisma.transaction.aggregate({
        where,
        _count: { id: true },
        _sum:   { amountPkr: true, amountUsdt: true, profitPkr: true },
      }),
      prisma.transaction.count({ where: { ...where, txnType: 'BUY' } }),
      prisma.transaction.count({ where: { ...where, txnType: 'SELL' } }),
    ]);

    return {
      count:      agg._count.id,
      pkrVolume:  agg._sum.amountPkr,
      usdtVolume: agg._sum.amountUsdt,
      profitPkr:  agg._sum.profitPkr,
      buyCount,
      sellCount,
    };
  }

  /**
   * Average exchange rate (buy and sell separately) over a period.
   *
   * @param {Date} from
   * @param {Date} to
   * @returns {Promise<{ avgBuyRate: Prisma.Decimal|null, avgSellRate: Prisma.Decimal|null }>}
   */
  async getAvgRates(from, to) {
    const base = { isVoid: false, timestamp: { gte: from, lte: to } };

    const [buyAgg, sellAgg] = await Promise.all([
      prisma.transaction.aggregate({
        where: { ...base, txnType: 'BUY' },
        _avg:  { exchangeRate: true },
      }),
      prisma.transaction.aggregate({
        where: { ...base, txnType: 'SELL' },
        _avg:  { exchangeRate: true },
      }),
    ]);

    return {
      avgBuyRate:  buyAgg._avg.exchangeRate,
      avgSellRate: sellAgg._avg.exchangeRate,
    };
  }

  // ── Chain status ───────────────────────────────────────────────

  /**
   * Returns count of sealed transactions and whether any are missing
   * a hash (i.e. unsealed).  The "is chain intact" deep scan belongs
   * to the Integrity service — this is a lightweight dashboard signal.
   *
   * @returns {Promise<{ totalSealed: number, totalUnsealed: number }>}
   */
  async getChainStatus() {
    const [totalSealed, totalUnsealed] = await Promise.all([
      prisma.transaction.count({ where: { hash: { not: null } } }),
      prisma.transaction.count({ where: { hash: null } }),
    ]);
    return { totalSealed, totalUnsealed };
  }

  // ── Recent items ───────────────────────────────────────────────

  /**
   * Return the most recent `limit` transactions (newest first).
   *
   * @param {number} [limit=10]
   * @returns {Promise<import('@prisma/client').Transaction[]>}
   */
  getRecentTransactions(limit = 10) {
    return prisma.transaction.findMany({
      take:    limit,
      orderBy: { timestamp: 'desc' },
      select: {
        id:            true,
        receiptNumber: true,
        txnType:       true,
        amountPkr:     true,
        amountUsdt:    true,
        exchangeRate:  true,
        clientName:    true,
        timestamp:     true,
        chainIndex:    true,
        isVoid:        true,
      },
    });
  }

  /**
   * Return the most recent `limit` audit log entries (newest first).
   *
   * @param {number} [limit=20]
   * @returns {Promise<import('@prisma/client').AuditLog[]>}
   */
  getRecentAuditLogs(limit = 20) {
    return prisma.auditLog.findMany({
      take:    limit,
      orderBy: { timestamp: 'desc' },
      include: {
        user: {
          select: { id: true, fullName: true, email: true, role: true },
        },
      },
    });
  }

  // ── Chart data (time-series via raw SQL) ───────────────────────

  /**
   * Daily transaction totals grouped by calendar day.
   * Returns an array of rows: { day, count, pkr_volume, usdt_volume, buy_count, sell_count }
   *
   * Uses DATE_TRUNC('day', timestamp) so all timestamps within the
   * same UTC calendar day are collapsed into one bucket.
   *
   * @param {Date} from
   * @param {Date} to
   * @returns {Promise<Array<{day: Date, count: bigint, pkr_volume: Prisma.Decimal, usdt_volume: Prisma.Decimal, buy_count: bigint, sell_count: bigint}>>}
   */
  getDailyChartData(from, to) {
    return prisma.$queryRaw`
      SELECT
        DATE_TRUNC('day', "timestamp") AS day,
        COUNT(*)::int                                       AS count,
        COALESCE(SUM("amount_pkr"),  0)                    AS pkr_volume,
        COALESCE(SUM("amount_usdt"), 0)                    AS usdt_volume,
        COALESCE(SUM("profit_pkr"),  0)                    AS profit_pkr,
        COUNT(*) FILTER (WHERE "txn_type" = 'BUY')::int   AS buy_count,
        COUNT(*) FILTER (WHERE "txn_type" = 'SELL')::int  AS sell_count
      FROM transactions
      WHERE
        "is_void"   = false
        AND "timestamp" >= ${from}
        AND "timestamp" <= ${to}
      GROUP BY DATE_TRUNC('day', "timestamp")
      ORDER BY day ASC
    `;
  }

  /**
   * Monthly transaction totals grouped by calendar month.
   *
   * @param {Date} from
   * @param {Date} to
   * @returns {Promise<Array>}
   */
  getMonthlyChartData(from, to) {
    return prisma.$queryRaw`
      SELECT
        DATE_TRUNC('month', "timestamp") AS month,
        COUNT(*)::int                                       AS count,
        COALESCE(SUM("amount_pkr"),  0)                    AS pkr_volume,
        COALESCE(SUM("amount_usdt"), 0)                    AS usdt_volume,
        COALESCE(SUM("profit_pkr"),  0)                    AS profit_pkr,
        COUNT(*) FILTER (WHERE "txn_type" = 'BUY')::int   AS buy_count,
        COUNT(*) FILTER (WHERE "txn_type" = 'SELL')::int  AS sell_count
      FROM transactions
      WHERE
        "is_void"   = false
        AND "timestamp" >= ${from}
        AND "timestamp" <= ${to}
      GROUP BY DATE_TRUNC('month', "timestamp")
      ORDER BY month ASC
    `;
  }

  /**
   * Hourly breakdown for a single day — powers the daily drill-down chart.
   *
   * @param {Date} dayStart  — midnight UTC of the target day
   * @param {Date} dayEnd    — 23:59:59.999 UTC of the target day
   * @returns {Promise<Array>}
   */
  getHourlyChartData(dayStart, dayEnd) {
    return prisma.$queryRaw`
      SELECT
        DATE_TRUNC('hour', "timestamp") AS hour,
        COUNT(*)::int                                       AS count,
        COALESCE(SUM("amount_pkr"),  0)                    AS pkr_volume,
        COALESCE(SUM("amount_usdt"), 0)                    AS usdt_volume,
        COUNT(*) FILTER (WHERE "txn_type" = 'BUY')::int   AS buy_count,
        COUNT(*) FILTER (WHERE "txn_type" = 'SELL')::int  AS sell_count
      FROM transactions
      WHERE
        "is_void"   = false
        AND "timestamp" >= ${dayStart}
        AND "timestamp" <= ${dayEnd}
      GROUP BY DATE_TRUNC('hour', "timestamp")
      ORDER BY hour ASC
    `;
  }
}

module.exports = new DashboardRepository();
