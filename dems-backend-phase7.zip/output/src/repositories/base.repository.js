/**
 * src/repositories/base.repository.js
 * ────────────────────────────────────────────────────────────────
 * Generic repository providing common CRUD operations on top of a
 * Prisma model delegate (e.g. `prisma.client`, `prisma.transaction`).
 *
 * This is infrastructure, not business logic: it knows nothing about
 * what a "Client" or "Transaction" means — it just forwards
 * find/create/update/delete calls to Prisma. Entity-specific
 * repositories in later phases extend this class and add
 * domain-specific query methods (e.g. `findByReceiptNumber`).
 *
 * Example (future phase):
 *   class ClientRepository extends BaseRepository {
 *     constructor() { super(prisma.client); }
 *     findByCnic(cnic) { return this.model.findUnique({ where: { cnic } }); }
 *   }
 * ────────────────────────────────────────────────────────────────
 */

class BaseRepository {
  /**
   * @param {import('@prisma/client').Prisma.ModelName} model - a Prisma
   *   model delegate, e.g. `prisma.user`, `prisma.transaction`.
   */
  constructor(model) {
    if (!model) {
      throw new Error('BaseRepository requires a Prisma model delegate.');
    }
    this.model = model;
  }

  findById(id, options = {}) {
    return this.model.findUnique({ where: { id }, ...options });
  }

  findOne(where, options = {}) {
    return this.model.findFirst({ where, ...options });
  }

  findMany({ where = {}, skip, take, orderBy, include, select } = {}) {
    return this.model.findMany({ where, skip, take, orderBy, include, select });
  }

  count(where = {}) {
    return this.model.count({ where });
  }

  create(data, options = {}) {
    return this.model.create({ data, ...options });
  }

  updateById(id, data, options = {}) {
    return this.model.update({ where: { id }, data, ...options });
  }

  deleteById(id) {
    return this.model.delete({ where: { id } });
  }
}

module.exports = BaseRepository;
