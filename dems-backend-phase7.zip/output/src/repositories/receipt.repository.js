/**
 * src/repositories/receipt.repository.js
 * ────────────────────────────────────────────────────────────────
 * Data-access layer for the Receipt model (Phase 6).
 *
 * The Receipt model has a 1-1 relation with Transaction.
 * A receipt record may or may not exist for any given transaction —
 * the service layer calls `ensureReceipt()` to create one on demand.
 *
 * Responsibilities:
 *   • Find receipt by receipt number or transaction ID.
 *   • Create a receipt record (idempotent upsert pattern).
 *   • Update PDF path after PDF generation.
 *   • Atomically increment print / share counts.
 *   • Paginated list for admin views.
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const BaseRepository = require('./base.repository');
const { prisma }     = require('../database/prisma.client');

/** Full transaction include used by receipt lookups. */
const TXN_INCLUDE = {
  transaction: {
    include: {
      client: {
        select: {
          id: true, fullName: true, cnic: true,
          isVerified: true, isFlagged: true,
          phone: true, bankName: true, bankLast4: true,
        },
      },
      attachments: {
        orderBy: { uploadedAt: 'asc' },
      },
    },
  },
};

class ReceiptRepository extends BaseRepository {
  constructor() {
    super(prisma.receipt);
  }

  // ── Lookups ────────────────────────────────────────────────────

  /**
   * Find a receipt (with full transaction data) by receipt number.
   *
   * @param {string} receiptNumber — e.g. EXC-2026-000001
   * @returns {Promise<import('@prisma/client').Receipt & { transaction: object } | null>}
   */
  findByReceiptNumber(receiptNumber) {
    return this.model.findUnique({
      where:   { receiptNumber },
      include: TXN_INCLUDE,
    });
  }

  /**
   * Find a receipt by the linked transaction's UUID.
   *
   * @param {string} transactionId
   * @returns {Promise<import('@prisma/client').Receipt | null>}
   */
  findByTransactionId(transactionId) {
    return this.model.findUnique({
      where:   { transactionId },
      include: TXN_INCLUDE,
    });
  }

  // ── Upsert ────────────────────────────────────────────────────

  /**
   * Upsert a receipt record for the given transaction.
   *
   * Creates a new row if one does not exist; returns the existing
   * row unchanged if it does.  This is the idempotent "ensure"
   * pattern used by the receipt service.
   *
   * @param {{ transactionId: string, receiptNumber: string, qrData?: string }} data
   * @returns {Promise<import('@prisma/client').Receipt>}
   */
  upsert({ transactionId, receiptNumber, qrData }) {
    return this.model.upsert({
      where:  { transactionId },
      create: { transactionId, receiptNumber, qrData: qrData ?? null },
      update: {},          // do NOT overwrite existing fields on conflict
    });
  }

  // ── Updates ───────────────────────────────────────────────────

  /**
   * Persist the relative PDF file path after a PDF has been generated.
   *
   * @param {string} receiptId  — Receipt.id (UUID)
   * @param {string} pdfPath    — relative path, e.g. 'receipts/pdf/EXC-2026-000001.pdf'
   * @returns {Promise<import('@prisma/client').Receipt>}
   */
  setPdfPath(receiptId, pdfPath) {
    return this.model.update({
      where: { id: receiptId },
      data:  { pdfPath },
    });
  }

  /**
   * Persist the QR data (URL string) on the receipt record.
   *
   * @param {string} receiptId
   * @param {string} qrData
   */
  setQrData(receiptId, qrData) {
    return this.model.update({
      where: { id: receiptId },
      data:  { qrData },
    });
  }

  /**
   * Atomically increment the print count by 1.
   *
   * @param {string} receiptId
   * @returns {Promise<import('@prisma/client').Receipt>}
   */
  incrementPrintCount(receiptId) {
    return this.model.update({
      where: { id: receiptId },
      data:  { printCount: { increment: 1 } },
    });
  }

  /**
   * Atomically increment the share count by 1.
   *
   * @param {string} receiptId
   * @returns {Promise<import('@prisma/client').Receipt>}
   */
  incrementShareCount(receiptId) {
    return this.model.update({
      where: { id: receiptId },
      data:  { shareCount: { increment: 1 } },
    });
  }

  // ── Paginated list ────────────────────────────────────────────

  /**
   * Paginated list of receipts (newest first by default).
   *
   * @param {{ skip: number, take: number, orderBy?: object }} params
   * @returns {Promise<import('@prisma/client').Receipt[]>}
   */
  listReceipts({ skip = 0, take = 20, orderBy = { generatedAt: 'desc' } } = {}) {
    return this.model.findMany({
      skip,
      take,
      orderBy,
      include: {
        transaction: {
          select: {
            id: true, txnType: true, amountPkr: true,
            exchangeRate: true, amountUsdt: true,
            clientName: true, timestamp: true,
            chainIndex: true, isVoid: true,
          },
        },
      },
    });
  }

  /**
   * Total count of receipt records.
   * @returns {Promise<number>}
   */
  countReceipts() {
    return this.model.count();
  }
}

module.exports = new ReceiptRepository();
