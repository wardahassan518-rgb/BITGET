/**
 * src/repositories/client.repository.js
 * ────────────────────────────────────────────────────────────────
 * Data-access layer for the `clients` table.
 * Extends BaseRepository with Client-specific lookups. Search,
 * filtering, and pagination *parameters* are decided by
 * `services/client.service.js` — this file only knows how to turn an
 * already-built `where`/`skip`/`take`/`orderBy` into a Prisma call.
 * ────────────────────────────────────────────────────────────────
 */

const BaseRepository = require('./base.repository');
const { prisma } = require('../database/prisma.client');

class ClientRepository extends BaseRepository {
  constructor() {
    super(prisma.client);
  }

  /**
   * Find a client by CNIC (unique).
   *
   * @param {string} cnic
   * @returns {Promise<import('@prisma/client').Client | null>}
   */
  findByCnic(cnic) {
    return this.model.findUnique({ where: { cnic } });
  }

  /**
   * List clients matching a pre-built filter, with pagination + sort.
   *
   * @param {{ where: object, skip: number, take: number, orderBy: object }} params
   * @returns {Promise<import('@prisma/client').Client[]>}
   */
  search({ where, skip, take, orderBy }) {
    return this.model.findMany({ where, skip, take, orderBy });
  }

  /**
   * Count clients matching a pre-built filter (for pagination meta).
   *
   * @param {object} where
   * @returns {Promise<number>}
   */
  countMatching(where) {
    return this.model.count({ where });
  }

  /**
   * Recompute and persist a client's aggregate transaction stats
   * (totalTxns, totalVolumePkr, firstTxnDate, lastTxnDate) from the
   * `transactions` table. Always recomputing from source (rather than
   * incrementing/decrementing deltas on every transaction write) keeps
   * these denormalized fields correct even after transaction edits,
   * client re-assignment, or deletes — no drift can accumulate.
   *
   * Must be called with a transaction-scoped Prisma client (`tx`) in
   * the same `$transaction` as the transaction write that triggered it.
   *
   * @param {import('@prisma/client').Prisma.TransactionClient} tx
   * @param {string} clientId
   * @returns {Promise<import('@prisma/client').Client>}
   */
  async recomputeStats(tx, clientId) {
    const agg = await tx.transaction.aggregate({
      where: { clientId },
      _count: { _all: true },
      _sum: { amountPkr: true },
      _min: { timestamp: true },
      _max: { timestamp: true },
    });

    return tx.client.update({
      where: { id: clientId },
      data: {
        totalTxns: agg._count._all,
        totalVolumePkr: agg._sum.amountPkr ?? 0,
        firstTxnDate: agg._min.timestamp,
        lastTxnDate: agg._max.timestamp,
      },
    });
  }
}

module.exports = new ClientRepository();
