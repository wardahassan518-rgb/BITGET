/**
 * src/validators/reports.validator.js
 * ────────────────────────────────────────────────────────────────
 * Zod schemas for Reports endpoints (Phase 5).
 * ────────────────────────────────────────────────────────────────
 */

const { z } = require('zod');
const { paginationQuerySchema, booleanQueryParam } = require('./common.validator');

const TXN_TYPES = ['BUY', 'SELL'];

// ── Shared sub-schemas ────────────────────────────────────────────

const dateRangeBase = z
  .object({
    from: z.coerce.date().optional(),
    to:   z.coerce.date().optional(),
  })
  .refine(
    (d) => !d.from || !d.to || d.from <= d.to,
    { message: '"from" must be before or equal to "to"', path: ['from'] },
  );

// ── Daily Report ─────────────────────────────────────────────────

/**
 * GET /reports/daily
 * Defaults to today when no date is provided.
 */
const dailyReportQuerySchema = z.object({
  /** ISO date string of the target day, e.g. 2026-06-27. */
  date: z.coerce.date().optional(),
});

// ── Monthly Report ────────────────────────────────────────────────

/**
 * GET /reports/monthly
 * Defaults to the current calendar month when neither is provided.
 */
const monthlyReportQuerySchema = z.object({
  year:  z.coerce.number().int().min(2020).max(2100).optional(),
  month: z.coerce.number().int().min(1).max(12).optional(),
});

// ── Custom Date-Range Report ──────────────────────────────────────

/**
 * GET /reports/custom
 */
const customReportQuerySchema = dateRangeBase.extend({
  txnType:  z.enum(TXN_TYPES).optional(),
  clientId: z.string().uuid('clientId must be a valid UUID').optional(),
  /** Whether to include a per-day breakdown array in the response. */
  breakdown: booleanQueryParam,
});

// ── Client Report ─────────────────────────────────────────────────

/**
 * GET /reports/clients
 */
const clientReportQuerySchema = paginationQuerySchema.extend({
  from:       z.coerce.date().optional(),
  to:         z.coerce.date().optional(),
  search:     z.string().trim().max(150).optional(),
  isVerified: booleanQueryParam,
  isFlagged:  booleanQueryParam,
  /** Sort clients by a computed or stored metric. */
  sortBy:     z.enum(['totalTxns', 'totalVolumePkr', 'lastTxnDate', 'createdAt']).optional(),
  sortOrder:  z.enum(['asc', 'desc']).optional(),
  /** Include the top-N clients by PKR volume in a separate `topClients` array. */
  topN:       z.coerce.number().int().min(1).max(20).optional(),
}).refine(
  (d) => !d.from || !d.to || d.from <= d.to,
  { message: '"from" must be before or equal to "to"', path: ['from'] },
);

// ── Transaction Report ────────────────────────────────────────────

/**
 * GET /reports/transactions
 */
const transactionReportQuerySchema = paginationQuerySchema.extend({
  search:    z.string().trim().max(150).optional(),
  txnType:   z.enum(TXN_TYPES).optional(),
  clientId:  z.string().uuid('clientId must be a valid UUID').optional(),
  from:      z.coerce.date().optional(),
  to:        z.coerce.date().optional(),
  sortBy:    z.enum(['timestamp', 'amountPkr', 'receiptNumber', 'createdAt']).optional(),
  sortOrder: z.enum(['asc', 'desc']).optional(),
  /** Include aggregate totals (volume, profit) in the response. */
  includeTotals: booleanQueryParam,
}).refine(
  (d) => !d.from || !d.to || d.from <= d.to,
  { message: '"from" must be before or equal to "to"', path: ['from'] },
);

// ── Audit Report ──────────────────────────────────────────────────

/**
 * GET /reports/audit
 */
const auditReportQuerySchema = paginationQuerySchema.extend({
  action:    z.string().trim().max(80).optional(),
  userId:    z.string().uuid('userId must be a valid UUID').optional(),
  from:      z.coerce.date().optional(),
  to:        z.coerce.date().optional(),
  search:    z.string().trim().max(150).optional(),
  sortOrder: z.enum(['asc', 'desc']).optional(),
}).refine(
  (d) => !d.from || !d.to || d.from <= d.to,
  { message: '"from" must be before or equal to "to"', path: ['from'] },
);

// ── Statistics ────────────────────────────────────────────────────

/**
 * GET /reports/statistics
 */
const statisticsQuerySchema = z.object({
  from: z.coerce.date().optional(),
  to:   z.coerce.date().optional(),
}).refine(
  (d) => !d.from || !d.to || d.from <= d.to,
  { message: '"from" must be before or equal to "to"', path: ['from'] },
);

module.exports = {
  dailyReportQuerySchema,
  monthlyReportQuerySchema,
  customReportQuerySchema,
  clientReportQuerySchema,
  transactionReportQuerySchema,
  auditReportQuerySchema,
  statisticsQuerySchema,
};
