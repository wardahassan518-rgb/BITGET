/**
 * src/validators/client.validator.js
 * ────────────────────────────────────────────────────────────────
 * Zod schemas for the Client Management endpoints (Phase 3).
 * Used with the `validate` middleware from Phase 1.
 *
 * Deliberately NOT included here (system-managed, never client input):
 *   totalTxns, totalVolumePkr, firstTxnDate, lastTxnDate — these are
 *   recomputed by `client.repository.js#recomputeStats()` whenever a
 *   linked transaction is created/updated/deleted. Any of these keys
 *   sent by a caller are silently stripped by Zod's default
 *   "strip unknown keys" behaviour.
 * ────────────────────────────────────────────────────────────────
 */

const { z } = require('zod');
const { paginationQuerySchema, booleanQueryParam } = require('./common.validator');

/**
 * POST /clients
 */
const createClientSchema = z.object({
  cnic: z
    .string()
    .trim()
    .min(1)
    .max(20, 'cnic looks too long')
    .optional(),

  fullName: z
    .string({ required_error: 'fullName is required' })
    .trim()
    .min(1, 'fullName is required')
    .max(150),

  phone: z.string().trim().max(20).optional(),
  whatsapp: z.string().trim().max(20).optional(),

  bankName: z.string().trim().max(100).optional(),
  bankAccount: z.string().trim().max(50).optional(),
  bankLast4: z
    .string()
    .trim()
    .regex(/^\d{4}$/, 'bankLast4 must be exactly 4 digits')
    .optional(),

  isVerified: z.boolean().optional(),
  isFlagged: z.boolean().optional(),
  flagReason: z.string().trim().max(255).optional(),

  notes: z.string().trim().max(2000).optional(),
});

/**
 * PUT/PATCH /clients/:id — every field optional, same shape as create.
 */
const updateClientSchema = createClientSchema.partial();

/**
 * GET /clients — list query params: pagination + search + filters + sort.
 */
const listClientsQuerySchema = paginationQuerySchema.extend({
  /** Free-text search across fullName, cnic, phone, whatsapp, bankAccount. */
  search: z.string().trim().max(150).optional(),

  isVerified: booleanQueryParam,
  isFlagged: booleanQueryParam,

  sortBy: z
    .enum(['fullName', 'createdAt', 'totalTxns', 'totalVolumePkr', 'lastTxnDate'])
    .optional(),
  sortOrder: z.enum(['asc', 'desc']).optional(),
});

module.exports = { createClientSchema, updateClientSchema, listClientsQuerySchema };
