/**
 * src/validators/auth.validator.js
 * ────────────────────────────────────────────────────────────────
 * Zod schemas for the Authentication endpoints (Phase 2).
 * Used with the `validate` middleware from Phase 1.
 *
 * Usage:
 *   router.post('/login', validate(loginSchema), authController.login);
 * ────────────────────────────────────────────────────────────────
 */

const { z } = require('zod');

/**
 * POST /auth/login
 */
const loginSchema = z.object({
  email: z
    .string({ required_error: 'Email is required' })
    .trim()
    .email('Must be a valid email address')
    .toLowerCase(),

  password: z
    .string({ required_error: 'Password is required' })
    .min(1, 'Password is required'),
});

module.exports = { loginSchema };
