/**
 * src/validators/dashboard.validator.js
 * ────────────────────────────────────────────────────────────────
 * Zod schemas for Dashboard endpoints (Phase 5).
 * ────────────────────────────────────────────────────────────────
 */

const { z } = require('zod');

/**
 * GET /dashboard/summary — optional date-range override.
 * When omitted the service uses sensible defaults (today / this month).
 */
const dashboardSummaryQuerySchema = z.object({
  /** ISO date string — start of the "current period" window for
   *  the period-over-period comparison.  Defaults to start of today. */
  from: z.coerce.date().optional(),
  to:   z.coerce.date().optional(),
}).refine(
  (d) => !d.from || !d.to || d.from <= d.to,
  { message: '"from" must be before or equal to "to"', path: ['from'] },
);

/**
 * GET /dashboard/charts — specifies the time window and granularity.
 */
const dashboardChartsQuerySchema = z.object({
  /** How many days back to include.  Defaults to 30. */
  days: z.coerce.number().int().min(1).max(365).optional(),
  /** Explicit range (overrides `days` when both provided, `from` takes precedence). */
  from: z.coerce.date().optional(),
  to:   z.coerce.date().optional(),
  /** Chart granularity — day (default) or month. */
  granularity: z.enum(['day', 'month']).optional(),
}).refine(
  (d) => !d.from || !d.to || d.from <= d.to,
  { message: '"from" must be before or equal to "to"', path: ['from'] },
);

/**
 * GET /dashboard/recent-transactions
 */
const recentTransactionsQuerySchema = z.object({
  limit: z.coerce.number().int().min(1).max(50).optional(),
});

/**
 * GET /dashboard/recent-audit-logs
 */
const recentAuditLogsQuerySchema = z.object({
  limit: z.coerce.number().int().min(1).max(100).optional(),
});

module.exports = {
  dashboardSummaryQuerySchema,
  dashboardChartsQuerySchema,
  recentTransactionsQuerySchema,
  recentAuditLogsQuerySchema,
};
