/**
 * src/validators/common.validator.js
 * ────────────────────────────────────────────────────────────────
 * Generic, reusable Zod schemas shared across future feature
 * validators. Nothing here is specific to Transactions, Clients,
 * Auth, etc. — those schemas belong to the phase that builds that
 * feature (e.g. `validators/transaction.validator.js` in Phase 3).
 * ────────────────────────────────────────────────────────────────
 */

const { z } = require('zod');

/** Validates a UUID route param, e.g. GET /clients/:id */
const idParamSchema = z.object({
  id: z.string().uuid('id must be a valid UUID'),
});

/** Validates `?page=&limit=` query params used by any list endpoint. */
const paginationQuerySchema = z.object({
  page: z.coerce.number().int().positive().optional(),
  limit: z.coerce.number().int().positive().max(100).optional(),
});

/** Validates an ISO date-range query, e.g. `?from=&to=` */
const dateRangeQuerySchema = z
  .object({
    from: z.coerce.date().optional(),
    to: z.coerce.date().optional(),
  })
  .refine((data) => !data.from || !data.to || data.from <= data.to, {
    message: '"from" date must be before or equal to "to" date',
    path: ['from'],
  });

/**
 * Coerces the string `?flag=true` / `?flag=false` query value into an
 * actual boolean. Plain `z.coerce.boolean()` is unsafe for this —
 * it calls `Boolean(value)`, so the literal string `"false"` would
 * coerce to `true`. Used by any list endpoint with boolean filters
 * (e.g. `?isVerified=false`, `?isFlagged=true`).
 */
const booleanQueryParam = z.preprocess((val) => {
  if (val === undefined) return undefined;
  if (typeof val === 'boolean') return val;
  if (val === 'true') return true;
  if (val === 'false') return false;
  return val; // let z.boolean() reject anything else with a clear error
}, z.boolean().optional());

module.exports = {
  idParamSchema,
  paginationQuerySchema,
  dateRangeQuerySchema,
  booleanQueryParam,
};
