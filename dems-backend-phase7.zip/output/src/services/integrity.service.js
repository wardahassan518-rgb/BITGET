/**
 * src/services/integrity.service.js
 * ────────────────────────────────────────────────────────────────
 * DEMS Integrity Engine — Phase 4.
 *
 * Responsibilities:
 *   sealTransaction()       — compute chainIndex, prevHash, and
 *                             SHA-256 hash for a newly created
 *                             transaction, then write them back.
 *                             Called inside the same Prisma
 *                             $transaction as createTransaction so
 *                             the seal is atomic with the insert.
 *
 *   verifyByReceipt()       — look up a transaction by receipt
 *                             number, recompute its hash, compare
 *                             against the stored value, log the
 *                             attempt, and return ORIGINAL /
 *                             TAMPERED / NOT_FOUND.
 *
 *   verifyTransaction()     — same as above but accepts a full
 *                             transaction object (used by the
 *                             authenticated detail endpoint).
 *
 *   scanChain()             — walk every sealed transaction in
 *                             chainIndex order, verify each hash
 *                             individually AND verify that each
 *                             record's prevHash matches its
 *                             predecessor's hash.
 *
 *  _computeHash()           — deterministic SHA-256 of the canonical
 *                             field set. Private helper.
 *  _normalise()             — coerce any JS value to a stable string.
 *                             Private helper.
 *
 * Hash algorithm:
 *   Input = PIPE-separated field values in HASH_FIELDS_V2 order,
 *   with CHAIN_SALT appended at the end.
 *   All null / undefined values → the literal string "null".
 *   Decimal / BigDecimal → .toString() (preserves precision).
 *   Date → .toISOString() (UTC, deterministic regardless of locale).
 *   Output = SHA-256 hex digest (64 hex chars).
 * ────────────────────────────────────────────────────────────────
 */

const { prisma }            = require('../database/prisma.client');
const { sha256 }            = require('../utils/hash.util');
const { writeAuditLog }     = require('../utils/auditLog.util');
const integrityRepository   = require('../repositories/integrity.repository');
const { AUDIT_ACTIONS }     = require('../constants/audit');
const config                = require('../config/env.config');
const logger                = require('../utils/logger');

const {
  HASH_FIELDS_V2,
  GENESIS_PREV_HASH,
  HASH_VERSION,
  VERIFICATION_RESULT,
  VERIFICATION_LABEL,
} = require('../constants/integrity');

// ────────────────────────────────────────────────────────────────
//  Private helpers
// ────────────────────────────────────────────────────────────────

/**
 * Coerce any value into a stable, deterministic string.
 *
 * Canonical rules (must never change for DEMS_V2):
 *   null | undefined  → "null"
 *   Date              → UTC ISO-8601 (e.g. "2026-06-27T10:00:00.000Z")
 *   Prisma Decimal    → .toString()  (preserves all decimal places)
 *   everything else   → String(value)
 *
 * @param {unknown} value
 * @returns {string}
 */
function _normalise(value) {
  if (value === null || value === undefined) return 'null';
  if (value instanceof Date)                return value.toISOString();
  // Prisma Decimal objects have a toString() that preserves precision.
  // Plain numbers do too, so this covers both.
  return String(value);
}

/**
 * Compute the deterministic SHA-256 hash for a transaction.
 *
 * The pre-image is:
 *   HASH_FIELDS_V2[0] | HASH_FIELDS_V2[1] | … | HASH_FIELDS_V2[N] | CHAIN_SALT
 *
 * @param {object} txn      — full transaction object (or projection)
 * @param {string} prevHash — the previous record's hash (or GENESIS_PREV_HASH)
 * @param {number} chainIndex
 * @returns {string}  64-character hex digest
 */
function _computeHash(txn, prevHash, chainIndex) {
  // Build a temporary object that includes the two chain-linking fields
  // so the generic field loop below can handle them uniformly.
  const source = { ...txn, prevHash, chainIndex };

  const parts = HASH_FIELDS_V2.map((field) => _normalise(source[field]));
  // Append the environment salt as the final segment.
  parts.push(config.security.chainSalt);

  const preImage = parts.join('|');
  return sha256(preImage);
}

// ────────────────────────────────────────────────────────────────
//  Exported service methods
// ────────────────────────────────────────────────────────────────

/**
 * Seal a newly created transaction by computing and writing its
 * chainIndex, prevHash, hash, and hashVersion.
 *
 * MUST be called inside an existing `prisma.$transaction()` so the
 * hash write is atomic with the transaction insert.  The caller
 * (transaction.service.js createTransaction) passes its `tx` handle.
 *
 * Locking strategy:
 *   `findChainTail` runs inside the same serialisable unit as the
 *   UPDATE, so two concurrent inserts cannot claim the same
 *   chainIndex.  Postgres row-level locking ensures correct ordering.
 *
 * @param {import('@prisma/client').Prisma.TransactionClient} tx
 * @param {import('@prisma/client').Transaction} transaction — the
 *        freshly created row (returned by tx.transaction.create)
 * @returns {Promise<import('@prisma/client').Transaction>}  the sealed row
 */
async function sealTransaction(tx, transaction) {
  // ── 1. Determine chain position ──────────────────────────────
  const tail = await integrityRepository.findChainTail(tx);

  const chainIndex = tail === null ? 0 : tail.chainIndex + 1;
  const prevHash   = tail === null ? GENESIS_PREV_HASH : tail.hash;

  // ── 2. Compute hash ──────────────────────────────────────────
  const hash = _computeHash(transaction, prevHash, chainIndex);

  // ── 3. Write hash fields back to the transaction row ─────────
  const sealed = await tx.transaction.update({
    where: { id: transaction.id },
    data: {
      chainIndex,
      prevHash,
      hash,
      hashVersion: HASH_VERSION,
      isLocked:    true,
    },
    include: {
      client: {
        select: { id: true, fullName: true, cnic: true, isVerified: true, isFlagged: true },
      },
    },
  });

  logger.info(
    `[Integrity] Sealed txn ${transaction.receiptNumber} ` +
    `chainIndex=${chainIndex} hash=${hash.slice(0, 16)}…`,
  );

  return sealed;
}

/**
 * Verify a transaction's integrity by receipt number.
 *
 * Steps:
 *   1. Look up the transaction.
 *   2. If not found → log NOT_FOUND → return NOT_FOUND.
 *   3. If found but not sealed (hash is null) → treat as TAMPERED
 *      because a committed transaction MUST have a hash.
 *   4. Recompute the expected hash from the stored field values.
 *   5. Compare with stored hash.
 *   6. Write VerificationLog row + AuditLog entry.
 *   7. Return ORIGINAL or TAMPERED with supporting detail.
 *
 * This is the method called by the public `GET /api/verify/:receipt`
 * endpoint.  No authentication is required.
 *
 * @param {string} receiptNumber
 * @param {{ verifierIp?: string, userAgent?: string }} [meta]
 * @returns {Promise<{
 *   result:        'ORIGINAL' | 'TAMPERED' | 'NOT_FOUND',
 *   label:         'Verified' | 'Tampered' | 'Not Found',
 *   receiptNumber: string,
 *   transaction?:  object,
 *   message:       string,
 * }>}
 */
async function verifyByReceipt(receiptNumber, { verifierIp, userAgent } = {}) {
  return prisma.$transaction(async (tx) => {
    // ── 1. Look up ──────────────────────────────────────────────
    const txn = await integrityRepository.findTransactionByReceipt(receiptNumber);

    // ── 2. NOT_FOUND ────────────────────────────────────────────
    if (!txn) {
      await integrityRepository.writeVerificationLog(tx, {
        receiptNumber,
        result:     VERIFICATION_RESULT.NOT_FOUND,
        verifierIp,
        userAgent,
      });

      await writeAuditLog(tx, {
        action:    AUDIT_ACTIONS.INTEGRITY_NOT_FOUND,
        detail:    `Verification attempted for unknown receipt ${receiptNumber}`,
        userId:    null,
        userAgent,
      }, { silent: true });

      return {
        result:        VERIFICATION_RESULT.NOT_FOUND,
        label:         VERIFICATION_LABEL.NOT_FOUND,
        receiptNumber,
        transaction:   null,
        message:       `No transaction found with receipt number ${receiptNumber}.`,
      };
    }

    // ── 3. Not sealed ────────────────────────────────────────────
    if (!txn.hash || txn.chainIndex === null || txn.chainIndex === undefined) {
      await integrityRepository.writeVerificationLog(tx, {
        receiptNumber,
        result:     VERIFICATION_RESULT.TAMPERED,
        verifierIp,
        userAgent,
      });

      await writeAuditLog(tx, {
        action:    AUDIT_ACTIONS.INTEGRITY_TAMPERED,
        detail:    `Receipt ${receiptNumber} exists but has no integrity hash — treated as tampered`,
        userId:    null,
        userAgent,
      }, { silent: true });

      return {
        result:        VERIFICATION_RESULT.TAMPERED,
        label:         VERIFICATION_LABEL.TAMPERED,
        receiptNumber,
        transaction:   _safeTransactionSummary(txn),
        message:       'Transaction record exists but has not been sealed. Integrity cannot be confirmed.',
      };
    }

    // ── 4. Recompute hash ────────────────────────────────────────
    const expected = _computeHash(txn, txn.prevHash, txn.chainIndex);
    const match    = expected === txn.hash;

    const result = match ? VERIFICATION_RESULT.ORIGINAL : VERIFICATION_RESULT.TAMPERED;
    const label  = VERIFICATION_LABEL[result];

    // ── 5. Log ───────────────────────────────────────────────────
    await integrityRepository.writeVerificationLog(tx, {
      receiptNumber,
      result,
      verifierIp,
      userAgent,
    });

    const auditAction = match
      ? AUDIT_ACTIONS.INTEGRITY_VERIFIED
      : AUDIT_ACTIONS.INTEGRITY_TAMPERED;

    const auditDetail = match
      ? `Receipt ${receiptNumber} verified — hash matches (chainIndex=${txn.chainIndex})`
      : `Receipt ${receiptNumber} TAMPERED — hash mismatch (chainIndex=${txn.chainIndex})`;

    await writeAuditLog(tx, {
      action:    auditAction,
      detail:    auditDetail,
      userId:    null,
      userAgent,
    }, { silent: true });

    // ── 6. Return ────────────────────────────────────────────────
    return {
      result,
      label,
      receiptNumber,
      transaction: _safeTransactionSummary(txn),
      message: match
        ? 'Transaction integrity verified. This record has not been tampered with.'
        : 'Transaction integrity check failed. This record may have been tampered with.',
    };
  });
}

/**
 * Verify a transaction that has already been fetched.  Used by the
 * authenticated endpoint that needs both the hash result AND the full
 * transaction detail in one response.
 *
 * @param {import('@prisma/client').Transaction} txn
 * @param {{ userId?: string, userAgent?: string, verifierIp?: string }} [meta]
 * @returns {Promise<{ result: string, label: string, match: boolean, chainIndex: number|null }>}
 */
async function verifyTransaction(txn, { userId, userAgent, verifierIp } = {}) {
  return prisma.$transaction(async (tx) => {
    if (!txn.hash || txn.chainIndex === null || txn.chainIndex === undefined) {
      await writeAuditLog(tx, {
        action:    AUDIT_ACTIONS.INTEGRITY_TAMPERED,
        detail:    `Transaction ${txn.receiptNumber} has no integrity hash`,
        userId,
        userAgent,
      }, { silent: true });

      return {
        result:     VERIFICATION_RESULT.TAMPERED,
        label:      VERIFICATION_LABEL.TAMPERED,
        match:      false,
        chainIndex: null,
        message:    'Transaction is not sealed. No hash found.',
      };
    }

    const expected = _computeHash(txn, txn.prevHash, txn.chainIndex);
    const match    = expected === txn.hash;
    const result   = match ? VERIFICATION_RESULT.ORIGINAL : VERIFICATION_RESULT.TAMPERED;

    await integrityRepository.writeVerificationLog(tx, {
      receiptNumber: txn.receiptNumber,
      result,
      verifierIp,
      userAgent,
    });

    await writeAuditLog(tx, {
      action:    match ? AUDIT_ACTIONS.INTEGRITY_VERIFIED : AUDIT_ACTIONS.INTEGRITY_TAMPERED,
      detail:    `Integrity check for ${txn.receiptNumber}: ${result}`,
      userId,
      userAgent,
    }, { silent: true });

    return {
      result,
      label:      VERIFICATION_LABEL[result],
      match,
      chainIndex: txn.chainIndex,
      message:    match
        ? 'Transaction integrity verified.'
        : 'Transaction integrity check failed — record may have been tampered with.',
    };
  });
}

/**
 * Walk every sealed transaction in chainIndex order and verify:
 *   (a) each record's hash matches its stored fields, AND
 *   (b) each record's prevHash equals its predecessor's hash.
 *
 * Returns a summary of the scan and the list of any broken links.
 *
 * @param {{ userId?: string, userAgent?: string }} [meta]
 * @returns {Promise<{
 *   totalScanned: number,
 *   passed:       number,
 *   failed:       number,
 *   broken:       Array<{ chainIndex: number, receiptNumber: string, reason: string }>,
 *   chainIntact:  boolean,
 * }>}
 */
async function scanChain({ userId, userAgent } = {}) {
  const total   = await integrityRepository.countChain();
  const broken  = [];
  let   passed  = 0;
  let   prevHashSeen = null; // tracks the previous record's hash as we iterate

  // Paginate in batches of 500 to avoid loading the whole chain at once.
  const BATCH = 500;
  let   skip  = 0;

  while (skip < total) {
    const batch = await integrityRepository.findChain({ skip, take: BATCH });
    if (batch.length === 0) break;

    for (const txn of batch) {
      const issues = [];

      // (a) Self-hash verification
      const expected = _computeHash(txn, txn.prevHash, txn.chainIndex);
      if (expected !== txn.hash) {
        issues.push('hash mismatch (fields altered after sealing)');
      }

      // (b) Chain-link verification (skip for genesis record)
      if (txn.chainIndex > 0 && prevHashSeen !== null) {
        if (txn.prevHash !== prevHashSeen) {
          issues.push(`chain link broken (prevHash ≠ predecessor hash)`);
        }
      } else if (txn.chainIndex === 0) {
        if (txn.prevHash !== GENESIS_PREV_HASH) {
          issues.push(`genesis prevHash is not the expected zero-hash`);
        }
      }

      if (issues.length > 0) {
        broken.push({
          chainIndex:    txn.chainIndex,
          receiptNumber: txn.receiptNumber,
          reason:        issues.join('; '),
        });
      } else {
        passed++;
      }

      prevHashSeen = txn.hash;
    }

    skip += BATCH;
  }

  const chainIntact = broken.length === 0;

  await writeAuditLog(prisma, {
    action:    AUDIT_ACTIONS.INTEGRITY_CHAIN_SCAN,
    detail:    `Chain scan: ${total} records scanned, ${broken.length} broken. Intact=${chainIntact}`,
    userId,
    userAgent,
  }, { silent: true });

  return {
    totalScanned: total,
    passed,
    failed:       broken.length,
    broken,
    chainIntact,
  };
}

// ────────────────────────────────────────────────────────────────
//  Internal helpers
// ────────────────────────────────────────────────────────────────

/**
 * Return a safe, frontend-friendly summary of a transaction for
 * inclusion in verification responses.  Does NOT expose the raw hash
 * or prevHash so callers cannot use the API to harvest the chain.
 *
 * @param {import('@prisma/client').Transaction} txn
 * @returns {object}
 */
function _safeTransactionSummary(txn) {
  return {
    id:            txn.id,
    receiptNumber: txn.receiptNumber,
    txnType:       txn.txnType,
    amountPkr:     txn.amountPkr,
    exchangeRate:  txn.exchangeRate,
    amountUsdt:    txn.amountUsdt,
    clientName:    txn.clientName,
    clientCnic:    txn.clientCnic,
    timestamp:     txn.timestamp,
    chainIndex:    txn.chainIndex,
    hashVersion:   txn.hashVersion,
    isVoid:        txn.isVoid,
  };
}

module.exports = {
  sealTransaction,
  verifyByReceipt,
  verifyTransaction,
  scanChain,
  // Exported for unit-test access
  _computeHash,
  _normalise,
};
