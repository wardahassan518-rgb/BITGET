/**
 * src/services/client.service.js
 * ────────────────────────────────────────────────────────────────
 * Business logic for Client Management (Phase 3).
 *
 * Controllers stay thin; all validation-beyond-Zod (uniqueness,
 * existence checks), the search/filter `where` clause, and audit
 * logging live here. Repositories handle the actual Prisma calls.
 * ────────────────────────────────────────────────────────────────
 */

const clientRepository = require('../repositories/client.repository');
const { prisma } = require('../database/prisma.client');
const { writeAuditLog } = require('../utils/auditLog.util');
const { getPagination, buildMeta } = require('../utils/pagination.util');
const { AUDIT_ACTIONS } = require('../constants/audit');
const ApiError = require('../utils/ApiError');

// ────────────────────────────────────────────────────────────────
//  Helpers
// ────────────────────────────────────────────────────────────────

/**
 * Build the Prisma `where` clause for `GET /clients` from validated
 * query params (search + boolean filters).
 *
 * @param {{ search?: string, isVerified?: boolean, isFlagged?: boolean }} filters
 * @returns {object}
 */
function buildClientWhere({ search, isVerified, isFlagged }) {
  const where = {};

  if (typeof isVerified === 'boolean') where.isVerified = isVerified;
  if (typeof isFlagged === 'boolean') where.isFlagged = isFlagged;

  if (search) {
    where.OR = [
      { fullName: { contains: search, mode: 'insensitive' } },
      { cnic: { contains: search, mode: 'insensitive' } },
      { phone: { contains: search, mode: 'insensitive' } },
      { whatsapp: { contains: search, mode: 'insensitive' } },
      { bankAccount: { contains: search, mode: 'insensitive' } },
    ];
  }

  return where;
}

// ────────────────────────────────────────────────────────────────
//  Exported service methods
// ────────────────────────────────────────────────────────────────

/**
 * Create a new client.
 *
 * @param {object} data - validated body (see client.validator.js)
 * @param {{ id: string }} actor - `req.user`
 * @param {{ userAgent?: string, ipAddress?: string }} meta
 * @returns {Promise<object>}
 */
async function createClient(data, actor, meta = {}) {
  if (data.cnic) {
    const existing = await clientRepository.findByCnic(data.cnic);
    if (existing) {
      throw new ApiError(409, 'A client with this CNIC already exists', {
        details: { clientId: existing.id },
      });
    }
  }

  return prisma.$transaction(async (tx) => {
    const client = await tx.client.create({ data });

    await writeAuditLog(tx, {
      action: AUDIT_ACTIONS.CLIENT_CREATED,
      detail: `Client "${client.fullName}" (${client.id}) created`,
      userId: actor?.id,
      ...meta,
    });

    return client;
  });
}

/**
 * Get a single client by id.
 *
 * @param {string} id
 * @returns {Promise<object>}
 */
async function getClientById(id) {
  const client = await clientRepository.findById(id);
  if (!client) throw new ApiError(404, 'Client not found');
  return client;
}

/**
 * List clients with pagination, search, and filtering.
 *
 * @param {object} query - validated query params (see client.validator.js)
 * @returns {Promise<{ clients: object[], meta: object }>}
 */
async function listClients(query) {
  const { page, limit, skip, take } = getPagination(query);
  const where = buildClientWhere(query);
  const orderBy = { [query.sortBy ?? 'createdAt']: query.sortOrder ?? 'desc' };

  const [clients, totalItems] = await Promise.all([
    clientRepository.search({ where, skip, take, orderBy }),
    clientRepository.countMatching(where),
  ]);

  return { clients, meta: buildMeta(page, limit, totalItems) };
}

/**
 * Update a client.
 *
 * @param {string} id
 * @param {object} data - validated body (see client.validator.js)
 * @param {{ id: string }} actor
 * @param {{ userAgent?: string, ipAddress?: string }} meta
 * @returns {Promise<object>}
 */
async function updateClient(id, data, actor, meta = {}) {
  const existing = await clientRepository.findById(id);
  if (!existing) throw new ApiError(404, 'Client not found');

  if (data.cnic && data.cnic !== existing.cnic) {
    const cnicOwner = await clientRepository.findByCnic(data.cnic);
    if (cnicOwner && cnicOwner.id !== id) {
      throw new ApiError(409, 'A client with this CNIC already exists', {
        details: { clientId: cnicOwner.id },
      });
    }
  }

  return prisma.$transaction(async (tx) => {
    const client = await tx.client.update({ where: { id }, data });

    await writeAuditLog(tx, {
      action: AUDIT_ACTIONS.CLIENT_UPDATED,
      detail: `Client "${client.fullName}" (${client.id}) updated`,
      userId: actor?.id,
      ...meta,
    });

    return client;
  });
}

/**
 * Delete a client.
 *
 * Blocks deletion if the client has linked transactions — those are
 * the tamper-evident ledger this whole system exists to protect, so
 * deleting a client out from under historical transactions (even
 * though the FK is nullable) would silently orphan financial records.
 * Re-assign or remove the transactions first.
 *
 * @param {string} id
 * @param {{ id: string }} actor
 * @param {{ userAgent?: string, ipAddress?: string }} meta
 * @returns {Promise<void>}
 */
async function deleteClient(id, actor, meta = {}) {
  const existing = await clientRepository.findById(id);
  if (!existing) throw new ApiError(404, 'Client not found');

  if (existing.totalTxns > 0) {
    throw new ApiError(
      409,
      'This client has linked transactions and cannot be deleted. Re-assign or remove those transactions first.',
    );
  }

  await prisma.$transaction(async (tx) => {
    await tx.client.delete({ where: { id } });

    await writeAuditLog(tx, {
      action: AUDIT_ACTIONS.CLIENT_DELETED,
      detail: `Client "${existing.fullName}" (${existing.id}) deleted`,
      userId: actor?.id,
      ...meta,
    });
  });
}

module.exports = { createClient, getClientById, listClients, updateClient, deleteClient };
