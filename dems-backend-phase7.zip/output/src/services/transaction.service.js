/**
 * src/services/transaction.service.js
 * ────────────────────────────────────────────────────────────────
 * Business logic for Transaction Management (Phase 3): CRUD,
 * automatic receipt numbering, client-stats sync, and audit logging.
 *
 * Every create/update/delete runs inside a single `prisma.$transaction`
 * so that the transaction write, the receipt-number reservation, the
 * client stats recompute, and the audit-log entry either all commit
 * together or all roll back together — there is never a state where
 * one exists without the others.
 *
 * Explicitly out of scope for this phase (per the Phase 3 brief):
 * hash-chain generation/verification, void/correction workflow, QR
 * codes, PDF receipts, and reports. The `hash`, `prevHash`,
 * `chainIndex`, `isLocked`, `isVoid` etc. columns on `Transaction`
 * are reserved for those later phases and are never touched here.
 * ────────────────────────────────────────────────────────────────
 */

const transactionRepository = require('../repositories/transaction.repository');
const clientRepository = require('../repositories/client.repository');
const { prisma } = require('../database/prisma.client');
const { generateReceiptNumber } = require('../utils/receiptNumber.util');
const { writeAuditLog } = require('../utils/auditLog.util');
const { getPagination, buildMeta } = require('../utils/pagination.util');
const { AUDIT_ACTIONS } = require('../constants/audit');
const ApiError = require('../utils/ApiError');
// Phase 4 — Integrity Engine: seal each new transaction with a
// SHA-256 hash, chainIndex, and prevHash inside the same DB transaction.
const { sealTransaction } = require('./integrity.service');

// ────────────────────────────────────────────────────────────────
//  Helpers
// ────────────────────────────────────────────────────────────────

/**
 * Build the Prisma `where` clause for `GET /transactions` from
 * validated query params (search + filters + date range).
 *
 * @param {{ search?: string, txnType?: string, clientId?: string, from?: Date, to?: Date }} filters
 * @returns {object}
 */
function buildTransactionWhere({ search, txnType, clientId, from, to }) {
  const where = {};

  if (txnType) where.txnType = txnType;
  if (clientId) where.clientId = clientId;

  if (from || to) {
    where.timestamp = {};
    if (from) where.timestamp.gte = from;
    if (to) where.timestamp.lte = to;
  }

  if (search) {
    where.OR = [
      { receiptNumber: { contains: search, mode: 'insensitive' } },
      { orderId: { contains: search, mode: 'insensitive' } },
      { clientName: { contains: search, mode: 'insensitive' } },
      { clientCnic: { contains: search, mode: 'insensitive' } },
      { paymentRef: { contains: search, mode: 'insensitive' } },
    ];
  }

  return where;
}

/**
 * Recompute client stats for every distinct, truthy client id in the
 * given list. Deduplicates so a same-client update only does one
 * aggregate query instead of two.
 *
 * @param {import('@prisma/client').Prisma.TransactionClient} tx
 * @param {Array<string|null|undefined>} clientIds
 */
async function recomputeAffectedClients(tx, clientIds) {
  const unique = [...new Set(clientIds.filter(Boolean))];
  await Promise.all(unique.map((id) => clientRepository.recomputeStats(tx, id)));
}

// ────────────────────────────────────────────────────────────────
//  Exported service methods
// ────────────────────────────────────────────────────────────────

/**
 * Create a new transaction. Generates the receipt number, snapshots
 * client identity (if linked), syncs client stats, and writes an
 * audit-log entry — all atomically.
 *
 * @param {object} data - validated body (see transaction.validator.js)
 * @param {{ id: string }} actor
 * @param {{ userAgent?: string, ipAddress?: string }} meta
 * @returns {Promise<object>}
 */
async function createTransaction(data, actor, meta = {}) {
  return prisma.$transaction(async (tx) => {
    let { clientId, clientName, clientCnic } = data;

    if (clientId) {
      const client = await tx.client.findUnique({ where: { id: clientId } });
      if (!client) throw new ApiError(404, 'Linked client not found');

      // Snapshot the client's current name/CNIC unless the caller
      // explicitly overrode them in the request body.
      clientName = clientName ?? client.fullName;
      clientCnic = clientCnic ?? client.cnic ?? undefined;
    }

    const receiptNumber = await generateReceiptNumber(tx);

    const transaction = await tx.transaction.create({
      data: {
        ...data,
        clientId,
        clientName,
        clientCnic,
        receiptNumber,
        timestamp: data.timestamp ?? new Date(),
      },
      include: {
        client: {
          select: { id: true, fullName: true, cnic: true, isVerified: true, isFlagged: true },
        },
      },
    });

    // ── Phase 4: Seal the transaction (chainIndex + prevHash + SHA-256 hash)
    // Runs inside this same $transaction so the hash write is atomic with
    // the insert. sealTransaction reads the chain tail using the same `tx`
    // handle, preventing concurrent inserts from claiming the same chainIndex.
    const sealed = await sealTransaction(tx, transaction);

    if (clientId) {
      await clientRepository.recomputeStats(tx, clientId);
    }

    await writeAuditLog(tx, {
      action: AUDIT_ACTIONS.TRANSACTION_CREATED,
      detail: `Transaction ${sealed.receiptNumber} (${sealed.txnType}, PKR ${sealed.amountPkr}) created — chainIndex=${sealed.chainIndex}`,
      userId: actor?.id,
      ...meta,
    });

    return sealed;
  });
}

/**
 * Get a single transaction by id.
 *
 * @param {string} id
 * @returns {Promise<object>}
 */
async function getTransactionById(id) {
  const transaction = await transactionRepository.findByIdWithClient(id);
  if (!transaction) throw new ApiError(404, 'Transaction not found');
  return transaction;
}

/**
 * List transactions with pagination, search, filtering, and sorting.
 *
 * @param {object} query - validated query params (see transaction.validator.js)
 * @returns {Promise<{ transactions: object[], meta: object }>}
 */
async function listTransactions(query) {
  const { page, limit, skip, take } = getPagination(query);
  const where = buildTransactionWhere(query);
  const orderBy = { [query.sortBy ?? 'timestamp']: query.sortOrder ?? 'desc' };

  const [transactions, totalItems] = await Promise.all([
    transactionRepository.search({ where, skip, take, orderBy }),
    transactionRepository.countMatching(where),
  ]);

  return { transactions, meta: buildMeta(page, limit, totalItems) };
}

/**
 * Update a transaction. If the linked client changes, both the old
 * and new client's stats are recomputed so neither is left stale.
 *
 * @param {string} id
 * @param {object} data - validated body (see transaction.validator.js)
 * @param {{ id: string }} actor
 * @param {{ userAgent?: string, ipAddress?: string }} meta
 * @returns {Promise<object>}
 */
async function updateTransaction(id, data, actor, meta = {}) {
  return prisma.$transaction(async (tx) => {
    const existing = await tx.transaction.findUnique({ where: { id } });
    if (!existing) throw new ApiError(404, 'Transaction not found');

    const clientChanged = Object.prototype.hasOwnProperty.call(data, 'clientId');
    const newClientId = clientChanged ? data.clientId : existing.clientId;

    let clientNameOverride = data.clientName;
    let clientCnicOverride = data.clientCnic;

    if (clientChanged && newClientId) {
      const client = await tx.client.findUnique({ where: { id: newClientId } });
      if (!client) throw new ApiError(404, 'Linked client not found');

      clientNameOverride = clientNameOverride ?? client.fullName;
      clientCnicOverride = clientCnicOverride ?? client.cnic ?? undefined;
    }

    const transaction = await tx.transaction.update({
      where: { id },
      data: {
        ...data,
        ...(clientNameOverride !== undefined ? { clientName: clientNameOverride } : {}),
        ...(clientCnicOverride !== undefined ? { clientCnic: clientCnicOverride } : {}),
      },
      include: {
        client: {
          select: { id: true, fullName: true, cnic: true, isVerified: true, isFlagged: true },
        },
      },
    });

    await recomputeAffectedClients(tx, [existing.clientId, newClientId]);

    await writeAuditLog(tx, {
      action: AUDIT_ACTIONS.TRANSACTION_UPDATED,
      detail: `Transaction ${transaction.receiptNumber} updated`,
      userId: actor?.id,
      ...meta,
    });

    return transaction;
  });
}

/**
 * Delete a transaction and re-sync the linked client's stats.
 *
 * Note: hash-chain locking (`isLocked`) that would normally prevent
 * deleting a committed ledger entry is a later phase's concern (see
 * file header) — this phase implements plain CRUD as requested.
 *
 * @param {string} id
 * @param {{ id: string }} actor
 * @param {{ userAgent?: string, ipAddress?: string }} meta
 * @returns {Promise<void>}
 */
async function deleteTransaction(id, actor, meta = {}) {
  await prisma.$transaction(async (tx) => {
    const existing = await tx.transaction.findUnique({ where: { id } });
    if (!existing) throw new ApiError(404, 'Transaction not found');

    await tx.transaction.delete({ where: { id } });

    if (existing.clientId) {
      await clientRepository.recomputeStats(tx, existing.clientId);
    }

    await writeAuditLog(tx, {
      action: AUDIT_ACTIONS.TRANSACTION_DELETED,
      detail: `Transaction ${existing.receiptNumber} deleted`,
      userId: actor?.id,
      ...meta,
    });
  });
}

module.exports = {
  createTransaction,
  getTransactionById,
  listTransactions,
  updateTransaction,
  deleteTransaction,
};
