/**
 * src/services/reports.service.js
 * ────────────────────────────────────────────────────────────────
 * Business logic for the Reports module (Phase 5).
 *
 * Handles:
 *   getDailyReport()        — single-day summary + hourly breakdown
 *   getMonthlyReport()      — single-month summary + daily breakdown
 *   getCustomReport()       — arbitrary date range + optional breakdown
 *   getClientReport()       — paginated client list + top-N leaders
 *   getTransactionReport()  — paginated transaction list + totals
 *   getAuditReport()        — paginated audit log list
 *   getStatistics()         — rates, busy hours/days, period comparison
 *
 * Each method returns a plain object consumed directly by its
 * controller.  All date window logic (start/end of day, month
 * boundaries) is resolved here — the repository receives concrete
 * Date objects.
 * ────────────────────────────────────────────────────────────────
 */

const reportsRepository = require('../repositories/reports.repository');
const { getPagination, buildMeta } = require('../utils/pagination.util');

// ────────────────────────────────────────────────────────────────
//  Date helpers
// ────────────────────────────────────────────────────────────────

function utcDayStart(d) {
  const dt = new Date(d);
  dt.setUTCHours(0, 0, 0, 0);
  return dt;
}

function utcDayEnd(d) {
  const dt = new Date(d);
  dt.setUTCHours(23, 59, 59, 999);
  return dt;
}

function utcMonthStart(year, month) {
  // month is 1-based (1=January)
  return new Date(Date.UTC(year, month - 1, 1, 0, 0, 0, 0));
}

function utcMonthEnd(year, month) {
  // Day 0 of next month = last day of current month
  return new Date(Date.UTC(year, month, 0, 23, 59, 59, 999));
}

/** Coerce Prisma Decimal / null to a decimal string. */
function ds(val) {
  if (val === null || val === undefined) return '0.00';
  return val.toString();
}

/** Normalise a raw SQL row from Postgres: BigInt → Number, Decimal → string. */
function normaliseRawRow(row) {
  const out = {};
  for (const [k, v] of Object.entries(row)) {
    if (typeof v === 'bigint') {
      out[k] = Number(v);
    } else if (v !== null && typeof v === 'object' && typeof v.toString === 'function' && v.constructor?.name !== 'Date') {
      out[k] = v.toString();
    } else {
      out[k] = v;
    }
  }
  return out;
}

/** Shape aggregate result from repository into a standardised object. */
function shapeAggregates(agg) {
  return {
    count:       agg.count,
    totalPkr:    ds(agg.totalPkr),
    totalUsdt:   ds(agg.totalUsdt),
    totalProfit: ds(agg.totalProfit),
    avgRate:     ds(agg.avgRate),
    avgPkr:      ds(agg.avgPkr),
    maxPkr:      ds(agg.maxPkr),
    minPkr:      ds(agg.minPkr),
  };
}

/** Shape a buy/sell type split result. */
function shapeSplit(split) {
  return {
    buy: {
      count:       split.buy.count,
      totalPkr:    ds(split.buy.totalPkr),
      totalUsdt:   ds(split.buy.totalUsdt),
      totalProfit: ds(split.buy.totalProfit),
      avgRate:     ds(split.buy.avgRate),
    },
    sell: {
      count:       split.sell.count,
      totalPkr:    ds(split.sell.totalPkr),
      totalUsdt:   ds(split.sell.totalUsdt),
      totalProfit: ds(split.sell.totalProfit),
      avgRate:     ds(split.sell.avgRate),
    },
  };
}

// ────────────────────────────────────────────────────────────────
//  Exported service methods
// ────────────────────────────────────────────────────────────────

/**
 * Daily report — full summary for a single calendar day.
 *
 * @param {{ date?: Date }} query
 * @returns {Promise<object>}
 */
async function getDailyReport({ date } = {}) {
  const target   = date ?? new Date();
  const dayStart = utcDayStart(target);
  const dayEnd   = utcDayEnd(target);

  const where = {
    isVoid:    false,
    timestamp: { gte: dayStart, lte: dayEnd },
  };

  const [aggregates, split, rawBreakdown] = await Promise.all([
    reportsRepository.getTransactionAggregates(where),
    reportsRepository.getTypeSplit(where),
    reportsRepository.getDailyHourlyBreakdown(dayStart, dayEnd),
  ]);

  return {
    date:       dayStart.toISOString().slice(0, 10),
    dayStart:   dayStart.toISOString(),
    dayEnd:     dayEnd.toISOString(),
    summary:    shapeAggregates(aggregates),
    byType:     shapeSplit(split),
    breakdown:  rawBreakdown.map(normaliseRawRow),
    generatedAt: new Date().toISOString(),
  };
}

/**
 * Monthly report — full summary for a single calendar month.
 *
 * @param {{ year?: number, month?: number }} query
 * @returns {Promise<object>}
 */
async function getMonthlyReport({ year, month } = {}) {
  const now     = new Date();
  const y       = year  ?? now.getUTCFullYear();
  const m       = month ?? (now.getUTCMonth() + 1);

  const monthStart = utcMonthStart(y, m);
  const monthEnd   = utcMonthEnd(y, m);

  const where = {
    isVoid:    false,
    timestamp: { gte: monthStart, lte: monthEnd },
  };

  const MONTH_NAMES = [
    '', 'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
  ];

  const [aggregates, split, rawBreakdown] = await Promise.all([
    reportsRepository.getTransactionAggregates(where),
    reportsRepository.getTypeSplit(where),
    reportsRepository.getMonthlyDailyBreakdown(monthStart, monthEnd),
  ]);

  return {
    year:       y,
    month:      m,
    monthName:  MONTH_NAMES[m],
    monthStart: monthStart.toISOString(),
    monthEnd:   monthEnd.toISOString(),
    summary:    shapeAggregates(aggregates),
    byType:     shapeSplit(split),
    breakdown:  rawBreakdown.map(normaliseRawRow),
    generatedAt: new Date().toISOString(),
  };
}

/**
 * Custom date-range report.
 *
 * @param {{ from?: Date, to?: Date, txnType?: string, clientId?: string, breakdown?: boolean }} query
 * @returns {Promise<object>}
 */
async function getCustomReport({ from, to, txnType, clientId, breakdown = false } = {}) {
  const now  = new Date();
  const toD  = to   ? utcDayEnd(to)   : utcDayEnd(now);
  const fromD= from ? utcDayStart(from): utcDayStart(new Date(now.getTime() - 29 * 86400000));

  const where = {
    isVoid:    false,
    timestamp: { gte: fromD, lte: toD },
  };
  if (txnType)  where.txnType  = txnType;
  if (clientId) where.clientId = clientId;

  const tasks = [
    reportsRepository.getTransactionAggregates(where),
    reportsRepository.getTypeSplit({ isVoid: false, timestamp: { gte: fromD, lte: toD }, ...(clientId ? { clientId } : {}) }),
  ];
  if (breakdown) {
    tasks.push(reportsRepository.getCustomDailyBreakdown(fromD, toD));
  }

  const [aggregates, split, rawBreakdown] = await Promise.all(tasks);

  return {
    from:        fromD.toISOString(),
    to:          toD.toISOString(),
    filters:     { txnType: txnType ?? null, clientId: clientId ?? null },
    summary:     shapeAggregates(aggregates),
    byType:      shapeSplit(split),
    breakdown:   breakdown ? (rawBreakdown ?? []).map(normaliseRawRow) : undefined,
    generatedAt: new Date().toISOString(),
  };
}

/**
 * Client report — paginated client list + optional top-N leaders.
 *
 * @param {object} query — validated clientReportQuerySchema
 * @returns {Promise<object>}
 */
async function getClientReport(query) {
  const { page, limit, skip, take } = getPagination(query);

  const where = {};
  if (typeof query.isVerified === 'boolean') where.isVerified = query.isVerified;
  if (typeof query.isFlagged  === 'boolean') where.isFlagged  = query.isFlagged;
  if (query.search) {
    where.OR = [
      { fullName: { contains: query.search, mode: 'insensitive' } },
      { cnic:     { contains: query.search, mode: 'insensitive' } },
      { phone:    { contains: query.search, mode: 'insensitive' } },
    ];
  }

  const orderBy = {
    [query.sortBy ?? 'totalVolumePkr']: query.sortOrder ?? 'desc',
  };

  const [clients, totalItems] = await Promise.all([
    reportsRepository.getClientList({ where, skip, take, orderBy }),
    reportsRepository.countClients(where),
  ]);

  const result = {
    clients,
    meta: buildMeta(page, limit, totalItems),
  };

  // Include top-N leaders if requested and a date range is provided
  if (query.topN) {
    const now  = new Date();
    const toD  = query.to   ? utcDayEnd(query.to)   : utcDayEnd(now);
    const fromD= query.from ? utcDayStart(query.from): utcDayStart(new Date(now.getTime() - 29 * 86400000));
    const raw  = await reportsRepository.getTopClientsByVolume(fromD, toD, query.topN);
    result.topClients = raw.map(normaliseRawRow);
    result.topClientsWindow = { from: fromD.toISOString(), to: toD.toISOString() };
  }

  return result;
}

/**
 * Transaction report — paginated transaction list with optional totals.
 *
 * @param {object} query — validated transactionReportQuerySchema
 * @returns {Promise<object>}
 */
async function getTransactionReport(query) {
  const { page, limit, skip, take } = getPagination(query);

  const where = { isVoid: false };
  if (query.txnType)  where.txnType  = query.txnType;
  if (query.clientId) where.clientId = query.clientId;

  if (query.from || query.to) {
    where.timestamp = {};
    if (query.from) where.timestamp.gte = utcDayStart(query.from);
    if (query.to)   where.timestamp.lte = utcDayEnd(query.to);
  }

  if (query.search) {
    where.OR = [
      { receiptNumber: { contains: query.search, mode: 'insensitive' } },
      { orderId:       { contains: query.search, mode: 'insensitive' } },
      { clientName:    { contains: query.search, mode: 'insensitive' } },
      { clientCnic:    { contains: query.search, mode: 'insensitive' } },
      { paymentRef:    { contains: query.search, mode: 'insensitive' } },
    ];
  }

  const orderBy = {
    [query.sortBy ?? 'timestamp']: query.sortOrder ?? 'desc',
  };

  const tasks = [
    reportsRepository.getTransactionList({ where, skip, take, orderBy }),
    reportsRepository.countTransactions(where),
  ];

  if (query.includeTotals) {
    tasks.push(reportsRepository.getTransactionAggregates(where));
    tasks.push(reportsRepository.getTypeSplit(where));
  }

  const [transactions, totalItems, aggregates, split] = await Promise.all(tasks);

  const result = {
    transactions,
    meta: buildMeta(page, limit, totalItems),
  };

  if (query.includeTotals && aggregates) {
    result.totals = shapeAggregates(aggregates);
    result.byType = shapeSplit(split);
  }

  return result;
}

/**
 * Audit log report — paginated audit entries with optional filters.
 *
 * @param {object} query — validated auditReportQuerySchema
 * @returns {Promise<object>}
 */
async function getAuditReport(query) {
  const { page, limit, skip, take } = getPagination(query);

  const where = {};
  if (query.action) where.action = { contains: query.action, mode: 'insensitive' };
  if (query.userId) where.userId = query.userId;

  if (query.from || query.to) {
    where.timestamp = {};
    if (query.from) where.timestamp.gte = utcDayStart(query.from);
    if (query.to)   where.timestamp.lte = utcDayEnd(query.to);
  }

  if (query.search) {
    where.OR = [
      { action: { contains: query.search, mode: 'insensitive' } },
      { detail: { contains: query.search, mode: 'insensitive' } },
    ];
  }

  const orderBy = { timestamp: query.sortOrder ?? 'desc' };

  const [logs, totalItems] = await Promise.all([
    reportsRepository.getAuditList({ where, skip, take, orderBy }),
    reportsRepository.countAuditLogs(where),
  ]);

  return {
    logs,
    meta: buildMeta(page, limit, totalItems),
  };
}

/**
 * Statistics — aggregate metrics, rate analysis, busy hours/days,
 * period-over-period comparison, and verification summary.
 *
 * @param {{ from?: Date, to?: Date }} query
 * @returns {Promise<object>}
 */
async function getStatistics({ from, to } = {}) {
  const now  = new Date();
  const toD  = to   ? utcDayEnd(to)   : utcDayEnd(now);
  const fromD= from ? utcDayStart(from): utcDayStart(new Date(now.getTime() - 29 * 86400000));

  const baseWhere = {
    isVoid:    false,
    timestamp: { gte: fromD, lte: toD },
  };

  const DOW_NAMES = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

  const [
    aggregates,
    split,
    rateStats,
    busiestHours,
    busiestDays,
    comparison,
    verificationSummary,
    actionFrequency,
  ] = await Promise.all([
    reportsRepository.getTransactionAggregates(baseWhere),
    reportsRepository.getTypeSplit(baseWhere),
    reportsRepository.getRateStats(fromD, toD),
    reportsRepository.getBusiestHours(fromD, toD),
    reportsRepository.getBusiestDaysOfWeek(fromD, toD),
    reportsRepository.getPeriodComparison(fromD, toD),
    reportsRepository.getVerificationSummary(fromD, toD),
    reportsRepository.getActionFrequency(fromD, toD),
  ]);

  return {
    window: { from: fromD.toISOString(), to: toD.toISOString() },

    volume:  shapeAggregates(aggregates),
    byType:  shapeSplit(split),

    rates: {
      buy: {
        avg: ds(rateStats.buy.avg),
        max: ds(rateStats.buy.max),
        min: ds(rateStats.buy.min),
      },
      sell: {
        avg: ds(rateStats.sell.avg),
        max: ds(rateStats.sell.max),
        min: ds(rateStats.sell.min),
      },
    },

    activity: {
      busiestHours: busiestHours.map((r) => ({
        hour:  Number(r.hour),
        count: Number(r.count),
      })),
      busiestDaysOfWeek: busiestDays.map((r) => ({
        dow:     Number(r.dow),
        dayName: DOW_NAMES[Number(r.dow)] ?? `Day ${r.dow}`,
        count:   Number(r.count),
      })),
    },

    comparison: {
      current: shapeAggregates(comparison.current),
      previous: shapeAggregates(comparison.previous),
      previousWindow: {
        from: comparison.prevFrom.toISOString(),
        to:   comparison.prevTo.toISOString(),
      },
    },

    verification: verificationSummary.map(normaliseRawRow),

    auditActions: actionFrequency.map(normaliseRawRow),

    generatedAt: now.toISOString(),
  };
}

module.exports = {
  getDailyReport,
  getMonthlyReport,
  getCustomReport,
  getClientReport,
  getTransactionReport,
  getAuditReport,
  getStatistics,
};
