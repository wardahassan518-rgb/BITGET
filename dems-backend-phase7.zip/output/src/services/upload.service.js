/**
 * src/services/upload.service.js
 * ────────────────────────────────────────────────────────────────
 * Attachment Upload Service (Phase 6).
 *
 * Handles the lifecycle of file attachments on transactions:
 *   1. Move a multer-staged file from `uploads/temp/` to its final
 *      destination at `uploads/attachments/<transactionId>/`.
 *   2. Create / delete the corresponding `Attachment` Prisma record.
 *   3. Write audit log entries for every change.
 *
 * This service is the ONLY layer that knows about file paths —
 * controllers receive metadata (id, originalName, mimeType, etc.)
 * but never interact with the file system directly.
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const path    = require('path');
const { prisma } = require('../database/prisma.client');
const storage    = require('./storage.service');
const { writeAuditLog } = require('../utils/auditLog.util');
const { RECEIPT_AUDIT_ACTIONS, RECEIPT_DIRS } = require('../constants/receipt');
const ApiError = require('../utils/ApiError');
const logger   = require('../utils/logger');

// ── Public API ────────────────────────────────────────────────────

/**
 * Process a multer-uploaded file: move it from temp, persist the
 * Attachment record, and write an audit entry.
 *
 * @param {{
 *   file:          Express.Multer.File,
 *   transactionId: string,
 *   userId?:       string | null,
 *   userAgent?:    string,
 * }} params
 * @returns {Promise<import('@prisma/client').Attachment>}
 */
async function processAttachment({ file, transactionId, userId, userAgent }) {
  if (!file) throw new ApiError(400, 'No file provided.');

  // Verify the transaction exists
  const txn = await prisma.transaction.findUnique({ where: { id: transactionId } });
  if (!txn) throw new ApiError(404, `Transaction ${transactionId} not found.`);

  // Destination:  uploads/attachments/<transactionId>/<timestamp>-<original>
  const safeOriginal = path.basename(file.originalname || file.filename).replace(/[^a-zA-Z0-9._-]/g, '_');
  const destRelPath  = path.posix.join(
    RECEIPT_DIRS.ATTACHMENTS,
    transactionId,
    `${Date.now()}-${safeOriginal}`,
  );

  // Move from temp
  const destAbsPath = storage.moveFile(file.path, destRelPath);

  logger.debug(`[Upload] Attachment moved: ${file.path} → ${destAbsPath}`);

  // Persist & audit inside a transaction
  const attachment = await prisma.$transaction(async (tx) => {
    const rec = await tx.attachment.create({
      data: {
        transactionId,
        mimeType:      file.mimetype,
        originalName:  file.originalname || null,
        filePath:      destRelPath,
        fileSizeBytes: file.size || storage.getFileSize(destAbsPath),
      },
    });

    await writeAuditLog(tx, {
      action:    RECEIPT_AUDIT_ACTIONS.ATTACHMENT_UPLOADED,
      detail:    `Attachment ${rec.id} uploaded for transaction ${transactionId} (${file.originalname})`,
      userId:    userId ?? null,
      userAgent: userAgent ?? null,
    });

    return rec;
  });

  return attachment;
}

/**
 * Delete an attachment: remove the file from disk and the DB record.
 *
 * @param {{
 *   attachmentId: string,
 *   userId?:      string | null,
 *   userAgent?:   string,
 * }} params
 * @returns {Promise<void>}
 */
async function deleteAttachment({ attachmentId, userId, userAgent }) {
  const existing = await prisma.attachment.findUnique({ where: { id: attachmentId } });
  if (!existing) throw new ApiError(404, `Attachment ${attachmentId} not found.`);

  await prisma.$transaction(async (tx) => {
    await tx.attachment.delete({ where: { id: attachmentId } });

    await writeAuditLog(tx, {
      action:    RECEIPT_AUDIT_ACTIONS.ATTACHMENT_DELETED,
      detail:    `Attachment ${attachmentId} deleted (${existing.originalName})`,
      userId:    userId ?? null,
      userAgent: userAgent ?? null,
    });
  });

  // Delete file after DB commit (so a failed DB rollback keeps the file)
  const absPath = storage.getAbsPath(existing.filePath);
  storage.deleteFile(absPath);

  logger.debug(`[Upload] Attachment deleted: ${absPath}`);
}

/**
 * Return the attachment record and its absolute file path.
 * Throws 404 if not found or the file is missing from disk.
 *
 * @param {string} attachmentId
 * @returns {Promise<{ attachment: object, absPath: string }>}
 */
async function getAttachmentForDownload(attachmentId) {
  const attachment = await prisma.attachment.findUnique({
    where: { id: attachmentId },
    include: { transaction: { select: { id: true, receiptNumber: true } } },
  });
  if (!attachment) throw new ApiError(404, 'Attachment not found.');

  const absPath = storage.getAbsPath(attachment.filePath);
  if (!storage.fileExists(absPath)) {
    throw new ApiError(410, 'Attachment file has been removed from storage.');
  }

  return { attachment, absPath };
}

/**
 * List all attachments for a given transaction.
 *
 * @param {string} transactionId
 * @returns {Promise<import('@prisma/client').Attachment[]>}
 */
async function listAttachments(transactionId) {
  return prisma.attachment.findMany({
    where:   { transactionId },
    orderBy: { uploadedAt: 'asc' },
  });
}

module.exports = {
  processAttachment,
  deleteAttachment,
  getAttachmentForDownload,
  listAttachments,
};
