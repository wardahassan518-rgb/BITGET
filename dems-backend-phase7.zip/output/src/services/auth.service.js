/**
 * src/services/auth.service.js
 * ────────────────────────────────────────────────────────────────
 * Authentication business logic.
 *
 * All token generation, password verification, lockout enforcement,
 * and session lifecycle management lives here.  Controllers are thin
 * wrappers that call this service; repositories handle all DB I/O.
 * ────────────────────────────────────────────────────────────────
 */

const crypto = require('crypto');

const { compareValue } = require('../utils/bcrypt.util');
const { signAccessToken, signRefreshToken, verifyRefreshToken } = require('../utils/jwt.util');
const ApiError = require('../utils/ApiError');
const logger = require('../utils/logger');

const userRepository = require('../repositories/user.repository');
const sessionRepository = require('../repositories/session.repository');
const { prisma } = require('../database/prisma.client');

const { AUTH } = require('../constants/auth');
const config = require('../config/env.config');

// ────────────────────────────────────────────────────────────────
//  Helpers
// ────────────────────────────────────────────────────────────────

/**
 * Deterministic SHA-256 hex digest of a raw token string.
 * Used when writing to / querying the sessions table.
 *
 * @param {string} token
 * @returns {string}
 */
function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

/**
 * Parse a `JWT_REFRESH_EXPIRES_IN`-style duration string into a
 * concrete `Date` in the future.  Supports `d` (days) and `h` (hours).
 *
 * @param {string} duration  e.g. "7d", "24h"
 * @returns {Date}
 */
function expiryDateFromDuration(duration) {
  const match = duration.match(/^(\d+)([dhm])$/);
  if (!match) {
    // Fallback: 7 days
    return new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
  }
  const [, value, unit] = match;
  const ms = { d: 86_400_000, h: 3_600_000, m: 60_000 }[unit];
  return new Date(Date.now() + Number(value) * ms);
}

/**
 * Build the access-token payload.
 * `sub` is the canonical claim for "who this token is for".
 *
 * @param {object} user
 * @param {string} sessionId
 * @returns {object}
 */
function buildAccessPayload(user, sessionId) {
  return {
    sub: user.id,
    email: user.email,
    role: user.role,
    sessionId,
  };
}

/**
 * Build the refresh-token payload (minimal — only what is needed
 * to look up the session during rotation).
 *
 * @param {string} userId
 * @param {string} sessionId
 * @returns {object}
 */
function buildRefreshPayload(userId, sessionId) {
  return { sub: userId, sessionId, type: 'refresh' };
}

// ────────────────────────────────────────────────────────────────
//  Lockout helpers
// ────────────────────────────────────────────────────────────────

/**
 * Record a failed login attempt; lock the identifier if the attempt
 * threshold is crossed.
 *
 * @param {string} identifier  email address used at login
 * @param {string|null} userId  resolved user id (null if user not found)
 */
async function recordFailedAttempt(identifier, userId) {
  const existing = await prisma.loginLockout.findUnique({ where: { identifier } });
  const failedCount = (existing?.failedCount ?? 0) + 1;

  const lockoutUntil =
    failedCount >= AUTH.MAX_FAILED_ATTEMPTS
      ? new Date(Date.now() + AUTH.LOCKOUT_MINUTES * 60 * 1000)
      : null;

  await prisma.loginLockout.upsert({
    where: { identifier },
    create: { identifier, userId, failedCount, lockoutUntil },
    update: { failedCount, lockoutUntil, userId },
  });
}

/**
 * Clear the lockout record after a successful login.
 *
 * @param {string} identifier
 */
async function clearLockout(identifier) {
  await prisma.loginLockout
    .delete({ where: { identifier } })
    .catch(() => { /* record may not exist — that is fine */ });
}

/**
 * Write a row to the audit_log table.  Non-fatal: a logging failure
 * must never break the login response.
 *
 * @param {{ action: string, detail?: string, userId?: string, ipAddress?: string, userAgent?: string }} entry
 */
async function writeAuditLog({ action, detail, userId, ipAddress, userAgent }) {
  await prisma.auditLog
    .create({
      data: {
        action,
        detail,
        userId: userId ?? null,
        platform: 'api',
        userAgent: userAgent ?? null,
      },
    })
    .catch((err) => logger.warn(`Audit log write failed: ${err.message}`));
}

// ────────────────────────────────────────────────────────────────
//  Exported service methods
// ────────────────────────────────────────────────────────────────

/**
 * Authenticate a user with email + password.
 * Enforces lockout, verifies credentials, creates a session, and
 * returns a signed access token plus a signed refresh token.
 *
 * @param {{ email: string, password: string }} credentials
 * @param {{ userAgent?: string, ipAddress?: string }} meta
 * @returns {Promise<{ accessToken: string, refreshToken: string, user: object }>}
 */
async function login({ email, password }, { userAgent, ipAddress } = {}) {
  const identifier = email.toLowerCase().trim();

  // ── 1. Check lockout ─────────────────────────────────────────
  const lockout = await prisma.loginLockout.findUnique({ where: { identifier } });
  if (lockout?.lockoutUntil && lockout.lockoutUntil > new Date()) {
    const minutesLeft = Math.ceil((lockout.lockoutUntil - Date.now()) / 60_000);

    await writeAuditLog({
      action: AUTH.AUDIT.LOGIN_LOCKED,
      detail: `Account locked. Try again in ${minutesLeft} minute(s).`,
      ipAddress,
      userAgent,
    });

    throw new ApiError(429, `Account is temporarily locked. Try again in ${minutesLeft} minute(s).`);
  }

  // ── 2. Resolve user ──────────────────────────────────────────
  const user = await userRepository.findByEmail(identifier);

  if (!user) {
    // Record attempt with no userId (account enumeration defence: same
    // error message whether the email exists or the password is wrong).
    await recordFailedAttempt(identifier, null);
    await writeAuditLog({ action: AUTH.AUDIT.LOGIN_FAILED, detail: 'Unknown email', ipAddress, userAgent });
    throw new ApiError(401, 'Invalid email or password');
  }

  // ── 3. Active-account guard ──────────────────────────────────
  if (!user.isActive) {
    throw new ApiError(403, 'Your account has been deactivated. Contact an administrator.');
  }

  // ── 4. Password check ────────────────────────────────────────
  const passwordValid = await compareValue(password, user.passwordHash);

  if (!passwordValid) {
    await recordFailedAttempt(identifier, user.id);
    await writeAuditLog({
      action: AUTH.AUDIT.LOGIN_FAILED,
      detail: 'Incorrect password',
      userId: user.id,
      ipAddress,
      userAgent,
    });
    throw new ApiError(401, 'Invalid email or password');
  }

  // ── 5. Issue tokens ──────────────────────────────────────────
  // Create a placeholder session id first (needed inside the token
  // payload so the access token can identify which session it belongs
  // to without a second DB round-trip during verification).
  const tempSessionId = crypto.randomUUID();

  const refreshToken = signRefreshToken(buildRefreshPayload(user.id, tempSessionId));
  const tokenHash = hashToken(refreshToken);
  const expiresAt = expiryDateFromDuration(config.jwt.refreshExpiresIn);

  // ── 6. Persist session ───────────────────────────────────────
  const session = await sessionRepository.createSession({
    userId: user.id,
    tokenHash,
    expiresAt,
    userAgent,
    ipAddress,
  });

  // Now that we have the real session id, sign the access token.
  const accessToken = signAccessToken(buildAccessPayload(user, session.id));

  // ── 7. Housekeeping ──────────────────────────────────────────
  await Promise.all([
    clearLockout(identifier),
    userRepository.stampLastLogin(user.id),
    writeAuditLog({
      action: AUTH.AUDIT.LOGIN_SUCCESS,
      userId: user.id,
      detail: `Session ${session.id}`,
      ipAddress,
      userAgent,
    }),
  ]);

  // Return a safe user object (no passwordHash).
  const { passwordHash: _omit, ...safeUser } = user;

  return { accessToken, refreshToken, user: safeUser };
}

/**
 * Invalidate the current session (logout).
 *
 * @param {string} sessionId   from `req.user.sessionId`
 * @param {string} userId
 * @param {{ userAgent?: string, ipAddress?: string }} meta
 * @returns {Promise<void>}
 */
async function logout(sessionId, userId, meta = {}) {
  await sessionRepository.revokeById(sessionId).catch(() => {
    // If the session was already revoked or doesn't exist, treat as success.
  });

  await writeAuditLog({
    action: AUTH.AUDIT.LOGOUT,
    userId,
    detail: `Session ${sessionId}`,
    ...meta,
  });
}

/**
 * Rotate a refresh token: verify the incoming token, revoke the old
 * session, create a new session, and return fresh tokens.
 *
 * @param {string} incomingRefreshToken
 * @param {{ userAgent?: string, ipAddress?: string }} meta
 * @returns {Promise<{ accessToken: string, refreshToken: string }>}
 */
async function refreshTokens(incomingRefreshToken, meta = {}) {
  // ── 1. Verify JWT signature ──────────────────────────────────
  let payload;
  try {
    payload = verifyRefreshToken(incomingRefreshToken);
  } catch {
    throw new ApiError(401, 'Invalid or expired refresh token');
  }

  if (payload.type !== 'refresh') {
    throw new ApiError(401, 'Invalid token type');
  }

  // ── 2. Look up session in DB ─────────────────────────────────
  const tokenHash = hashToken(incomingRefreshToken);
  const session = await sessionRepository.findByTokenHash(tokenHash);

  if (!session || session.isRevoked || session.expiresAt < new Date()) {
    throw new ApiError(401, 'Session is invalid or has expired. Please log in again.');
  }

  // ── 3. Verify session belongs to the claimed user ────────────
  if (session.userId !== payload.sub) {
    // Token reuse with a mismatched session — revoke everything for safety.
    await sessionRepository.revokeAllForUser(session.userId);
    throw new ApiError(401, 'Token mismatch detected. All sessions revoked for your safety.');
  }

  // ── 4. Load the user ─────────────────────────────────────────
  const user = await userRepository.findById(payload.sub);
  if (!user || !user.isActive) {
    throw new ApiError(401, 'User account is inactive');
  }

  // ── 5. Rotate: invalidate old token, issue new pair ──────────
  const newRefreshToken = signRefreshToken(buildRefreshPayload(user.id, session.id));
  const newTokenHash = hashToken(newRefreshToken);
  const newExpiresAt = expiryDateFromDuration(config.jwt.refreshExpiresIn);

  await sessionRepository.rotateToken(session.id, {
    tokenHash: newTokenHash,
    expiresAt: newExpiresAt,
  });

  const accessToken = signAccessToken(buildAccessPayload(user, session.id));

  await writeAuditLog({
    action: AUTH.AUDIT.TOKEN_REFRESHED,
    userId: user.id,
    detail: `Session ${session.id}`,
    ...meta,
  });

  return { accessToken, refreshToken: newRefreshToken };
}

/**
 * Return the authenticated user's profile (no passwordHash).
 *
 * @param {string} userId
 * @returns {Promise<object>}
 */
async function getCurrentUser(userId) {
  const user = await userRepository.findByIdSafe(userId);
  if (!user) throw new ApiError(404, 'User not found');
  return user;
}

module.exports = { login, logout, refreshTokens, getCurrentUser };
