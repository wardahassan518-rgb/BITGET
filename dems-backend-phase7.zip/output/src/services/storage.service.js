/**
 * src/services/storage.service.js
 * ────────────────────────────────────────────────────────────────
 * File-system abstraction layer (Phase 6).
 *
 * All file I/O for the application passes through here — generated
 * PDFs, QR PNGs, uploaded attachments.  Controllers and higher-level
 * services never call `fs` directly; they call these helpers instead.
 *
 * The upload root is resolved once at module load from the same env
 * key that multer.config.js uses (`UPLOAD_DIR`), so every part of
 * the system writes to exactly the same directory tree.
 *
 * Directory structure (all inside UPLOAD_ROOT):
 *   receipts/pdf/           — generated receipt PDFs
 *   receipts/qr/            — generated QR PNG images
 *   attachments/            — uploaded transaction attachments
 *   temp/                   — multer transit staging area (existing)
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const fs   = require('fs');
const path = require('path');

/** Root of the file storage tree — mirrors `config.upload.dir`. */
const UPLOAD_ROOT = path.resolve(
  process.cwd(),
  process.env.UPLOAD_DIR || 'uploads',
);

// ── Internal helpers ──────────────────────────────────────────────

/**
 * Resolve a path relative to UPLOAD_ROOT.
 * @param {...string} parts
 * @returns {string}
 */
function resolve(...parts) {
  return path.join(UPLOAD_ROOT, ...parts);
}

// ── Public API ────────────────────────────────────────────────────

/**
 * Ensure a directory (relative to UPLOAD_ROOT) exists, creating it
 * recursively if needed.  Safe to call multiple times.
 *
 * @param {string} relativePath
 * @returns {string} The absolute path that was ensured.
 */
function ensureDir(relativePath) {
  const abs = resolve(relativePath);
  if (!fs.existsSync(abs)) {
    fs.mkdirSync(abs, { recursive: true });
  }
  return abs;
}

/**
 * Save a Buffer to disk at UPLOAD_ROOT/<relativePath>.
 * The parent directory is created automatically.
 *
 * @param {Buffer}  buffer
 * @param {string}  relativePath   — e.g. 'receipts/pdf/EXC-2026-000001.pdf'
 * @returns {string} The absolute path of the written file.
 */
function saveBuffer(buffer, relativePath) {
  const abs = resolve(relativePath);
  ensureDir(path.dirname(relativePath));
  fs.writeFileSync(abs, buffer);
  return abs;
}

/**
 * Move (rename) a file within / across the UPLOAD_ROOT tree.
 * Used after multer drops a file in `temp/` to promote it to its
 * final destination directory.
 *
 * Falls back to copy-then-delete when `fs.renameSync` fails across
 * device boundaries (e.g. different mount points in Docker).
 *
 * @param {string} srcAbsPath   — absolute path to the source file
 * @param {string} dstRelPath   — destination relative to UPLOAD_ROOT
 * @returns {string} The absolute destination path.
 */
function moveFile(srcAbsPath, dstRelPath) {
  const dst = resolve(dstRelPath);
  ensureDir(path.dirname(dstRelPath));

  try {
    fs.renameSync(srcAbsPath, dst);
  } catch {
    // Cross-device fallback
    fs.copyFileSync(srcAbsPath, dst);
    fs.unlinkSync(srcAbsPath);
  }
  return dst;
}

/**
 * Delete a file at the given absolute path.
 * Silently ignores missing-file errors so callers can call this
 * unconditionally in cleanup flows.
 *
 * @param {string} absPath
 */
function deleteFile(absPath) {
  try {
    if (fs.existsSync(absPath)) {
      fs.unlinkSync(absPath);
    }
  } catch {
    // Deliberately swallowed — missing file is not an error in cleanup
  }
}

/**
 * Check whether a file exists at the given absolute path.
 *
 * @param {string} absPath
 * @returns {boolean}
 */
function fileExists(absPath) {
  return fs.existsSync(absPath);
}

/**
 * Return the absolute path for a relative path inside UPLOAD_ROOT.
 *
 * @param {string} relativePath
 * @returns {string}
 */
function getAbsPath(relativePath) {
  return resolve(relativePath);
}

/**
 * Read a file and return its Buffer.
 *
 * @param {string} absPath
 * @returns {Buffer}
 */
function readFile(absPath) {
  return fs.readFileSync(absPath);
}

/**
 * Return file size in bytes (0 if file does not exist).
 *
 * @param {string} absPath
 * @returns {number}
 */
function getFileSize(absPath) {
  try {
    return fs.statSync(absPath).size;
  } catch {
    return 0;
  }
}

module.exports = {
  UPLOAD_ROOT,
  ensureDir,
  saveBuffer,
  moveFile,
  deleteFile,
  fileExists,
  getAbsPath,
  readFile,
  getFileSize,
};
