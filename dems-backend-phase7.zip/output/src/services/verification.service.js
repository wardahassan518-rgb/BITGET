/**
 * src/services/verification.service.js
 * ────────────────────────────────────────────────────────────────
 * Verification Service (Phase 6).
 *
 * The Phase 4 Integrity Engine handles the core hash verification.
 * This Phase 6 service enriches verification with:
 *   • Full receipt / transaction details alongside the result.
 *   • Verification history (log of past scan attempts).
 *   • Aggregate stats over a date window.
 *
 * It deliberately does NOT re-implement hash logic — it calls the
 * existing integrity service for that and decorates the result.
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const integrityService        = require('./integrity.service');
const receiptRepository       = require('../repositories/receipt.repository');
const verificationRepository  = require('../repositories/verification.repository');
const { prisma }              = require('../database/prisma.client');
const { writeAuditLog }       = require('../utils/auditLog.util');
const { RECEIPT_AUDIT_ACTIONS } = require('../constants/receipt');
const { getPagination, buildMeta } = require('../utils/pagination.util');
const logger = require('../utils/logger');

// ── Helpers ───────────────────────────────────────────────────────

function ds(val) {
  if (val === null || val === undefined) return '0';
  return val.toString();
}

/** Shape a transaction object for the public verification response. */
function shapeTransactionPublic(txn) {
  if (!txn) return null;
  return {
    id:            txn.id,
    receiptNumber: txn.receiptNumber,
    txnType:       txn.txnType,
    amountPkr:     ds(txn.amountPkr),
    exchangeRate:  ds(txn.exchangeRate),
    amountUsdt:    ds(txn.amountUsdt),
    clientName:    txn.clientName  ?? null,
    clientCnic:    txn.clientCnic  ?? null,
    timestamp:     txn.timestamp,
    chainIndex:    txn.chainIndex  ?? null,
    isVoid:        txn.isVoid,
    hashVersion:   txn.hashVersion ?? null,
    isLocked:      txn.isLocked    ?? null,
  };
}

// ── Public API ────────────────────────────────────────────────────

/**
 * Perform receipt verification and return the enriched result.
 *
 * The hash check itself is delegated to integrityService so there is
 * no duplication of the hashing logic.  The result is then decorated
 * with the full receipt record and the QR verification URL.
 *
 * @param {string} receiptNumber
 * @param {{ verifierIp?: string, userAgent?: string, userId?: string }} [meta]
 * @returns {Promise<object>}
 */
async function verifyReceipt(receiptNumber, { verifierIp, userAgent, userId } = {}) {
  // Delegate to Phase 4 integrity service for the core hash check.
  // It also writes the VerificationLog row, so we don't duplicate that.
  const outcome = await integrityService.verifyByReceipt(receiptNumber, {
    verifierIp: verifierIp ?? null,
    userAgent:  userAgent  ?? null,
  });

  // Attempt to fetch enriched receipt data (may not exist yet for older txns)
  let receiptData = null;
  try {
    receiptData = await receiptRepository.findByReceiptNumber(receiptNumber);
  } catch (err) {
    logger.warn(`[Verification] Could not load receipt for ${receiptNumber}: ${err.message}`);
  }

  // Optionally write an audit entry for authenticated verification views
  if (userId) {
    await writeAuditLog(prisma, {
      action:    RECEIPT_AUDIT_ACTIONS.VERIFICATION_VIEWED,
      detail:    `Verification viewed for ${receiptNumber}: ${outcome.result}`,
      userId:    userId ?? null,
      userAgent: userAgent ?? null,
    }, { silent: true });
  }

  const txn = outcome.transaction ?? receiptData?.transaction ?? null;

  return {
    result:        outcome.result,
    label:         outcome.label,
    message:       outcome.message,
    receiptNumber,
    transaction:   shapeTransactionPublic(txn),
    receipt: receiptData ? {
      id:          receiptData.id,
      pdfPath:     receiptData.pdfPath    ?? null,
      qrData:      receiptData.qrData     ?? null,
      printCount:  receiptData.printCount,
      shareCount:  receiptData.shareCount,
      generatedAt: receiptData.generatedAt,
    } : null,
    verifiedAt: new Date().toISOString(),
  };
}

/**
 * Return the verification history log for a specific receipt number.
 *
 * @param {string} receiptNumber
 * @param {{ limit?: number }} [query]
 * @returns {Promise<{ history: object[], resultCounts: object[] }>}
 */
async function getVerificationHistory(receiptNumber, { limit = 50 } = {}) {
  const [history, rawCounts] = await Promise.all([
    verificationRepository.getHistory(receiptNumber, Math.min(limit, 200)),
    verificationRepository.getResultCounts(receiptNumber),
  ]);

  const resultCounts = rawCounts.map((r) => ({
    result: r.result,
    count:  Number(r.count),
  }));

  return { receiptNumber, history, resultCounts, totalAttempts: history.length };
}

/**
 * Paginated verification log with optional filters.
 *
 * @param {object} query — validated verificationLogQuerySchema
 * @returns {Promise<object>}
 */
async function getVerificationLog(query) {
  const { page, limit, skip, take } = getPagination(query);

  const where = {};
  if (query.result)        where.result        = query.result;
  if (query.receiptNumber) where.receiptNumber = { contains: query.receiptNumber, mode: 'insensitive' };
  if (query.from || query.to) {
    where.verifiedAt = {};
    if (query.from) where.verifiedAt.gte = query.from;
    if (query.to)   where.verifiedAt.lte = query.to;
  }

  const [logs, totalItems] = await Promise.all([
    verificationRepository.list({ where, skip, take }),
    verificationRepository.countList(where),
  ]);

  return {
    logs,
    meta: buildMeta(page, limit, totalItems),
  };
}

/**
 * Summary stats over a date window — count by result type + top verified receipts.
 *
 * @param {{ from?: Date, to?: Date }} [query]
 * @returns {Promise<object>}
 */
async function getVerificationStats({ from, to } = {}) {
  const now  = new Date();
  const toD  = to   ?? new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
  const fromD= from ?? new Date(now.getTime() - 29 * 86400000);

  const [summary, topVerified] = await Promise.all([
    verificationRepository.getSummaryByResult(fromD, toD),
    verificationRepository.getTopVerified(fromD, toD, 10),
  ]);

  return {
    window: { from: fromD.toISOString(), to: toD.toISOString() },
    byResult:    summary.map((r)    => ({ result: r.result, count: Number(r.count) })),
    topVerified: topVerified.map((r) => ({
      receiptNumber: r.receipt_number,
      count:         Number(r.count),
      lastResult:    r.last_result,
    })),
    generatedAt: now.toISOString(),
  };
}

module.exports = {
  verifyReceipt,
  getVerificationHistory,
  getVerificationLog,
  getVerificationStats,
};
