/**
 * src/services/receipt.service.js
 * ────────────────────────────────────────────────────────────────
 * Receipt Service (Phase 6).
 *
 * Orchestrates the full receipt lifecycle:
 *   • ensureReceipt()       — create or return the Receipt record
 *                             for a given transaction (idempotent)
 *   • getReceiptByNumber()  — fetch full receipt + transaction data
 *   • generatePdf()         — invoke PDF service, persist path
 *   • generateQr()          — invoke QR service, persist qrData URL
 *   • servePdf()            — resolve the PDF abs-path for streaming
 *   • logPrint()            — increment print count + audit
 *   • logShare()            — increment share count + audit
 *   • listReceipts()        — paginated admin list
 *
 * All file-system work is delegated to storage.service (via
 * pdf.service / qr.service). This service only orchestrates and
 * writes DB records.
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const { prisma }          = require('../database/prisma.client');
const receiptRepository   = require('../repositories/receipt.repository');
const pdfService          = require('./pdf.service');
const qrService           = require('./qr.service');
const storage             = require('./storage.service');
const { writeAuditLog }   = require('../utils/auditLog.util');
const { RECEIPT_AUDIT_ACTIONS } = require('../constants/receipt');
const { getPagination, buildMeta } = require('../utils/pagination.util');
const ApiError            = require('../utils/ApiError');
const logger              = require('../utils/logger');

// ── Helpers ───────────────────────────────────────────────────────

function ds(val) {
  if (val === null || val === undefined) return '0';
  return val.toString();
}

/** Shape the full receipt object returned to the API consumer. */
function shapeReceipt(rec) {
  if (!rec) return null;
  const txn = rec.transaction;
  return {
    id:            rec.id,
    receiptNumber: rec.receiptNumber,
    pdfPath:       rec.pdfPath   ?? null,
    qrData:        rec.qrData    ?? null,
    printCount:    rec.printCount,
    shareCount:    rec.shareCount,
    generatedAt:   rec.generatedAt,
    transaction: txn ? {
      id:            txn.id,
      receiptNumber: txn.receiptNumber,
      txnType:       txn.txnType,
      amountPkr:     ds(txn.amountPkr),
      exchangeRate:  ds(txn.exchangeRate),
      amountUsdt:    ds(txn.amountUsdt),
      profitPkr:     ds(txn.profitPkr),
      clientName:    txn.clientName  ?? null,
      clientCnic:    txn.clientCnic  ?? null,
      bankName:      txn.bankName    ?? null,
      bankLast4:     txn.bankLast4   ?? null,
      paymentRef:    txn.paymentRef  ?? null,
      orderId:       txn.orderId     ?? null,
      notes:         txn.notes       ?? null,
      timestamp:     txn.timestamp,
      chainIndex:    txn.chainIndex  ?? null,
      hash:          txn.hash        ?? null,
      hashVersion:   txn.hashVersion ?? null,
      isLocked:      txn.isLocked,
      isVoid:        txn.isVoid,
      client:        txn.client      ?? null,
      attachments:   txn.attachments ?? [],
    } : null,
  };
}

// ── Public API ────────────────────────────────────────────────────

/**
 * Idempotent: create or retrieve the Receipt record for a transaction.
 *
 * @param {string} transactionId
 * @param {{ userId?: string, userAgent?: string }} [meta]
 * @returns {Promise<object>} Shaped receipt object
 */
async function ensureReceipt(transactionId, { userId, userAgent } = {}) {
  const txn = await prisma.transaction.findUnique({
    where:   { id: transactionId },
    include: {
      client:      { select: { id: true, fullName: true, cnic: true, isVerified: true } },
      attachments: { orderBy: { uploadedAt: 'asc' } },
    },
  });
  if (!txn) throw new ApiError(404, `Transaction ${transactionId} not found.`);

  const qrUrl = qrService.buildVerifyUrl(txn.receiptNumber);

  const rec = await receiptRepository.upsert({
    transactionId:  txn.id,
    receiptNumber:  txn.receiptNumber,
    qrData:         qrUrl,
  });

  // Write audit only on creation (printCount === 0 && shareCount === 0 is a proxy)
  if (rec.printCount === 0 && rec.shareCount === 0) {
    await writeAuditLog(prisma, {
      action:    RECEIPT_AUDIT_ACTIONS.RECEIPT_VIEWED,
      detail:    `Receipt record ensured for ${txn.receiptNumber}`,
      userId:    userId    ?? null,
      userAgent: userAgent ?? null,
    }, { silent: true });
  }

  // Reload with full transaction so the shape helper has everything
  const full = await receiptRepository.findByReceiptNumber(txn.receiptNumber);
  return shapeReceipt(full);
}

/**
 * Fetch the full receipt by receipt number.
 *
 * @param {string} receiptNumber
 * @returns {Promise<object>}
 */
async function getReceiptByNumber(receiptNumber) {
  const rec = await receiptRepository.findByReceiptNumber(receiptNumber);
  if (!rec) throw new ApiError(404, `Receipt ${receiptNumber} not found.`);
  return shapeReceipt(rec);
}

/**
 * Generate (or regenerate) the PDF for a receipt.
 * Persists the relative path back to the Receipt record.
 *
 * @param {string} receiptNumber
 * @param {{ userId?: string, userAgent?: string }} [meta]
 * @returns {Promise<{ receipt: object, pdf: { relPath, sizeBytes } }>}
 */
async function generatePdf(receiptNumber, { userId, userAgent } = {}) {
  const rec = await receiptRepository.findByReceiptNumber(receiptNumber);
  if (!rec) throw new ApiError(404, `Receipt ${receiptNumber} not found.`);

  // Load business profile (single row — null if not set up yet)
  const business = await prisma.businessProfile.findFirst();

  const { relPath, sizeBytes } = await pdfService.generateReceiptPdf({
    transaction: rec.transaction,
    business:    business ?? null,
  });

  // Persist pdf path
  await receiptRepository.setPdfPath(rec.id, relPath);

  await writeAuditLog(prisma, {
    action:    RECEIPT_AUDIT_ACTIONS.RECEIPT_PDF_GENERATED,
    detail:    `PDF generated for ${receiptNumber} (${sizeBytes} bytes)`,
    userId:    userId    ?? null,
    userAgent: userAgent ?? null,
  }, { silent: true });

  const updated = await receiptRepository.findByReceiptNumber(receiptNumber);
  return { receipt: shapeReceipt(updated), pdf: { relPath, sizeBytes } };
}

/**
 * Generate (or regenerate) the QR PNG file for a receipt.
 *
 * @param {string} receiptNumber
 * @returns {Promise<{ relPath: string, url: string }>}
 */
async function generateQr(receiptNumber) {
  const rec = await receiptRepository.findByReceiptNumber(receiptNumber);
  if (!rec) throw new ApiError(404, `Receipt ${receiptNumber} not found.`);

  const { relPath, url } = await qrService.generateQrFile(receiptNumber);

  // Update qrData with the canonical URL (idempotent)
  await receiptRepository.setQrData(rec.id, url);

  return { relPath, url };
}

/**
 * Resolve the absolute path of a receipt PDF, generating it on the
 * fly if the file is missing from disk.
 *
 * @param {string} receiptNumber
 * @param {{ userId?: string, userAgent?: string }} [meta]
 * @returns {Promise<{ absPath: string, filename: string }>}
 */
async function servePdf(receiptNumber, { userId, userAgent } = {}) {
  let rec = await receiptRepository.findByReceiptNumber(receiptNumber);
  if (!rec) throw new ApiError(404, `Receipt ${receiptNumber} not found.`);

  let absPath = rec.pdfPath ? storage.getAbsPath(rec.pdfPath) : null;

  // Generate if the file is missing
  if (!absPath || !storage.fileExists(absPath)) {
    logger.debug(`[Receipt] PDF missing — generating on-demand for ${receiptNumber}`);
    const { pdf } = await generatePdf(receiptNumber, { userId, userAgent });
    absPath = storage.getAbsPath(pdf.relPath);
    rec = await receiptRepository.findByReceiptNumber(receiptNumber);
  }

  if (!storage.fileExists(absPath)) {
    throw new ApiError(500, `PDF could not be generated for ${receiptNumber}.`);
  }

  return { absPath, filename: `${receiptNumber}.pdf` };
}

/**
 * Increment print count and write audit log.
 *
 * @param {string} receiptNumber
 * @param {{ userId?: string, userAgent?: string }} [meta]
 */
async function logPrint(receiptNumber, { userId, userAgent } = {}) {
  const rec = await receiptRepository.findByReceiptNumber(receiptNumber);
  if (!rec) throw new ApiError(404, `Receipt ${receiptNumber} not found.`);

  await receiptRepository.incrementPrintCount(rec.id);

  await writeAuditLog(prisma, {
    action:    RECEIPT_AUDIT_ACTIONS.RECEIPT_PRINTED,
    detail:    `Receipt ${receiptNumber} printed`,
    userId:    userId    ?? null,
    userAgent: userAgent ?? null,
  }, { silent: true });
}

/**
 * Increment share count and write audit log.
 *
 * @param {string} receiptNumber
 * @param {{ userId?: string, userAgent?: string }} [meta]
 */
async function logShare(receiptNumber, { userId, userAgent } = {}) {
  const rec = await receiptRepository.findByReceiptNumber(receiptNumber);
  if (!rec) throw new ApiError(404, `Receipt ${receiptNumber} not found.`);

  await receiptRepository.incrementShareCount(rec.id);

  await writeAuditLog(prisma, {
    action:    RECEIPT_AUDIT_ACTIONS.RECEIPT_SHARED,
    detail:    `Receipt ${receiptNumber} shared`,
    userId:    userId    ?? null,
    userAgent: userAgent ?? null,
  }, { silent: true });
}

/**
 * Paginated list of receipts for admin views.
 *
 * @param {object} query
 * @returns {Promise<{ receipts: object[], meta: object }>}
 */
async function listReceipts(query = {}) {
  const { page, limit, skip, take } = getPagination(query);

  const [rows, totalItems] = await Promise.all([
    receiptRepository.listReceipts({ skip, take }),
    receiptRepository.countReceipts(),
  ]);

  return {
    receipts: rows.map(shapeReceipt),
    meta:     buildMeta(page, limit, totalItems),
  };
}

module.exports = {
  ensureReceipt,
  getReceiptByNumber,
  generatePdf,
  generateQr,
  servePdf,
  logPrint,
  logShare,
  listReceipts,
};
