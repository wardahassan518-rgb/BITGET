/**
 * src/services/qr.service.js
 * ────────────────────────────────────────────────────────────────
 * QR Code Generation Service (Phase 6).
 *
 * Generates QR code PNG images that encode a public verification URL.
 * The URL points to the existing public endpoint from Phase 4:
 *
 *   GET /api/verify/:receipt
 *
 * When a user scans the QR code with any QR scanner / camera app,
 * their browser opens that URL and gets the Verified / Tampered /
 * Not Found result without needing authentication.
 *
 * Base URL resolution order (first wins):
 *   1. APP_BASE_URL env variable   — set in production  e.g. https://dems.example.com
 *   2. http://localhost:<PORT>      — development fallback
 *
 * Generated PNGs are saved to:
 *   <UPLOAD_ROOT>/receipts/qr/<receiptNumber>.png
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const path    = require('path');
const QRCode  = require('qrcode');
const storage = require('./storage.service');
const { QR_OPTIONS, RECEIPT_DIRS } = require('../constants/receipt');
const logger  = require('../utils/logger');

// ── Base URL for QR content ───────────────────────────────────────

function getBaseUrl() {
  return (
    process.env.APP_BASE_URL ||
    `http://localhost:${process.env.PORT || 5000}`
  ).replace(/\/$/, ''); // strip trailing slash
}

/**
 * Build the public verification URL for a receipt number.
 *
 * @param {string} receiptNumber — e.g. EXC-2026-000001
 * @returns {string}             — e.g. https://dems.example.com/api/verify/EXC-2026-000001
 */
function buildVerifyUrl(receiptNumber) {
  return `${getBaseUrl()}/api/verify/${encodeURIComponent(receiptNumber)}`;
}

// ── Public API ────────────────────────────────────────────────────

/**
 * Generate a QR code PNG as a Buffer (in-memory, not saved to disk).
 * Use this when you need the PNG bytes without persisting them —
 * e.g. embedding inline in a PDF.
 *
 * @param {string} receiptNumber
 * @returns {Promise<Buffer>} PNG image buffer
 */
async function generateQrBuffer(receiptNumber) {
  const url = buildVerifyUrl(receiptNumber);
  const buffer = await QRCode.toBuffer(url, QR_OPTIONS);
  return buffer;
}

/**
 * Generate a QR code PNG and save it to disk.
 * Returns the absolute path on success.
 *
 * Idempotent — if the file already exists it is overwritten so that
 * a re-generate call always produces a fresh image.
 *
 * @param {string} receiptNumber
 * @returns {Promise<{ absPath: string, relPath: string, url: string }>}
 */
async function generateQrFile(receiptNumber) {
  const relPath = path.posix.join(RECEIPT_DIRS.QR, `${receiptNumber}.png`);
  const url     = buildVerifyUrl(receiptNumber);

  logger.debug(`[QR] Generating QR for ${receiptNumber} → ${url}`);

  const buffer  = await QRCode.toBuffer(url, QR_OPTIONS);
  const absPath = storage.saveBuffer(buffer, relPath);

  logger.debug(`[QR] Saved QR PNG: ${absPath}`);

  return { absPath, relPath, url };
}

/**
 * Return the absolute path to a previously generated QR file.
 * Returns null if the file does not exist (caller should generate first).
 *
 * @param {string} receiptNumber
 * @returns {string | null}
 */
function getQrPath(receiptNumber) {
  const relPath = path.posix.join(RECEIPT_DIRS.QR, `${receiptNumber}.png`);
  const abs     = storage.getAbsPath(relPath);
  return storage.fileExists(abs) ? abs : null;
}

module.exports = {
  buildVerifyUrl,
  generateQrBuffer,
  generateQrFile,
  getQrPath,
};
