/**
 * src/services/pdf.service.js
 * ────────────────────────────────────────────────────────────────
 * Server-side Receipt PDF Generation Service (Phase 6).
 *
 * Uses PDFKit (pure-JS, no native dependencies) to compose a
 * professional receipt document from:
 *   • BusinessProfile   — header (name, address, contact, logo emoji)
 *   • Transaction       — amounts, rate, client details, bank info
 *   • QR code PNG       — embedded at the bottom for scan-to-verify
 *   • Integrity data    — chain index, hash snippet, seal status
 *
 * Layout (A4, portrait):
 *   ┌──────────────────────────────┐
 *   │  [EMOJI]  BUSINESS NAME      │  ← header
 *   │  Address · City · Phone      │
 *   ├──────────────────────────────┤
 *   │  RECEIPT   EXC-2026-000001   │  ← receipt identity
 *   │  Date / Time (UTC)           │
 *   │  Type: BUY / SELL            │
 *   ├──────────────────────────────┤
 *   │  CLIENT DETAILS              │  ← client block
 *   │  Name / CNIC / Bank          │
 *   ├──────────────────────────────┤
 *   │  TRANSACTION DETAILS         │  ← amounts
 *   │  PKR · Rate · USDT           │
 *   │  Notes / Payment Ref         │
 *   ├──────────────────────────────┤
 *   │  INTEGRITY                   │  ← chain info
 *   │  Chain #42  ✓ Sealed         │
 *   │  Hash: abc…xyz               │
 *   ├──────────────────────────────┤
 *   │  [QR CODE]                   │  ← scan to verify
 *   │  Scan to verify authenticity │
 *   ├──────────────────────────────┤
 *   │  Footer text                 │  ← business receipt_footer
 *   └──────────────────────────────┘
 *
 * All generated PDFs are saved to:
 *   <UPLOAD_ROOT>/receipts/pdf/<receiptNumber>.pdf
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const path    = require('path');
const PDFDocument = require('pdfkit');
const qrService   = require('./qr.service');
const storage     = require('./storage.service');
const { RECEIPT_DIRS } = require('../constants/receipt');
const logger      = require('../utils/logger');

// ── Palette & metrics ─────────────────────────────────────────────

const C = {
  BLACK:      '#1A1A2E',
  ACCENT:     '#16213E',
  TEAL:       '#0F3460',
  LIGHT_GREY: '#F5F5F5',
  MID_GREY:   '#CCCCCC',
  TEXT_BODY:  '#333333',
  TEXT_MUTED: '#777777',
  GREEN:      '#2D6A4F',
  RED:        '#C0392B',
  WHITE:      '#FFFFFF',
};

const PAGE  = { width: 595, height: 842, margin: 45 };
const COL_W = PAGE.width - PAGE.margin * 2;

// ── Formatting helpers ────────────────────────────────────────────

function fmtPkr(val) {
  if (!val) return 'PKR 0.00';
  const n = parseFloat(val.toString());
  return `PKR ${n.toLocaleString('en-PK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function fmtUsdt(val) {
  if (!val) return '—';
  const n = parseFloat(val.toString());
  return `${n.toLocaleString('en-US', { minimumFractionDigits: 4, maximumFractionDigits: 4 })} USDT`;
}

function fmtRate(val) {
  if (!val) return '—';
  const n = parseFloat(val.toString());
  return n.toLocaleString('en-PK', { minimumFractionDigits: 2, maximumFractionDigits: 4 });
}

function fmtDateTime(d) {
  const dt = d instanceof Date ? d : new Date(d);
  return dt.toUTCString().replace('GMT', 'UTC');
}

// ── PDF builder ───────────────────────────────────────────────────

/**
 * Draw a horizontal divider rule.
 */
function hRule(doc, y, color = C.MID_GREY) {
  doc
    .moveTo(PAGE.margin, y)
    .lineTo(PAGE.width - PAGE.margin, y)
    .strokeColor(color)
    .lineWidth(0.5)
    .stroke();
  return y + 6;
}

/**
 * Draw a two-column key/value row.
 * @returns {number} New y position after the row.
 */
function kvRow(doc, label, value, y, opts = {}) {
  const { labelColor = C.TEXT_MUTED, valueColor = C.TEXT_BODY, bold = false } = opts;
  const halfW = COL_W / 2;

  doc
    .font('Helvetica')
    .fontSize(9)
    .fillColor(labelColor)
    .text(label, PAGE.margin, y, { width: halfW, align: 'left' });

  doc
    .font(bold ? 'Helvetica-Bold' : 'Helvetica')
    .fontSize(9)
    .fillColor(valueColor)
    .text(value || '—', PAGE.margin + halfW, y, { width: halfW, align: 'right' });

  return y + 16;
}

/**
 * Draw a section header label.
 * @returns {number} New y position.
 */
function sectionHeader(doc, label, y) {
  doc
    .fillColor(C.ACCENT)
    .rect(PAGE.margin, y, COL_W, 18)
    .fill();

  doc
    .font('Helvetica-Bold')
    .fontSize(8)
    .fillColor(C.WHITE)
    .text(label.toUpperCase(), PAGE.margin + 6, y + 5, { width: COL_W, align: 'left' });

  return y + 24;
}

// ── Main export ───────────────────────────────────────────────────

/**
 * Generate a receipt PDF and save it to disk.
 *
 * @param {object} params
 * @param {object} params.transaction   — full Transaction + client from Prisma
 * @param {object} [params.business]    — BusinessProfile row (or null)
 * @returns {Promise<{ absPath: string, relPath: string, sizeBytes: number }>}
 */
async function generateReceiptPdf({ transaction, business = null }) {
  const { receiptNumber } = transaction;
  const relPath = path.posix.join(RECEIPT_DIRS.PDF, `${receiptNumber}.pdf`);
  const absPath = storage.getAbsPath(relPath);

  logger.debug(`[PDF] Generating receipt PDF: ${receiptNumber}`);

  // ── QR code: generate in-memory PNG buffer ──────────────────────
  let qrBuffer = null;
  try {
    qrBuffer = await qrService.generateQrBuffer(receiptNumber);
  } catch (err) {
    logger.warn(`[PDF] QR generation failed for ${receiptNumber}: ${err.message}`);
  }

  // ── Build PDF in memory then flush to disk ──────────────────────
  const pdfBuffer = await new Promise((resolve, reject) => {
    const doc    = new PDFDocument({ size: 'A4', margin: PAGE.margin, info: {
      Title:   `DEMS Receipt ${receiptNumber}`,
      Author:  business?.businessName || 'DEMS Exchange',
      Subject: 'Transaction Receipt',
    }});
    const chunks = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end',  () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    let y = PAGE.margin;

    // ── HEADER ────────────────────────────────────────────────────
    const bName = business?.businessName || 'Digital Exchange';
    const emoji = business?.logoEmoji    || '🏦';
    const bCity = [business?.area, business?.city].filter(Boolean).join(', ');
    const bAddr = [business?.address, bCity].filter(Boolean).join(' — ');
    const bPhone = [business?.phone, business?.whatsapp].filter(Boolean).join(' / ');
    const bLicenses = [
      business?.secpNumber ? `SECP: ${business.secpNumber}` : null,
      business?.ntnNumber  ? `NTN: ${business.ntnNumber}`   : null,
    ].filter(Boolean).join('  ·  ');

    // Background bar
    doc.fillColor(C.ACCENT).rect(0, 0, PAGE.width, 90).fill();

    // Business name
    doc
      .font('Helvetica-Bold')
      .fontSize(20)
      .fillColor(C.WHITE)
      .text(`${emoji}  ${bName}`, PAGE.margin, 18, { width: COL_W });

    if (bAddr) {
      doc.font('Helvetica').fontSize(8).fillColor(C.MID_GREY)
        .text(bAddr, PAGE.margin, 44, { width: COL_W });
    }
    const secondLine = [bPhone, bLicenses].filter(Boolean).join('   ');
    if (secondLine) {
      doc.font('Helvetica').fontSize(8).fillColor(C.MID_GREY)
        .text(secondLine, PAGE.margin, 56, { width: COL_W });
    }

    y = 100;

    // ── RECEIPT IDENTITY ─────────────────────────────────────────
    const txnTypeLabel = transaction.txnType === 'BUY' ? 'BUY (Purchase)' : 'SELL (Sale)';
    const typeColor    = transaction.txnType === 'BUY' ? C.TEAL : C.RED;

    doc
      .font('Helvetica-Bold').fontSize(14).fillColor(C.BLACK)
      .text('RECEIPT', PAGE.margin, y, { width: COL_W / 2, align: 'left' });

    doc
      .font('Helvetica-Bold').fontSize(14).fillColor(C.TEXT_BODY)
      .text(receiptNumber, PAGE.margin, y, { width: COL_W, align: 'right' });

    y += 20;

    doc.font('Helvetica').fontSize(9).fillColor(C.TEXT_MUTED)
      .text(fmtDateTime(transaction.timestamp), PAGE.margin, y, { width: COL_W / 2 });

    doc.font('Helvetica-Bold').fontSize(9).fillColor(typeColor)
      .text(txnTypeLabel, PAGE.margin, y, { width: COL_W, align: 'right' });

    y += 20;
    y = hRule(doc, y);
    y += 4;

    // ── CLIENT DETAILS ───────────────────────────────────────────
    if (transaction.clientName || transaction.clientCnic) {
      y = sectionHeader(doc, 'Client Details', y);
      if (transaction.clientName) y = kvRow(doc, 'Name',         transaction.clientName, y);
      if (transaction.clientCnic) y = kvRow(doc, 'CNIC',         transaction.clientCnic, y);
      if (transaction.client?.isVerified !== undefined) {
        y = kvRow(doc, 'KYC Status',
          transaction.client?.isVerified ? '✓ Verified' : '○ Unverified', y,
          { valueColor: transaction.client?.isVerified ? C.GREEN : C.TEXT_MUTED });
      }
      y += 6;
    }

    // ── TRANSACTION DETAILS ───────────────────────────────────────
    y = sectionHeader(doc, 'Transaction Details', y);
    y = kvRow(doc, 'Amount (PKR)',    fmtPkr(transaction.amountPkr),   y, { bold: true, valueColor: C.BLACK });
    y = kvRow(doc, 'Exchange Rate',   fmtRate(transaction.exchangeRate), y);
    y = kvRow(doc, 'Amount (USDT)',   fmtUsdt(transaction.amountUsdt),  y);

    if (transaction.profitPkr && parseFloat(transaction.profitPkr.toString()) !== 0) {
      y = kvRow(doc, 'Profit (PKR)', fmtPkr(transaction.profitPkr), y,
        { valueColor: C.GREEN });
    }

    y += 4;

    if (transaction.bankName) {
      y = kvRow(doc, 'Bank',         transaction.bankName, y);
    }
    if (transaction.bankLast4) {
      y = kvRow(doc, 'Account (last 4)', `····${transaction.bankLast4}`, y);
    }
    if (transaction.paymentRef) {
      y = kvRow(doc, 'Payment Ref',  transaction.paymentRef, y);
    }
    if (transaction.orderId) {
      y = kvRow(doc, 'Order ID',     transaction.orderId, y);
    }
    if (transaction.notes) {
      y += 4;
      doc.font('Helvetica').fontSize(9).fillColor(C.TEXT_MUTED).text('Notes:', PAGE.margin, y);
      y += 12;
      doc.font('Helvetica').fontSize(8).fillColor(C.TEXT_BODY)
        .text(transaction.notes, PAGE.margin + 8, y, { width: COL_W - 8 });
      y += doc.heightOfString(transaction.notes, { width: COL_W - 8 }) + 6;
    }

    y += 6;

    // ── INTEGRITY ─────────────────────────────────────────────────
    y = sectionHeader(doc, 'Integrity & Authenticity', y);

    const isSealed = !!transaction.hash;
    const hashSnippet = transaction.hash
      ? `${transaction.hash.slice(0, 16)}…${transaction.hash.slice(-8)}`
      : '—';

    if (transaction.chainIndex !== null && transaction.chainIndex !== undefined) {
      y = kvRow(doc, 'Chain Position', `#${transaction.chainIndex}`, y);
    }
    y = kvRow(doc, 'Seal Status',
      isSealed ? '✓ Sealed & Hash-Locked' : '○ Unsealed',
      y, { valueColor: isSealed ? C.GREEN : C.TEXT_MUTED, bold: isSealed });

    if (isSealed) {
      y = kvRow(doc, 'SHA-256', hashSnippet, y,
        { labelColor: C.TEXT_MUTED, valueColor: C.TEXT_MUTED });
      y = kvRow(doc, 'Hash Version', transaction.hashVersion || 'DEMS_V2', y);
    }

    y += 10;

    // ── QR CODE ───────────────────────────────────────────────────
    const qrSide = 100;
    const qrX    = PAGE.width - PAGE.margin - qrSide;

    if (qrBuffer) {
      doc.image(qrBuffer, qrX, y, { width: qrSide, height: qrSide });

      doc.font('Helvetica').fontSize(7).fillColor(C.TEXT_MUTED)
        .text('Scan to verify', qrX, y + qrSide + 3, { width: qrSide, align: 'center' });

      doc.font('Helvetica').fontSize(7.5).fillColor(C.TEXT_BODY)
        .text(qrService.buildVerifyUrl(receiptNumber), PAGE.margin, y + 4,
          { width: COL_W - qrSide - 10, align: 'left' });

      doc.font('Helvetica').fontSize(7).fillColor(C.TEXT_MUTED)
        .text('Scan the QR code or visit the URL above to verify the\nauthenticity of this receipt on the DEMS blockchain ledger.',
          PAGE.margin, y + 20, { width: COL_W - qrSide - 10 });

      y = Math.max(y + qrSide + 14, y + 60) + 10;
    } else {
      const verifyUrl = qrService.buildVerifyUrl(receiptNumber);
      doc.font('Helvetica').fontSize(8).fillColor(C.TEXT_BODY)
        .text(`Verify at: ${verifyUrl}`, PAGE.margin, y, { width: COL_W });
      y += 20;
    }

    y = hRule(doc, y);

    // ── FOOTER ────────────────────────────────────────────────────
    const footerText = business?.receiptFooter ||
      'This is a computer-generated receipt. For queries contact the exchange office.';

    doc.font('Helvetica').fontSize(7.5).fillColor(C.TEXT_MUTED)
      .text(footerText, PAGE.margin, y + 4, { width: COL_W, align: 'center' });

    doc.end();
  });

  // ── Persist to disk ───────────────────────────────────────────
  storage.ensureDir(RECEIPT_DIRS.PDF);
  storage.saveBuffer(pdfBuffer, relPath);

  const sizeBytes = storage.getFileSize(absPath);
  logger.debug(`[PDF] Saved receipt PDF: ${absPath} (${sizeBytes} bytes)`);

  return { absPath, relPath, sizeBytes };
}

module.exports = { generateReceiptPdf };
