/**
 * src/services/dashboard.service.js
 * ────────────────────────────────────────────────────────────────
 * Business logic for the Dashboard module (Phase 5).
 *
 * This service assembles repository results into the shaped objects
 * the controllers return.  Metric computations (percentages, period
 * comparisons) happen here — not in the repository (data access only)
 * and not in the controller (HTTP concerns only).
 *
 * All timestamps use UTC midnight/end-of-day boundaries so results
 * are deterministic regardless of the caller's timezone.
 * ────────────────────────────────────────────────────────────────
 */

const dashboardRepository = require('../repositories/dashboard.repository');

// ────────────────────────────────────────────────────────────────
//  Date helpers
// ────────────────────────────────────────────────────────────────

/** Start of a given UTC day (00:00:00.000). */
function utcDayStart(d) {
  const dt = new Date(d);
  dt.setUTCHours(0, 0, 0, 0);
  return dt;
}

/** End of a given UTC day (23:59:59.999). */
function utcDayEnd(d) {
  const dt = new Date(d);
  dt.setUTCHours(23, 59, 59, 999);
  return dt;
}

/** Start of the current UTC month. */
function thisMonthStart() {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1, 0, 0, 0, 0));
}

/** End of the current UTC month (last millisecond of last day). */
function thisMonthEnd() {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 0, 23, 59, 59, 999));
}

/** Safely convert Prisma Decimal / null to a plain JS number string. */
function toDecimalString(val) {
  if (val === null || val === undefined) return '0.00';
  return val.toString();
}

/**
 * Compute a % change between two numeric values.
 * Returns null when the base is zero (division by zero).
 *
 * @param {number} current
 * @param {number} previous
 * @returns {number|null}
 */
function pctChange(current, previous) {
  if (previous === 0) return current > 0 ? 100 : null;
  return parseFloat((((current - previous) / previous) * 100).toFixed(2));
}

// ────────────────────────────────────────────────────────────────
//  Service methods
// ────────────────────────────────────────────────────────────────

/**
 * Full dashboard summary — overall totals, today's stats, this
 * month's stats, period-over-period comparisons, chain status.
 *
 * @param {{ from?: Date, to?: Date }} [query]
 * @returns {Promise<object>}
 */
async function getSummary({ from, to } = {}) {
  const now      = new Date();
  const todayS   = utcDayStart(now);
  const todayE   = utcDayEnd(now);
  const monthS   = thisMonthStart();
  const monthE   = thisMonthEnd();

  // Yesterday for day-over-day comparison
  const yest    = new Date(now);
  yest.setUTCDate(yest.getUTCDate() - 1);
  const yesterdayS = utcDayStart(yest);
  const yesterdayE = utcDayEnd(yest);

  // Last month for month-over-month comparison
  const lastMonthS = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 1, 1));
  const lastMonthE = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 0, 23, 59, 59, 999));

  const [
    totals,
    totalClients,
    today,
    yesterday,
    thisMonth,
    lastMonth,
    chainStatus,
  ] = await Promise.all([
    dashboardRepository.getOverallTotals(),
    dashboardRepository.getTotalClients(),
    dashboardRepository.getPeriodStats(todayS, todayE),
    dashboardRepository.getPeriodStats(yesterdayS, yesterdayE),
    dashboardRepository.getPeriodStats(monthS, monthE),
    dashboardRepository.getPeriodStats(lastMonthS, lastMonthE),
    dashboardRepository.getChainStatus(),
  ]);

  return {
    totals: {
      transactions: totals.totalTxns,
      clients:      totalClients,
      volume: {
        pkr:  toDecimalString(totals.totalPkr),
        usdt: toDecimalString(totals.totalUsdt),
      },
      byType: {
        buy:  totals.buyCount,
        sell: totals.sellCount,
      },
    },

    today: {
      transactions: today.count,
      volume: {
        pkr:  toDecimalString(today.pkrVolume),
        usdt: toDecimalString(today.usdtVolume),
      },
      profit:    toDecimalString(today.profitPkr),
      byType: {
        buy:  today.buyCount,
        sell: today.sellCount,
      },
      vsYesterday: {
        transactions: pctChange(today.count, yesterday.count),
        pkrVolume:    pctChange(
          parseFloat(toDecimalString(today.pkrVolume)),
          parseFloat(toDecimalString(yesterday.pkrVolume)),
        ),
      },
    },

    thisMonth: {
      transactions: thisMonth.count,
      volume: {
        pkr:  toDecimalString(thisMonth.pkrVolume),
        usdt: toDecimalString(thisMonth.usdtVolume),
      },
      profit:    toDecimalString(thisMonth.profitPkr),
      byType: {
        buy:  thisMonth.buyCount,
        sell: thisMonth.sellCount,
      },
      vsLastMonth: {
        transactions: pctChange(thisMonth.count, lastMonth.count),
        pkrVolume:    pctChange(
          parseFloat(toDecimalString(thisMonth.pkrVolume)),
          parseFloat(toDecimalString(lastMonth.pkrVolume)),
        ),
      },
    },

    integrity: {
      totalSealed:   chainStatus.totalSealed,
      totalUnsealed: chainStatus.totalUnsealed,
      allSealed:     chainStatus.totalUnsealed === 0,
    },

    generatedAt: now.toISOString(),
  };
}

/**
 * Time-series data for dashboard charts.
 *
 * @param {{ days?: number, from?: Date, to?: Date, granularity?: 'day'|'month' }} query
 * @returns {Promise<object>}
 */
async function getCharts({ days, from, to, granularity = 'day' } = {}) {
  // Resolve date window
  const toDate   = to   ?? utcDayEnd(new Date());
  const fromDate = from ?? utcDayStart(new Date(toDate.getTime() - ((days ?? 30) - 1) * 86400000));

  const rawRows = granularity === 'month'
    ? await dashboardRepository.getMonthlyChartData(fromDate, toDate)
    : await dashboardRepository.getDailyChartData(fromDate, toDate);

  // Normalise raw SQL numbers (BigInt / Decimal from Postgres)
  const series = rawRows.map((row) => ({
    date:        row.day?.toISOString?.() ?? row.month?.toISOString?.() ?? null,
    count:       Number(row.count),
    pkrVolume:   row.pkr_volume?.toString  ? row.pkr_volume.toString()  : String(row.pkr_volume  ?? 0),
    usdtVolume:  row.usdt_volume?.toString ? row.usdt_volume.toString() : String(row.usdt_volume ?? 0),
    profitPkr:   row.profit_pkr?.toString  ? row.profit_pkr.toString()  : String(row.profit_pkr  ?? 0),
    buyCount:    Number(row.buy_count),
    sellCount:   Number(row.sell_count),
  }));

  return {
    granularity,
    from:        fromDate.toISOString(),
    to:          toDate.toISOString(),
    totalPoints: series.length,
    series,
  };
}

/**
 * Recent transactions for the dashboard activity feed.
 *
 * @param {{ limit?: number }} [query]
 * @returns {Promise<object[]>}
 */
async function getRecentTransactions({ limit = 10 } = {}) {
  const transactions = await dashboardRepository.getRecentTransactions(
    Math.min(limit, 50),
  );
  return transactions;
}

/**
 * Recent audit log entries for the dashboard activity feed.
 *
 * @param {{ limit?: number }} [query]
 * @returns {Promise<object[]>}
 */
async function getRecentAuditLogs({ limit = 20 } = {}) {
  return dashboardRepository.getRecentAuditLogs(Math.min(limit, 100));
}

module.exports = {
  getSummary,
  getCharts,
  getRecentTransactions,
  getRecentAuditLogs,
};
