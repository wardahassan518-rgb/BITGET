# Services Layer

Services hold **business logic**. They orchestrate one or more
repositories, enforce business rules, and are what controllers call.
A service never touches `req`/`res` directly, and never imports
Prisma directly for *queries* — repositories own the read/write
calls (Phase 3's services do open `prisma.$transaction` blocks
themselves, since that's the natural place to express "this batch of
repository calls must commit or roll back together," not a repository
concern).

## Phase 1

Intentionally empty. The only working vertical slice in this phase
(`/health`, `/health/db`) is simple enough that its controller calls
the database connection check directly — there is no business rule
to encapsulate yet.

## Phase 2 (Authentication)

- `auth.service.js` — login, token issuance/rotation, lockout rules,
  session lifecycle.

## Phase 3 (this phase) — Client & Transaction Management

- `client.service.js` — Client CRUD, search/filter query building,
  CNIC-uniqueness checks, audit logging.
- `transaction.service.js` — Transaction CRUD, automatic receipt
  numbering (via `utils/receiptNumber.util.js`), keeping each linked
  client's aggregate stats (`totalTxns`, `totalVolumePkr`,
  `firstTxnDate`, `lastTxnDate`) in sync on every create/update/delete,
  and audit logging.

## Future phases

- `receipt.service.js` — PDF/QR generation (Phase 4)
- `report.service.js` — analytics aggregation (Phase 6)
- Hash-chain creation/verification and the void/correction workflow
  for transactions (reserved columns already exist on `Transaction`,
  intentionally untouched by Phase 3 — see that model's schema comment)
