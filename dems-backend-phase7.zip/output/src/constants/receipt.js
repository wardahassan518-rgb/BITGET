/**
 * src/constants/receipt.js
 * ────────────────────────────────────────────────────────────────
 * Constants for the Receipt & Verification module (Phase 6).
 * ────────────────────────────────────────────────────────────────
 */

/** Sub-directories (relative to UPLOAD_ROOT) for generated files. */
const RECEIPT_DIRS = Object.freeze({
  PDF:         'receipts/pdf',
  QR:          'receipts/qr',
  ATTACHMENTS: 'attachments',
});

/** Allowed MIME types for transaction attachments. */
const ATTACHMENT_MIME_TYPES = Object.freeze([
  'image/jpeg',
  'image/png',
  'image/webp',
  'application/pdf',
]);

/** Audit actions added in Phase 6. */
const RECEIPT_AUDIT_ACTIONS = Object.freeze({
  RECEIPT_VIEWED:      'RECEIPT_VIEWED',
  RECEIPT_PDF_GENERATED: 'RECEIPT_PDF_GENERATED',
  RECEIPT_PRINTED:     'RECEIPT_PRINTED',
  RECEIPT_SHARED:      'RECEIPT_SHARED',
  ATTACHMENT_UPLOADED: 'ATTACHMENT_UPLOADED',
  ATTACHMENT_DELETED:  'ATTACHMENT_DELETED',
  VERIFICATION_VIEWED: 'VERIFICATION_VIEWED',
});

/** QR code generation options. */
const QR_OPTIONS = Object.freeze({
  type:       'png',
  width:      240,
  margin:     1,
  color: {
    dark:  '#000000',
    light: '#FFFFFF',
  },
  errorCorrectionLevel: 'M',
});

module.exports = {
  RECEIPT_DIRS,
  ATTACHMENT_MIME_TYPES,
  RECEIPT_AUDIT_ACTIONS,
  QR_OPTIONS,
};
