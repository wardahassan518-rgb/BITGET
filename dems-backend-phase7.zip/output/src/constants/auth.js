/**
 * src/constants/auth.js
 * ────────────────────────────────────────────────────────────────
 * Shared authentication constants.  Centralised here so changing
 * the cookie name, header, or lockout policy is a one-line edit,
 * not a grep-and-replace across the codebase.
 * ────────────────────────────────────────────────────────────────
 */

const AUTH = Object.freeze({
  /** HTTP Authorization header scheme. */
  BEARER_SCHEME: 'Bearer',

  /** Cookie name used to transport the refresh token. */
  REFRESH_COOKIE: 'dems_refresh_token',

  /** Brute-force lockout thresholds. */
  MAX_FAILED_ATTEMPTS: 5,
  LOCKOUT_MINUTES: 30,

  /** Audit-log action strings written by the auth service. */
  AUDIT: Object.freeze({
    LOGIN_SUCCESS: 'AUTH_LOGIN_SUCCESS',
    LOGIN_FAILED: 'AUTH_LOGIN_FAILED',
    LOGIN_LOCKED: 'AUTH_LOGIN_LOCKED',
    LOGOUT: 'AUTH_LOGOUT',
    TOKEN_REFRESHED: 'AUTH_TOKEN_REFRESHED',
  }),
});

module.exports = { AUTH };
