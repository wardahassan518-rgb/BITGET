/**
 * src/constants/audit.js
 * ────────────────────────────────────────────────────────────────
 * Audit-log action strings written by the Client, Transaction, and
 * Integrity services. Centralised here for one place to look up or
 * extend the action vocabulary instead of grepping for string literals.
 *
 * `AuditLog.action` stays a free-text column at the DB level (see
 * schema comment), so adding a new value here never requires a
 * migration — just add the constant and start writing it.
 * ────────────────────────────────────────────────────────────────
 */

const AUDIT_ACTIONS = Object.freeze({
  // ── Clients ───────────────────────────────────────────────
  CLIENT_CREATED: 'CLIENT_CREATED',
  CLIENT_UPDATED: 'CLIENT_UPDATED',
  CLIENT_DELETED: 'CLIENT_DELETED',

  // ── Transactions ──────────────────────────────────────────
  TRANSACTION_CREATED:  'TRANSACTION_CREATED',
  TRANSACTION_UPDATED:  'TRANSACTION_UPDATED',
  TRANSACTION_DELETED:  'TRANSACTION_DELETED',

  // ── Integrity / Verification (Phase 4) ────────────────────
  // Fired for every call to the public /api/verify/:receipt endpoint
  // and every call to the authenticated integrity endpoints, so there
  // is a full audit trail of who looked up what and what the result was.
  INTEGRITY_VERIFIED:   'INTEGRITY_VERIFIED',    // hash matched — record is ORIGINAL
  INTEGRITY_TAMPERED:   'INTEGRITY_TAMPERED',    // hash mismatch — record is TAMPERED
  INTEGRITY_NOT_FOUND:  'INTEGRITY_NOT_FOUND',   // no transaction for that receipt
  INTEGRITY_CHAIN_SCAN: 'INTEGRITY_CHAIN_SCAN',  // full-chain scan requested (auth)
  TRANSACTION_SEALED:   'TRANSACTION_SEALED',    // hash + chain-index written to txn
});

module.exports = { AUDIT_ACTIONS };
