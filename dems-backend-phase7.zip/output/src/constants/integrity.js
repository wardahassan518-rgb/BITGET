/**
 * src/constants/integrity.js
 * ────────────────────────────────────────────────────────────────
 * Constants for the DEMS Integrity Engine (Phase 4).
 *
 * HASH_FIELDS          — the ordered list of Transaction fields that are
 *                        serialised into the SHA-256 pre-image.  Order is
 *                        stable and version-tagged so future changes can be
 *                        introduced under DEMS_V3 without invalidating the
 *                        existing chain.
 *
 * GENESIS_PREV_HASH    — canonical previous-hash for the first transaction
 *                        (chain index 0).  64 ASCII zeros — looks like a
 *                        SHA-256 digest, unambiguously distinguishes the
 *                        genesis record from every real hash.
 *
 * HASH_VERSION         — which algorithm this engine writes.  Stored in
 *                        `transactions.hash_version` so verifiers can know
 *                        exactly how to recompute a given record's hash.
 *
 * VERIFICATION_RESULT  — mirrors the Prisma enum so application code can
 *                        import a single object instead of hard-coding
 *                        string literals.
 * ────────────────────────────────────────────────────────────────
 */

/**
 * Ordered field names serialised into the SHA-256 pre-image for DEMS_V2.
 *
 * Rules:
 *   • The order MUST NOT change once the first transaction is hashed.
 *   • Every field is coerced to a string before joining (see
 *     integrityService._normalise).  null / undefined → the literal string
 *     'null'.  Decimal → JS .toString().  Date → ISO-8601 UTC string.
 *   • chainIndex and prevHash are included so that position in the chain
 *     and the link to the previous record are both part of the digest.
 *   • The CHAIN_SALT (env) is appended last so an attacker who has read
 *     access to the DB but not the env cannot forge valid hashes offline.
 */
const HASH_FIELDS_V2 = Object.freeze([
  'chainIndex',
  'receiptNumber',
  'txnType',
  'amountPkr',
  'exchangeRate',
  'amountUsdt',
  'costRate',
  'profitPkr',
  'clientId',
  'clientName',
  'clientCnic',
  'bankName',
  'bankLast4',
  'paymentRef',
  'notes',
  'timestamp',  // stored as ISO-8601 string for determinism
  'prevHash',
  // CHAIN_SALT is appended by the service — not a field on the model
]);

/** SHA-256 digest placeholder for the genesis record's "previous" block. */
const GENESIS_PREV_HASH = '0'.repeat(64);

/** Hash version written to new transactions by this engine. */
const HASH_VERSION = 'DEMS_V2';

/** Mirrors the Prisma VerificationResult enum. */
const VERIFICATION_RESULT = Object.freeze({
  ORIGINAL:  'ORIGINAL',
  TAMPERED:  'TAMPERED',
  NOT_FOUND: 'NOT_FOUND',
});

/** Human-readable labels returned by the public verification API. */
const VERIFICATION_LABEL = Object.freeze({
  ORIGINAL:  'Verified',
  TAMPERED:  'Tampered',
  NOT_FOUND: 'Not Found',
});

module.exports = {
  HASH_FIELDS_V2,
  GENESIS_PREV_HASH,
  HASH_VERSION,
  VERIFICATION_RESULT,
  VERIFICATION_LABEL,
};
