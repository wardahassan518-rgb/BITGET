/**
 * src/constants/roles.js
 * ────────────────────────────────────────────────────────────────
 * Mirror of the `UserRole` Prisma enum so application code can
 * reference roles without hard-coding raw strings everywhere.
 *
 *   ADMIN   — full system access, user management
 *   MANAGER — reports, void approvals, client management
 *   CASHIER — create / view transactions (primary operator role)
 *   AUDITOR — read-only access to transactions and audit logs
 * ────────────────────────────────────────────────────────────────
 */

const ROLES = Object.freeze({
  ADMIN: 'ADMIN',
  MANAGER: 'MANAGER',
  CASHIER: 'CASHIER',
  AUDITOR: 'AUDITOR',
});

/** Ordered from most-privileged to least-privileged. */
const ROLE_HIERARCHY = Object.freeze([
  ROLES.ADMIN,
  ROLES.MANAGER,
  ROLES.CASHIER,
  ROLES.AUDITOR,
]);

/**
 * Returns true if `role` has at least the privilege level of
 * `requiredRole` (i.e. is equal to or higher in the hierarchy).
 *
 * @param {string} role
 * @param {string} requiredRole
 * @returns {boolean}
 */
function hasMinimumRole(role, requiredRole) {
  return ROLE_HIERARCHY.indexOf(role) <= ROLE_HIERARCHY.indexOf(requiredRole);
}

module.exports = { ROLES, ROLE_HIERARCHY, hasMinimumRole };
