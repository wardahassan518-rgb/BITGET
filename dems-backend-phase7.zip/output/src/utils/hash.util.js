/**
 * src/utils/hash.util.js
 * ────────────────────────────────────────────────────────────────
 * Generic SHA-256 helpers built on Node's built-in `crypto` module.
 *
 * IMPORTANT — scope of this file:
 * This provides only generic, reusable primitives (hash a string,
 * hash a buffer, generate a random hex token). It deliberately does
 * NOT implement the DEMS transaction hash-chain algorithm (field
 * ordering, salts, prev_hash linking, chain verification) described
 * in `app-config.json` — that is business logic reserved for the
 * Transactions phase, built on top of these primitives.
 * ────────────────────────────────────────────────────────────────
 */

const crypto = require('crypto');

/**
 * Returns the SHA-256 hex digest of a UTF-8 string.
 * @param {string} input
 * @returns {string} 64-character hex digest
 */
function sha256(input) {
  return crypto.createHash('sha256').update(input, 'utf8').digest('hex');
}

/**
 * Returns the SHA-256 hex digest of a Buffer (e.g. an uploaded file),
 * useful for content-integrity checks on attachments.
 * @param {Buffer} buffer
 * @returns {string}
 */
function sha256Buffer(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

/**
 * Generates a cryptographically secure random hex string.
 * Useful for things like password-reset tokens or one-off salts.
 * @param {number} [byteLength=32]
 * @returns {string}
 */
function randomHex(byteLength = 32) {
  return crypto.randomBytes(byteLength).toString('hex');
}

module.exports = { sha256, sha256Buffer, randomHex };
