/**
 * src/utils/requestMeta.util.js
 * ────────────────────────────────────────────────────────────────
 * Extracts audit-relevant metadata from an incoming request.
 * Mirrors the inline `requestMeta()` helper already used in
 * `auth.controller.js`, factored out so the new Client and
 * Transaction controllers (Phase 3) don't duplicate it a second and
 * third time. `auth.controller.js` itself is left untouched.
 * ────────────────────────────────────────────────────────────────
 */

/**
 * @param {import('express').Request} req
 * @returns {{ userAgent: string, ipAddress: string }}
 */
function requestMeta(req) {
  return {
    userAgent: req.headers['user-agent'] ?? 'unknown',
    ipAddress: req.ip ?? req.socket?.remoteAddress ?? 'unknown',
  };
}

module.exports = requestMeta;
