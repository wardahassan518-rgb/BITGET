/**
 * src/utils/ApiResponse.js
 * ────────────────────────────────────────────────────────────────
 * Standard success response envelope so every endpoint built in
 * later phases returns JSON in the same shape:
 *
 *   { success: true, message, data, meta }
 *
 * Usage:
 *   return new ApiResponse(200, 'OK', { user }).send(res);
 * ────────────────────────────────────────────────────────────────
 */

class ApiResponse {
  /**
   * @param {number} statusCode
   * @param {string} message
   * @param {unknown} [data=null]
   * @param {object} [meta=null] - pagination info, counts, etc.
   */
  constructor(statusCode, message, data = null, meta = null) {
    this.statusCode = statusCode;
    this.success = statusCode < 400;
    this.message = message;
    this.data = data;
    this.meta = meta;
  }

  send(res) {
    const body = {
      success: this.success,
      message: this.message,
      data: this.data,
    };
    if (this.meta) body.meta = this.meta;
    return res.status(this.statusCode).json(body);
  }
}

module.exports = ApiResponse;
