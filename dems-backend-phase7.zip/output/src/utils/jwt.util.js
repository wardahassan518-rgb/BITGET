/**
 * src/utils/jwt.util.js
 * ────────────────────────────────────────────────────────────────
 * Generic JWT sign/verify helpers, built on `jsonwebtoken`.
 *
 * Reserved for Phase 2 (Authentication). These functions are not
 * called from any route, controller, or middleware yet — there is
 * no login endpoint and no middleware enforcing auth on any route
 * in this phase. They exist purely so the Authentication phase has
 * a tested, consistent primitive to build on instead of re-deriving
 * JWT option-handling from scratch.
 * ────────────────────────────────────────────────────────────────
 */

const jwt = require('jsonwebtoken');
const jwtConfig = require('../config/jwt.config');

/**
 * Signs a payload into a short-lived access token.
 * @param {object} payload - e.g. { sub: userId, role }
 * @returns {string}
 */
function signAccessToken(payload) {
  return jwt.sign(payload, jwtConfig.accessToken.secret, {
    expiresIn: jwtConfig.accessToken.expiresIn,
    issuer: jwtConfig.issuer,
    audience: jwtConfig.audience,
  });
}

/**
 * Signs a payload into a long-lived refresh token.
 * @param {object} payload
 * @returns {string}
 */
function signRefreshToken(payload) {
  return jwt.sign(payload, jwtConfig.refreshToken.secret, {
    expiresIn: jwtConfig.refreshToken.expiresIn,
    issuer: jwtConfig.issuer,
    audience: jwtConfig.audience,
  });
}

/**
 * Verifies an access token, throwing if invalid/expired.
 * @param {string} token
 * @returns {object} decoded payload
 */
function verifyAccessToken(token) {
  return jwt.verify(token, jwtConfig.accessToken.secret, {
    issuer: jwtConfig.issuer,
    audience: jwtConfig.audience,
  });
}

/**
 * Verifies a refresh token, throwing if invalid/expired.
 * @param {string} token
 * @returns {object} decoded payload
 */
function verifyRefreshToken(token) {
  return jwt.verify(token, jwtConfig.refreshToken.secret, {
    issuer: jwtConfig.issuer,
    audience: jwtConfig.audience,
  });
}

module.exports = {
  signAccessToken,
  signRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
};
