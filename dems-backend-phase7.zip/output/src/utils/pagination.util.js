/**
 * src/utils/pagination.util.js
 * ────────────────────────────────────────────────────────────────
 * Generic helper for turning `?page=2&limit=20` query params into
 * Prisma's `skip`/`take` pair, plus a `buildMeta()` helper for
 * shaping the pagination block of a list response.
 *
 * Entity-specific filtering/sorting rules belong to each future
 * service/repository — this file only knows about page numbers.
 * ────────────────────────────────────────────────────────────────
 */

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 100;

/**
 * @param {{page?: string|number, limit?: string|number}} query
 * @returns {{ page: number, limit: number, skip: number, take: number }}
 */
function getPagination(query = {}) {
  const page = Math.max(parseInt(query.page, 10) || DEFAULT_PAGE, 1);
  const limit = Math.min(Math.max(parseInt(query.limit, 10) || DEFAULT_LIMIT, 1), MAX_LIMIT);
  const skip = (page - 1) * limit;
  return { page, limit, skip, take: limit };
}

/**
 * @param {number} page
 * @param {number} limit
 * @param {number} totalItems
 */
function buildMeta(page, limit, totalItems) {
  return {
    page,
    limit,
    totalItems,
    totalPages: Math.max(Math.ceil(totalItems / limit), 1),
  };
}

module.exports = { getPagination, buildMeta };
