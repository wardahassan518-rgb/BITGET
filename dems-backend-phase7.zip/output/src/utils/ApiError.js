/**
 * src/utils/ApiError.js
 * ────────────────────────────────────────────────────────────────
 * Standard application error shape.
 *
 * Throw `new ApiError(404, 'Client not found')` from anywhere
 * (controllers, services, repositories) and the global error
 * middleware (`src/middlewares/error.middleware.js`) will turn it
 * into a consistent JSON error response.
 *
 * `isOperational = true` marks "expected" errors (bad input, not
 * found, unauthorized, etc.) as opposed to programmer errors/bugs —
 * useful later for deciding what to log at what severity.
 * ────────────────────────────────────────────────────────────────
 */

class ApiError extends Error {
  /**
   * @param {number} statusCode - HTTP status code (e.g. 400, 404, 500)
   * @param {string} message - Human-readable error message
   * @param {object} [options]
   * @param {boolean} [options.isOperational=true]
   * @param {unknown} [options.details] - Extra structured info (e.g. Zod issues)
   */
  constructor(statusCode, message, options = {}) {
    super(message);
    this.name = 'ApiError';
    this.statusCode = statusCode;
    this.isOperational = options.isOperational ?? true;
    this.details = options.details ?? null;
    Error.captureStackTrace(this, this.constructor);
  }
}

module.exports = ApiError;
