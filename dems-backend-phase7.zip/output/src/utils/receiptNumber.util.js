/**
 * src/utils/receiptNumber.util.js
 * ────────────────────────────────────────────────────────────────
 * Generates the next receipt number in the format:
 *
 *   EXC-<year>-<sequence padded to 6 digits>
 *   e.g. EXC-2026-000001, EXC-2026-000002, EXC-2026-000003 ...
 *
 * The sequence restarts at 000001 on the first transaction of each
 * new calendar year (the year is baked into the number itself, which
 * is the standard convention for this kind of receipt numbering).
 *
 * Concurrency safety
 * ───────────────────
 * Two cashiers creating a transaction at the exact same millisecond
 * must never receive the same receipt number, and no number must
 * ever be skipped on a successful commit. A naive
 * "read lastNumber, add 1, write it back" approach has a race window
 * between the read and the write under concurrent requests.
 *
 * Instead this uses a single atomic SQL statement:
 *
 *   INSERT INTO receipt_sequences (...)
 *   VALUES (..., 1, ...)
 *   ON CONFLICT (year) DO UPDATE SET last_number = last_number + 1
 *   RETURNING last_number;
 *
 * Postgres takes the necessary row lock as part of this single
 * statement, so concurrent callers are safely serialized by the
 * database itself — no application-level locking needed.
 *
 * IMPORTANT: always call this with a transaction client (`tx`) inside
 * `prisma.$transaction(async (tx) => { ... })` together with the
 * `transaction.create(...)` call it numbers, so that if the rest of
 * the transaction creation fails, the reserved number is rolled back
 * too (no permanently "burned"/skipped numbers on a failed request).
 * ────────────────────────────────────────────────────────────────
 */

const crypto = require('crypto');

const RECEIPT_PREFIX = 'EXC';
const SEQUENCE_PADDING = 6;

/**
 * @param {import('@prisma/client').Prisma.TransactionClient} tx - must be a
 *   transaction-scoped Prisma client (the callback argument of `prisma.$transaction`)
 * @param {Date} [at] - defaults to now; exposed mainly for testability
 * @returns {Promise<string>} e.g. "EXC-2026-000001"
 */
async function generateReceiptNumber(tx, at = new Date()) {
  const year = at.getFullYear();
  const id = crypto.randomUUID();

  const rows = await tx.$queryRaw`
    INSERT INTO receipt_sequences (id, year, last_number, updated_at)
    VALUES (${id}, ${year}, 1, now())
    ON CONFLICT (year)
    DO UPDATE SET last_number = receipt_sequences.last_number + 1, updated_at = now()
    RETURNING last_number;
  `;

  const lastNumber = Number(rows[0].last_number);
  const padded = String(lastNumber).padStart(SEQUENCE_PADDING, '0');

  return `${RECEIPT_PREFIX}-${year}-${padded}`;
}

module.exports = { generateReceiptNumber };
