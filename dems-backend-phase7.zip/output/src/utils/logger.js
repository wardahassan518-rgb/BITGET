/**
 * src/utils/logger.js
 * ────────────────────────────────────────────────────────────────
 * Centralized Winston logger.
 *
 * - Console transport: human-readable, colorized (dev-friendly).
 * - File transports: JSON, daily-rotated, split into combined +
 *   error-only files, retained per LOG_MAX_FILES (e.g. "14d").
 *
 * Import this everywhere instead of using console.log/console.error.
 * ────────────────────────────────────────────────────────────────
 */

const path = require('path');
const winston = require('winston');
require('winston-daily-rotate-file');

// NOTE: this file intentionally reads process.env directly (not
// env.config.js) to avoid a circular dependency, since env.config.js
// itself does not depend on the logger for anything other than error
// reporting during its own validation failure path.
const NODE_ENV = process.env.NODE_ENV || 'development';
const LOG_LEVEL = process.env.LOG_LEVEL || 'info';
const LOG_DIR = path.resolve(process.cwd(), process.env.LOG_DIR || 'logs');
const LOG_MAX_FILES = process.env.LOG_MAX_FILES || '14d';

const { combine, timestamp, printf, colorize, json, errors } = winston.format;

const consoleFormat = combine(
  colorize(),
  timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  errors({ stack: true }),
  printf(({ level, message, timestamp: ts, stack, ...meta }) => {
    const metaStr = Object.keys(meta).length ? ` ${JSON.stringify(meta)}` : '';
    return `[${ts}] ${level}: ${stack || message}${metaStr}`;
  }),
);

const fileFormat = combine(timestamp(), errors({ stack: true }), json());

const transports = [
  new winston.transports.Console({
    format: consoleFormat,
    silent: NODE_ENV === 'test',
  }),
  new winston.transports.DailyRotateFile({
    dirname: LOG_DIR,
    filename: 'dems-combined-%DATE%.log',
    datePattern: 'YYYY-MM-DD',
    maxFiles: LOG_MAX_FILES,
    format: fileFormat,
  }),
  new winston.transports.DailyRotateFile({
    dirname: LOG_DIR,
    filename: 'dems-error-%DATE%.log',
    datePattern: 'YYYY-MM-DD',
    level: 'error',
    maxFiles: LOG_MAX_FILES,
    format: fileFormat,
  }),
];

const logger = winston.createLogger({
  level: LOG_LEVEL,
  levels: winston.config.npm.levels,
  transports,
  exitOnError: false,
});

// Stream adapter so morgan (HTTP request logging) can pipe into Winston.
logger.stream = {
  write: (message) => logger.http(message.trim()),
};

module.exports = logger;
