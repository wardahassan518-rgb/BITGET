/**
 * src/utils/asyncHandler.js
 * ────────────────────────────────────────────────────────────────
 * Wraps an async Express route/controller handler so any rejected
 * Promise (thrown error) is forwarded to `next(err)` automatically,
 * instead of every controller needing its own try/catch block.
 *
 * Usage:
 *   router.get('/', asyncHandler(async (req, res) => {
 *     const data = await someService.getData();
 *     res.json(data);
 *   }));
 * ────────────────────────────────────────────────────────────────
 */

const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

module.exports = asyncHandler;
