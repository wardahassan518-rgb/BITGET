/**
 * src/utils/bcrypt.util.js
 * ────────────────────────────────────────────────────────────────
 * Generic bcrypt hashing helpers.
 *
 * Reserved for Phase 2 (Authentication) — e.g. hashing a user's
 * password before storing it in `users.password_hash`. Not called
 * from any route or controller yet, since no registration/login
 * flow exists in this phase.
 * ────────────────────────────────────────────────────────────────
 */

const bcrypt = require('bcrypt');
const config = require('../config/env.config');

/**
 * Hashes a plaintext value (e.g. password, PIN).
 * @param {string} plain
 * @returns {Promise<string>}
 */
async function hashValue(plain) {
  return bcrypt.hash(plain, config.bcrypt.saltRounds);
}

/**
 * Compares a plaintext value against a stored bcrypt hash.
 * @param {string} plain
 * @param {string} hash
 * @returns {Promise<boolean>}
 */
async function compareValue(plain, hash) {
  return bcrypt.compare(plain, hash);
}

module.exports = { hashValue, compareValue };
