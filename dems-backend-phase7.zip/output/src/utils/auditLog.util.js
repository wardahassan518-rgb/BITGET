/**
 * src/utils/auditLog.util.js
 * ────────────────────────────────────────────────────────────────
 * Shared helper for writing a row to the `audit_log` table.
 *
 * Accepts a Prisma client/transaction handle as its first argument
 * (rather than importing the singleton itself) so callers can choose:
 *
 *   - `writeAuditLog(prisma, {...})`           — standalone write
 *   - `writeAuditLog(tx, {...})` inside
 *     `prisma.$transaction(async (tx) => { ... await writeAuditLog(tx, {...}); })`
 *     — atomic with the business write it documents (used by the
 *     Transaction and Client services so an audit entry can never
 *     exist without the change it describes, or vice versa).
 *
 * This intentionally mirrors `auth.service.js`'s inline
 * `writeAuditLog` helper but is NOT a replacement for it — Phase 2
 * (Authentication) is left untouched per instructions; this is a new,
 * separate helper for the Phase 3 modules.
 * ────────────────────────────────────────────────────────────────
 */

const logger = require('./logger');

/**
 * @param {import('@prisma/client').PrismaClient | import('@prisma/client').Prisma.TransactionClient} db
 * @param {{ action: string, detail?: string, userId?: string|null, platform?: string, userAgent?: string|null }} entry
 * @param {{ silent?: boolean }} [opts] - if true, swallow failures (logged as a warning)
 *   instead of throwing. Default `false` so writes inside a `$transaction`
 *   correctly roll back the whole transaction if the audit insert fails.
 */
async function writeAuditLog(db, { action, detail, userId, platform = 'api', userAgent } = {}, opts = {}) {
  const { silent = false } = opts;

  const write = () =>
    db.auditLog.create({
      data: {
        action,
        detail: detail ?? null,
        userId: userId ?? null,
        platform,
        userAgent: userAgent ?? null,
      },
    });

  if (silent) {
    return write().catch((err) => {
      logger.warn(`Audit log write failed: ${err.message}`);
      return null;
    });
  }

  return write();
}

module.exports = { writeAuditLog };
