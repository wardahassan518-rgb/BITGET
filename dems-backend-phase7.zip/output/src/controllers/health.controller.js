/**
 * src/controllers/health.controller.js
 * ────────────────────────────────────────────────────────────────
 * Liveness/readiness checks. This is the only "feature" wired
 * end-to-end in Phase 1 — it exists to prove the
 * Controller → Route → Middleware → Database plumbing works, not
 * as business logic.
 * ────────────────────────────────────────────────────────────────
 */

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const { checkDatabaseConnection } = require('../database/prisma.client');

/**
 * GET /health
 * Liveness probe — "is the Node process up?". Does not touch the DB.
 */
const getLiveness = asyncHandler(async (req, res) => {
  return new ApiResponse(200, 'DEMS backend is running', {
    status: 'ok',
    uptimeSeconds: Math.floor(process.uptime()),
    timestamp: new Date().toISOString(),
  }).send(res);
});

/**
 * GET /health/db
 * Readiness probe — "is the Node process up AND can it reach Postgres?".
 */
const getReadiness = asyncHandler(async (req, res) => {
  const dbConnected = await checkDatabaseConnection();

  return new ApiResponse(dbConnected ? 200 : 503, dbConnected ? 'Database reachable' : 'Database unreachable', {
    status: dbConnected ? 'ok' : 'down',
    database: dbConnected ? 'connected' : 'disconnected',
    timestamp: new Date().toISOString(),
  }).send(res);
});

module.exports = { getLiveness, getReadiness };
