/**
 * src/controllers/receipt.controller.js
 * ────────────────────────────────────────────────────────────────
 * HTTP layer for the Receipt & Attachment module (Phase 6).
 *
 * Handlers:
 *
 *   ensureReceipt()           — POST /receipts/ensure/:transactionId
 *                               Create or return the Receipt record.
 *
 *   getReceipt()              — GET /receipts/:receiptNumber
 *                               Full receipt + transaction + integrity.
 *
 *   generatePdf()             — POST /receipts/:receiptNumber/pdf
 *                               Generate / regenerate the PDF on demand.
 *
 *   downloadPdf()             — GET /receipts/:receiptNumber/pdf
 *                               Stream the PDF file for download.
 *
 *   generateQr()              — POST /receipts/:receiptNumber/qr
 *                               Generate / regenerate the QR PNG.
 *
 *   logPrint()                — POST /receipts/:receiptNumber/print
 *                               Increment print counter + audit.
 *
 *   logShare()                — POST /receipts/:receiptNumber/share
 *                               Increment share counter + audit.
 *
 *   listReceipts()            — GET /receipts
 *                               Paginated receipt list (admin).
 *
 *   uploadAttachment()        — POST /transactions/:txnId/attachments
 *   listAttachments()         — GET  /transactions/:txnId/attachments
 *   downloadAttachment()      — GET  /attachments/:attachmentId
 *   deleteAttachment()        — DELETE /attachments/:attachmentId
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const path          = require('path');
const asyncHandler  = require('../utils/asyncHandler');
const ApiResponse   = require('../utils/ApiResponse');
const ApiError      = require('../utils/ApiError');
const requestMeta   = require('../utils/requestMeta.util');
const receiptService   = require('../services/receipt.service');
const uploadService    = require('../services/upload.service');

// ── Receipt handlers ──────────────────────────────────────────────

/**
 * POST /api/v1/receipts/ensure/:transactionId
 *
 * Idempotent: create or fetch the Receipt record for a transaction.
 */
const ensureReceipt = asyncHandler(async (req, res) => {
  const { transactionId } = req.params;
  const meta = requestMeta(req);

  const receipt = await receiptService.ensureReceipt(transactionId, {
    userId:    req.user?.id,
    userAgent: meta.userAgent,
  });

  return new ApiResponse(200, 'Receipt retrieved', { receipt }).send(res);
});

/**
 * GET /api/v1/receipts/:receiptNumber
 *
 * Return full receipt data including transaction and integrity fields.
 */
const getReceipt = asyncHandler(async (req, res) => {
  const receiptNumber = (req.params.receiptNumber ?? '').trim().toUpperCase();
  if (!receiptNumber) throw new ApiError(400, 'Receipt number is required.');

  const receipt = await receiptService.getReceiptByNumber(receiptNumber);
  return new ApiResponse(200, 'Receipt retrieved', { receipt }).send(res);
});

/**
 * POST /api/v1/receipts/:receiptNumber/pdf
 *
 * Generate (or regenerate) the server-side PDF for this receipt.
 */
const generatePdf = asyncHandler(async (req, res) => {
  const receiptNumber = (req.params.receiptNumber ?? '').trim().toUpperCase();
  if (!receiptNumber) throw new ApiError(400, 'Receipt number is required.');

  const meta = requestMeta(req);
  const { receipt, pdf } = await receiptService.generatePdf(receiptNumber, {
    userId:    req.user?.id,
    userAgent: meta.userAgent,
  });

  return new ApiResponse(200, 'PDF generated', { receipt, pdf }).send(res);
});

/**
 * GET /api/v1/receipts/:receiptNumber/pdf
 *
 * Stream the PDF file as an attachment.  Generates on-demand if not
 * yet created (first-time access pattern).
 */
const downloadPdf = asyncHandler(async (req, res) => {
  const receiptNumber = (req.params.receiptNumber ?? '').trim().toUpperCase();
  if (!receiptNumber) throw new ApiError(400, 'Receipt number is required.');

  const meta = requestMeta(req);
  const { absPath, filename } = await receiptService.servePdf(receiptNumber, {
    userId:    req.user?.id,
    userAgent: meta.userAgent,
  });

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  return res.sendFile(absPath);
});

/**
 * POST /api/v1/receipts/:receiptNumber/qr
 *
 * Generate (or regenerate) the QR PNG for this receipt.
 */
const generateQr = asyncHandler(async (req, res) => {
  const receiptNumber = (req.params.receiptNumber ?? '').trim().toUpperCase();
  if (!receiptNumber) throw new ApiError(400, 'Receipt number is required.');

  const result = await receiptService.generateQr(receiptNumber);
  return new ApiResponse(200, 'QR code generated', result).send(res);
});

/**
 * POST /api/v1/receipts/:receiptNumber/print
 *
 * Increment the print counter and write an audit entry.
 */
const logPrint = asyncHandler(async (req, res) => {
  const receiptNumber = (req.params.receiptNumber ?? '').trim().toUpperCase();
  if (!receiptNumber) throw new ApiError(400, 'Receipt number is required.');

  const meta = requestMeta(req);
  await receiptService.logPrint(receiptNumber, {
    userId:    req.user?.id,
    userAgent: meta.userAgent,
  });

  return new ApiResponse(200, 'Print logged').send(res);
});

/**
 * POST /api/v1/receipts/:receiptNumber/share
 *
 * Increment the share counter and write an audit entry.
 */
const logShare = asyncHandler(async (req, res) => {
  const receiptNumber = (req.params.receiptNumber ?? '').trim().toUpperCase();
  if (!receiptNumber) throw new ApiError(400, 'Receipt number is required.');

  const meta = requestMeta(req);
  await receiptService.logShare(receiptNumber, {
    userId:    req.user?.id,
    userAgent: meta.userAgent,
  });

  return new ApiResponse(200, 'Share logged').send(res);
});

/**
 * GET /api/v1/receipts
 *
 * Paginated list of receipts (newest first). ADMIN / MANAGER / AUDITOR.
 */
const listReceipts = asyncHandler(async (req, res) => {
  const { receipts, meta } = await receiptService.listReceipts(req.query);
  return new ApiResponse(200, 'Receipts retrieved', { receipts }, meta).send(res);
});

// ── Attachment handlers ───────────────────────────────────────────

/**
 * POST /api/v1/transactions/:txnId/attachments
 *
 * Upload a file attachment for the given transaction.
 * Expects `multipart/form-data` with field name `file`.
 */
const uploadAttachment = asyncHandler(async (req, res) => {
  const { txnId } = req.params;
  const meta      = requestMeta(req);

  const attachment = await uploadService.processAttachment({
    file:          req.file,
    transactionId: txnId,
    userId:        req.user?.id,
    userAgent:     meta.userAgent,
  });

  return new ApiResponse(201, 'Attachment uploaded', { attachment }).send(res);
});

/**
 * GET /api/v1/transactions/:txnId/attachments
 *
 * List all attachments for a transaction.
 */
const listAttachments = asyncHandler(async (req, res) => {
  const { txnId } = req.params;
  const attachments = await uploadService.listAttachments(txnId);
  return new ApiResponse(200, 'Attachments retrieved', { attachments }).send(res);
});

/**
 * GET /api/v1/attachments/:attachmentId
 *
 * Download a specific attachment file.
 */
const downloadAttachment = asyncHandler(async (req, res) => {
  const { attachmentId } = req.params;
  const { attachment, absPath } = await uploadService.getAttachmentForDownload(attachmentId);

  const filename = attachment.originalName
    ? path.basename(attachment.originalName)
    : attachmentId;

  res.setHeader('Content-Type', attachment.mimeType);
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  return res.sendFile(absPath);
});

/**
 * DELETE /api/v1/attachments/:attachmentId
 *
 * Delete an attachment (ADMIN / MANAGER only — enforced by route).
 */
const deleteAttachment = asyncHandler(async (req, res) => {
  const { attachmentId } = req.params;
  const meta = requestMeta(req);

  await uploadService.deleteAttachment({
    attachmentId,
    userId:    req.user?.id,
    userAgent: meta.userAgent,
  });

  return new ApiResponse(200, 'Attachment deleted').send(res);
});

module.exports = {
  ensureReceipt,
  getReceipt,
  generatePdf,
  downloadPdf,
  generateQr,
  logPrint,
  logShare,
  listReceipts,
  uploadAttachment,
  listAttachments,
  downloadAttachment,
  deleteAttachment,
};
