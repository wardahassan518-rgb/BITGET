/**
 * src/controllers/transaction.controller.js
 * ────────────────────────────────────────────────────────────────
 * HTTP layer for Transaction Management endpoints.
 * Thin by design: extract request data, delegate to the transaction
 * service, shape the response. No business logic or DB access here.
 * ────────────────────────────────────────────────────────────────
 */

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const requestMeta = require('../utils/requestMeta.util');
const transactionService = require('../services/transaction.service');

/**
 * POST /transactions
 */
const createTransaction = asyncHandler(async (req, res) => {
  const transaction = await transactionService.createTransaction(req.body, req.user, requestMeta(req));
  return new ApiResponse(201, 'Transaction created', { transaction }).send(res);
});

/**
 * GET /transactions/:id
 */
const getTransaction = asyncHandler(async (req, res) => {
  const transaction = await transactionService.getTransactionById(req.params.id);
  return new ApiResponse(200, 'Transaction retrieved', { transaction }).send(res);
});

/**
 * GET /transactions
 * Query: page, limit, search, txnType, clientId, from, to, sortBy, sortOrder
 */
const listTransactions = asyncHandler(async (req, res) => {
  const { transactions, meta } = await transactionService.listTransactions(req.query);
  return new ApiResponse(200, 'Transactions retrieved', { transactions }, meta).send(res);
});

/**
 * PUT /transactions/:id
 */
const updateTransaction = asyncHandler(async (req, res) => {
  const transaction = await transactionService.updateTransaction(
    req.params.id,
    req.body,
    req.user,
    requestMeta(req),
  );
  return new ApiResponse(200, 'Transaction updated', { transaction }).send(res);
});

/**
 * DELETE /transactions/:id
 */
const deleteTransaction = asyncHandler(async (req, res) => {
  await transactionService.deleteTransaction(req.params.id, req.user, requestMeta(req));
  return new ApiResponse(200, 'Transaction deleted', null).send(res);
});

module.exports = {
  createTransaction,
  getTransaction,
  listTransactions,
  updateTransaction,
  deleteTransaction,
};
