/**
 * src/controllers/client.controller.js
 * ────────────────────────────────────────────────────────────────
 * HTTP layer for Client Management endpoints.
 * Thin by design: extract request data, delegate to the client
 * service, shape the response. No business logic or DB access here.
 * ────────────────────────────────────────────────────────────────
 */

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const requestMeta = require('../utils/requestMeta.util');
const clientService = require('../services/client.service');

/**
 * POST /clients
 */
const createClient = asyncHandler(async (req, res) => {
  const client = await clientService.createClient(req.body, req.user, requestMeta(req));
  return new ApiResponse(201, 'Client created', { client }).send(res);
});

/**
 * GET /clients/:id
 */
const getClient = asyncHandler(async (req, res) => {
  const client = await clientService.getClientById(req.params.id);
  return new ApiResponse(200, 'Client retrieved', { client }).send(res);
});

/**
 * GET /clients
 * Query: page, limit, search, isVerified, isFlagged, sortBy, sortOrder
 */
const listClients = asyncHandler(async (req, res) => {
  const { clients, meta } = await clientService.listClients(req.query);
  return new ApiResponse(200, 'Clients retrieved', { clients }, meta).send(res);
});

/**
 * PUT /clients/:id
 */
const updateClient = asyncHandler(async (req, res) => {
  const client = await clientService.updateClient(req.params.id, req.body, req.user, requestMeta(req));
  return new ApiResponse(200, 'Client updated', { client }).send(res);
});

/**
 * DELETE /clients/:id
 */
const deleteClient = asyncHandler(async (req, res) => {
  await clientService.deleteClient(req.params.id, req.user, requestMeta(req));
  return new ApiResponse(200, 'Client deleted', null).send(res);
});

module.exports = { createClient, getClient, listClients, updateClient, deleteClient };
