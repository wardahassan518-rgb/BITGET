/**
 * src/controllers/reports.controller.js
 * ────────────────────────────────────────────────────────────────
 * HTTP layer for Reports endpoints (Phase 5).
 *
 * Thin by design: validate → delegate to reports service → respond.
 * All business logic, date arithmetic, and pagination live in the
 * service layer.  All DB access lives in the repository layer.
 *
 * Route map (mounted at /api/v1/reports):
 *   GET /reports/daily          — single-day summary + hourly breakdown
 *   GET /reports/monthly        — single-month summary + daily breakdown
 *   GET /reports/custom         — arbitrary date-range report
 *   GET /reports/clients        — paginated client list + top-N leaders
 *   GET /reports/transactions   — paginated transaction list + totals
 *   GET /reports/audit          — paginated audit log list
 *   GET /reports/statistics     — aggregates, rates, busy periods, comparison
 * ────────────────────────────────────────────────────────────────
 */

const asyncHandler     = require('../utils/asyncHandler');
const ApiResponse      = require('../utils/ApiResponse');
const reportsService   = require('../services/reports.service');

// ── GET /reports/daily ────────────────────────────────────────────

/**
 * Single-day report: summary aggregates + hourly breakdown.
 *
 * Query params (all optional):
 *   date — ISO date string of the target day (default: today)
 *
 * @route   GET /api/v1/reports/daily
 * @access  ADMIN | MANAGER | AUDITOR
 */
const getDailyReport = asyncHandler(async (req, res) => {
  const report = await reportsService.getDailyReport(req.query);
  return new ApiResponse(200, 'Daily report retrieved', report).send(res);
});

// ── GET /reports/monthly ──────────────────────────────────────────

/**
 * Single-month report: summary aggregates + per-day breakdown.
 *
 * Query params (all optional):
 *   year  — 4-digit year (default: current year)
 *   month — 1-12 integer (default: current month)
 *
 * @route   GET /api/v1/reports/monthly
 * @access  ADMIN | MANAGER | AUDITOR
 */
const getMonthlyReport = asyncHandler(async (req, res) => {
  const report = await reportsService.getMonthlyReport(req.query);
  return new ApiResponse(200, 'Monthly report retrieved', report).send(res);
});

// ── GET /reports/custom ───────────────────────────────────────────

/**
 * Custom date-range report with optional filters.
 *
 * Query params (all optional):
 *   from      — ISO date string, start of range (default: 30 days ago)
 *   to        — ISO date string, end of range (default: today)
 *   txnType   — 'BUY' | 'SELL' filter
 *   clientId  — UUID filter by specific client
 *   breakdown — boolean; include per-day breakdown array
 *
 * @route   GET /api/v1/reports/custom
 * @access  ADMIN | MANAGER | AUDITOR
 */
const getCustomReport = asyncHandler(async (req, res) => {
  const report = await reportsService.getCustomReport(req.query);
  return new ApiResponse(200, 'Custom report retrieved', report).send(res);
});

// ── GET /reports/clients ──────────────────────────────────────────

/**
 * Paginated client report with optional search, filters, and top-N.
 *
 * Query params:
 *   page, limit    — pagination (default 1 / 20)
 *   search         — search fullName, CNIC, phone
 *   isVerified     — boolean filter
 *   isFlagged      — boolean filter
 *   sortBy         — 'totalTxns' | 'totalVolumePkr' | 'lastTxnDate' | 'createdAt'
 *   sortOrder      — 'asc' | 'desc'
 *   from / to      — date range for topN leaderboard
 *   topN           — include top-N clients by PKR volume (1–20)
 *
 * @route   GET /api/v1/reports/clients
 * @access  ADMIN | MANAGER | AUDITOR
 */
const getClientReport = asyncHandler(async (req, res) => {
  const { clients, meta, topClients, topClientsWindow } = await reportsService.getClientReport(req.query);

  const data = { clients };
  if (topClients !== undefined) {
    data.topClients       = topClients;
    data.topClientsWindow = topClientsWindow;
  }

  return new ApiResponse(200, 'Client report retrieved', data, meta).send(res);
});

// ── GET /reports/transactions ─────────────────────────────────────

/**
 * Paginated transaction report with rich filtering and optional totals.
 *
 * Query params:
 *   page, limit    — pagination (default 1 / 20)
 *   search         — receipt number, order ID, client name/CNIC, payment ref
 *   txnType        — 'BUY' | 'SELL'
 *   clientId       — UUID
 *   from / to      — date range
 *   sortBy         — 'timestamp' | 'amountPkr' | 'receiptNumber' | 'createdAt'
 *   sortOrder      — 'asc' | 'desc'
 *   includeTotals  — boolean; include volume/profit aggregates + type split
 *
 * @route   GET /api/v1/reports/transactions
 * @access  Any authenticated role
 */
const getTransactionReport = asyncHandler(async (req, res) => {
  const { transactions, meta, totals, byType } = await reportsService.getTransactionReport(req.query);

  const data = { transactions };
  if (totals !== undefined) {
    data.totals = totals;
    data.byType = byType;
  }

  return new ApiResponse(200, 'Transaction report retrieved', data, meta).send(res);
});

// ── GET /reports/audit ────────────────────────────────────────────

/**
 * Paginated audit log report.
 *
 * Query params:
 *   page, limit — pagination (default 1 / 20)
 *   action      — partial-match filter on action field
 *   userId      — UUID; filter by performing user
 *   from / to   — date range
 *   search      — search action + detail fields
 *   sortOrder   — 'asc' | 'desc' (default desc)
 *
 * @route   GET /api/v1/reports/audit
 * @access  ADMIN | AUDITOR
 */
const getAuditReport = asyncHandler(async (req, res) => {
  const { logs, meta } = await reportsService.getAuditReport(req.query);
  return new ApiResponse(200, 'Audit report retrieved', { logs }, meta).send(res);
});

// ── GET /reports/statistics ───────────────────────────────────────

/**
 * Aggregate statistics, rate analysis, busy periods, and comparison.
 *
 * Query params (all optional):
 *   from — start of analysis window (default: 30 days ago)
 *   to   — end of analysis window (default: today)
 *
 * @route   GET /api/v1/reports/statistics
 * @access  ADMIN | MANAGER | AUDITOR
 */
const getStatistics = asyncHandler(async (req, res) => {
  const stats = await reportsService.getStatistics(req.query);
  return new ApiResponse(200, 'Statistics retrieved', stats).send(res);
});

module.exports = {
  getDailyReport,
  getMonthlyReport,
  getCustomReport,
  getClientReport,
  getTransactionReport,
  getAuditReport,
  getStatistics,
};
