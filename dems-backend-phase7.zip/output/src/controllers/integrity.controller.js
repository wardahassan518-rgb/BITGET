/**
 * src/controllers/integrity.controller.js
 * ────────────────────────────────────────────────────────────────
 * HTTP layer for the DEMS Integrity Engine (Phase 4).
 *
 * Handlers:
 *
 *   verifyByReceipt()        — public, no auth required
 *                              GET /api/verify/:receipt
 *                              Returns Verified / Tampered / Not Found.
 *
 *   verifyTransaction()      — authenticated (any role)
 *                              GET /api/v1/integrity/transaction/:id
 *                              Verifies a transaction by its UUID and
 *                              returns the full hash detail alongside
 *                              the integrity result.
 *
 *   scanChain()              — authenticated (ADMIN or AUDITOR only)
 *                              GET /api/v1/integrity/chain
 *                              Full chain-integrity scan: checks every
 *                              sealed record's self-hash AND the
 *                              prevHash link to its predecessor.
 *
 * All handlers are wrapped by asyncHandler so thrown errors (including
 * ApiError instances from the service layer) are forwarded to the
 * global error middleware automatically.
 * ────────────────────────────────────────────────────────────────
 */

const integrityService      = require('../services/integrity.service');
const transactionRepository = require('../repositories/transaction.repository');
const ApiResponse            = require('../utils/ApiResponse');
const ApiError               = require('../utils/ApiError');
const asyncHandler           = require('../utils/asyncHandler');
const { getRequestMeta }     = require('../utils/requestMeta.util');
const { VERIFICATION_RESULT } = require('../constants/integrity');

// ── HTTP status codes used for each verification outcome ─────────
const STATUS = {
  [VERIFICATION_RESULT.ORIGINAL]:  200,
  [VERIFICATION_RESULT.TAMPERED]:  200, // still a valid response; client checks `result`
  [VERIFICATION_RESULT.NOT_FOUND]: 404,
};

// ────────────────────────────────────────────────────────────────
//  Public endpoint
// ────────────────────────────────────────────────────────────────

/**
 * GET /api/verify/:receipt
 *
 * Public receipt verification — no authentication required.
 * Accepts the receipt number in the URL param (e.g. EXC-2026-000001).
 *
 * Response body (always JSON):
 * {
 *   success:       boolean,
 *   message:       string,          // "Verified" | "Tampered" | "Not Found"
 *   data: {
 *     result:        string,         // "ORIGINAL" | "TAMPERED" | "NOT_FOUND"
 *     label:         string,         // human-readable
 *     receiptNumber: string,
 *     transaction:   object | null,  // safe summary (no hash exposed)
 *     message:       string,         // detail sentence
 *   }
 * }
 */
const verifyByReceipt = asyncHandler(async (req, res) => {
  const receiptNumber = (req.params.receipt ?? '').trim().toUpperCase();

  if (!receiptNumber) {
    throw new ApiError(400, 'Receipt number is required.');
  }

  const meta = getRequestMeta(req);
  const outcome = await integrityService.verifyByReceipt(receiptNumber, {
    verifierIp: meta.ipAddress,
    userAgent:  meta.userAgent,
  });

  const httpStatus = STATUS[outcome.result] ?? 200;

  return new ApiResponse(
    httpStatus,
    outcome.label,         // top-level message: "Verified" | "Tampered" | "Not Found"
    outcome,
  ).send(res);
});

// ────────────────────────────────────────────────────────────────
//  Authenticated endpoints
// ────────────────────────────────────────────────────────────────

/**
 * GET /api/v1/integrity/transaction/:id
 *
 * Verify a specific transaction by its UUID.
 * Requires authentication (any role).
 *
 * Returns the full hash detail (chainIndex, hashVersion, stored hash,
 * recomputed match) alongside the integrity result.
 */
const verifyTransaction = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const txn = await transactionRepository.findByIdWithClient(id);
  if (!txn) throw new ApiError(404, 'Transaction not found.');

  const meta    = getRequestMeta(req);
  const outcome = await integrityService.verifyTransaction(txn, {
    userId:     req.user?.id,
    userAgent:  meta.userAgent,
    verifierIp: meta.ipAddress,
  });

  return new ApiResponse(200, outcome.label, {
    ...outcome,
    transaction: {
      id:            txn.id,
      receiptNumber: txn.receiptNumber,
      txnType:       txn.txnType,
      amountPkr:     txn.amountPkr,
      exchangeRate:  txn.exchangeRate,
      amountUsdt:    txn.amountUsdt,
      clientName:    txn.clientName,
      clientCnic:    txn.clientCnic,
      timestamp:     txn.timestamp,
      chainIndex:    txn.chainIndex,
      prevHash:      txn.prevHash,
      hash:          txn.hash,
      hashVersion:   txn.hashVersion,
    },
  }).send(res);
});

/**
 * GET /api/v1/integrity/chain
 *
 * Full chain-integrity scan (ADMIN / AUDITOR only — enforced by the
 * router via `authorize`).
 *
 * Walks every sealed transaction in chainIndex order and verifies:
 *   (a) self-hash  — the stored hash matches the computed hash
 *   (b) chain link — each record's prevHash equals its predecessor's hash
 *
 * For typical exchange volumes this runs in well under a second.
 * Large deployments should schedule this as a background job instead.
 */
const scanChain = asyncHandler(async (req, res) => {
  const meta   = getRequestMeta(req);
  const result = await integrityService.scanChain({
    userId:    req.user?.id,
    userAgent: meta.userAgent,
  });

  const message = result.chainIntact
    ? `Chain intact — all ${result.totalScanned} records verified.`
    : `Chain broken — ${result.failed} record(s) failed integrity check.`;

  return new ApiResponse(200, message, result).send(res);
});

module.exports = {
  verifyByReceipt,
  verifyTransaction,
  scanChain,
};
