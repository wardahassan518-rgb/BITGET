/**
 * src/controllers/auth.controller.js
 * ────────────────────────────────────────────────────────────────
 * HTTP layer for authentication endpoints.
 * Controllers are intentionally thin: they extract request data,
 * delegate to the auth service, and format the response.
 * Business logic and DB access belong in the service / repositories.
 * ────────────────────────────────────────────────────────────────
 */

const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const ApiError = require('../utils/ApiError');
const authService = require('../services/auth.service');
const { AUTH } = require('../constants/auth');
const config = require('../config/env.config');

// ────────────────────────────────────────────────────────────────
//  Cookie helpers
// ────────────────────────────────────────────────────────────────

/**
 * Returns the `Set-Cookie` options for the refresh-token cookie.
 * `httpOnly` prevents JS access; `sameSite: 'strict'` stops CSRF.
 *
 * @returns {import('express').CookieOptions}
 */
function refreshCookieOptions() {
  return {
    httpOnly: true,
    sameSite: 'strict',
    secure: config.isProduction,
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days in ms
    path: '/',
  };
}

/**
 * Returns options that immediately expire the refresh-token cookie
 * (used on logout).
 *
 * @returns {import('express').CookieOptions}
 */
function clearCookieOptions() {
  return {
    httpOnly: true,
    sameSite: 'strict',
    secure: config.isProduction,
    maxAge: 0,
    path: '/',
  };
}

// ────────────────────────────────────────────────────────────────
//  Request metadata helper
// ────────────────────────────────────────────────────────────────

/**
 * Extract audit-relevant metadata from the incoming request.
 *
 * @param {import('express').Request} req
 * @returns {{ userAgent: string, ipAddress: string }}
 */
function requestMeta(req) {
  return {
    userAgent: req.headers['user-agent'] ?? 'unknown',
    ipAddress: (req.ip ?? req.socket?.remoteAddress ?? 'unknown'),
  };
}

// ────────────────────────────────────────────────────────────────
//  Handlers
// ────────────────────────────────────────────────────────────────

/**
 * POST /auth/login
 *
 * Body (validated by Zod via `validate` middleware):
 *   { email: string, password: string }
 *
 * Response:
 *   200 { accessToken, user }
 *   Sets HttpOnly cookie: dems_refresh_token
 */
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  const { accessToken, refreshToken, user } = await authService.login(
    { email, password },
    requestMeta(req),
  );

  res.cookie(AUTH.REFRESH_COOKIE, refreshToken, refreshCookieOptions());

  return new ApiResponse(200, 'Login successful', { accessToken, user }).send(res);
});

/**
 * POST /auth/logout
 *
 * Requires: valid access token (authenticate middleware).
 * Clears the refresh-token cookie and revokes the DB session.
 */
const logout = asyncHandler(async (req, res) => {
  await authService.logout(req.user.sessionId, req.user.id, requestMeta(req));

  res.clearCookie(AUTH.REFRESH_COOKIE, clearCookieOptions());

  return new ApiResponse(200, 'Logout successful', null).send(res);
});

/**
 * POST /auth/refresh
 *
 * Expects the refresh token either in the `dems_refresh_token` cookie
 * (browser clients) or in the `Authorization: Bearer <token>` header
 * (programmatic / mobile clients that cannot use cookies).
 *
 * Response:
 *   200 { accessToken }
 *   Rotates the HttpOnly refresh-token cookie.
 */
const refresh = asyncHandler(async (req, res) => {
  // Prefer the HttpOnly cookie; fall back to the Authorization header.
  const tokenFromCookie = req.cookies?.[AUTH.REFRESH_COOKIE];
  const authHeader = req.headers.authorization ?? '';
  const tokenFromHeader =
    authHeader.startsWith(`${AUTH.BEARER_SCHEME} `)
      ? authHeader.slice(AUTH.BEARER_SCHEME.length + 1)
      : null;

  const incomingToken = tokenFromCookie || tokenFromHeader;

  if (!incomingToken) {
    throw new ApiError(401, 'Refresh token is required');
  }

  const { accessToken, refreshToken } = await authService.refreshTokens(
    incomingToken,
    requestMeta(req),
  );

  res.cookie(AUTH.REFRESH_COOKIE, refreshToken, refreshCookieOptions());

  return new ApiResponse(200, 'Token refreshed', { accessToken }).send(res);
});

/**
 * GET /auth/me
 *
 * Requires: valid access token (authenticate middleware).
 * Returns the authenticated user's profile.
 */
const me = asyncHandler(async (req, res) => {
  const user = await authService.getCurrentUser(req.user.id);
  return new ApiResponse(200, 'Current user retrieved', { user }).send(res);
});

module.exports = { login, logout, refresh, me };
