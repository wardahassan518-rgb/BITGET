/**
 * src/controllers/dashboard.controller.js
 * ────────────────────────────────────────────────────────────────
 * HTTP layer for Dashboard endpoints (Phase 5).
 *
 * Thin by design: extract validated query params, delegate to the
 * dashboard service, shape the ApiResponse envelope.  No business
 * logic or DB access lives here.
 *
 * Route map (mounted at /api/v1/dashboard):
 *   GET /dashboard/summary              — overall + period stats
 *   GET /dashboard/charts               — time-series chart data
 *   GET /dashboard/recent-transactions  — activity feed (last N txns)
 *   GET /dashboard/recent-audit-logs    — activity feed (last N logs)
 * ────────────────────────────────────────────────────────────────
 */

const asyncHandler  = require('../utils/asyncHandler');
const ApiResponse   = require('../utils/ApiResponse');
const dashboardService = require('../services/dashboard.service');

// ── GET /dashboard/summary ────────────────────────────────────────

/**
 * Returns the full dashboard summary:
 *   • Overall lifetime totals (transactions, PKR/USDT volume, buy/sell split)
 *   • Today's stats + day-over-day comparison vs yesterday
 *   • This month's stats + month-over-month comparison vs last month
 *   • Chain integrity signal (sealed vs unsealed count)
 *
 * @route   GET /api/v1/dashboard/summary
 * @access  Any authenticated role
 */
const getSummary = asyncHandler(async (req, res) => {
  const summary = await dashboardService.getSummary(req.query);
  return new ApiResponse(200, 'Dashboard summary retrieved', summary).send(res);
});

// ── GET /dashboard/charts ─────────────────────────────────────────

/**
 * Returns time-series data for dashboard charts.
 *
 * Query params (all optional):
 *   days        — rolling window in days (default 30, max 365)
 *   from / to   — explicit ISO date range (overrides `days`)
 *   granularity — 'day' (default) | 'month'
 *
 * @route   GET /api/v1/dashboard/charts
 * @access  Any authenticated role
 */
const getCharts = asyncHandler(async (req, res) => {
  const data = await dashboardService.getCharts(req.query);
  return new ApiResponse(200, 'Dashboard chart data retrieved', data).send(res);
});

// ── GET /dashboard/recent-transactions ───────────────────────────

/**
 * Returns the most recent N transactions for the activity feed.
 *
 * Query params (all optional):
 *   limit — number of records (default 10, max 50)
 *
 * @route   GET /api/v1/dashboard/recent-transactions
 * @access  Any authenticated role
 */
const getRecentTransactions = asyncHandler(async (req, res) => {
  const transactions = await dashboardService.getRecentTransactions(req.query);
  return new ApiResponse(200, 'Recent transactions retrieved', { transactions }).send(res);
});

// ── GET /dashboard/recent-audit-logs ─────────────────────────────

/**
 * Returns the most recent N audit log entries for the activity feed.
 *
 * Query params (all optional):
 *   limit — number of records (default 20, max 100)
 *
 * @route   GET /api/v1/dashboard/recent-audit-logs
 * @access  ADMIN | MANAGER | AUDITOR
 */
const getRecentAuditLogs = asyncHandler(async (req, res) => {
  const logs = await dashboardService.getRecentAuditLogs(req.query);
  return new ApiResponse(200, 'Recent audit logs retrieved', { logs }).send(res);
});

module.exports = {
  getSummary,
  getCharts,
  getRecentTransactions,
  getRecentAuditLogs,
};
