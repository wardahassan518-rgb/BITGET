/**
 * src/controllers/verification.controller.js
 * ────────────────────────────────────────────────────────────────
 * HTTP layer for the Phase 6 Verification module.
 *
 * NOTE: The core public verification endpoint
 *   GET /api/verify/:receipt  (result: Verified / Tampered / Not Found)
 * remains in `integrity.controller.js` (Phase 4) and is NOT touched.
 *
 * This controller exposes AUTHENTICATED, ENRICHED endpoints:
 *
 *   verifyEnriched()      — GET /api/v1/verification/:receiptNumber
 *                           Same hash check + full receipt + QR data.
 *
 *   getHistory()          — GET /api/v1/verification/:receiptNumber/history
 *                           All past scan attempts for a receipt.
 *
 *   getLog()              — GET /api/v1/verification/log
 *                           Paginated verification log (ADMIN/AUDITOR).
 *
 *   getStats()            — GET /api/v1/verification/stats
 *                           Aggregate stats over a configurable window.
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const asyncHandler       = require('../utils/asyncHandler');
const ApiResponse        = require('../utils/ApiResponse');
const ApiError           = require('../utils/ApiError');
const requestMeta        = require('../utils/requestMeta.util');
const verificationService = require('../services/verification.service');

// ── HTTP status per verification result ───────────────────────────
const STATUS = {
  ORIGINAL:  200,
  TAMPERED:  200, // valid response; consumer checks `result`
  NOT_FOUND: 404,
};

// ─────────────────────────────────────────────────────────────────

/**
 * GET /api/v1/verification/:receiptNumber
 *
 * Authenticated enriched verification.
 * Returns the same ORIGINAL / TAMPERED / NOT_FOUND result as the
 * public endpoint but adds full receipt details, QR data, and
 * transaction integrity fields.
 */
const verifyEnriched = asyncHandler(async (req, res) => {
  const receiptNumber = (req.params.receiptNumber ?? '').trim().toUpperCase();
  if (!receiptNumber) throw new ApiError(400, 'Receipt number is required.');

  const meta = requestMeta(req);
  const outcome = await verificationService.verifyReceipt(receiptNumber, {
    verifierIp: meta.ipAddress,
    userAgent:  meta.userAgent,
    userId:     req.user?.id,
  });

  const httpStatus = STATUS[outcome.result] ?? 200;
  return new ApiResponse(httpStatus, outcome.label, outcome).send(res);
});

/**
 * GET /api/v1/verification/:receiptNumber/history
 *
 * Return the scan-attempt history log for a specific receipt.
 * `?limit=N` caps at 200 entries.
 */
const getHistory = asyncHandler(async (req, res) => {
  const receiptNumber = (req.params.receiptNumber ?? '').trim().toUpperCase();
  if (!receiptNumber) throw new ApiError(400, 'Receipt number is required.');

  const limit  = Math.min(parseInt(req.query.limit, 10) || 50, 200);
  const result = await verificationService.getVerificationHistory(receiptNumber, { limit });

  return new ApiResponse(200, 'Verification history retrieved', result).send(res);
});

/**
 * GET /api/v1/verification/log
 *
 * Paginated verification log with optional filters:
 *   ?result=ORIGINAL|TAMPERED|NOT_FOUND
 *   ?receiptNumber=EXC-2026-000001
 *   ?from=2026-01-01  ?to=2026-06-30
 *   ?page=1  ?limit=20
 */
const getLog = asyncHandler(async (req, res) => {
  const { logs, meta } = await verificationService.getVerificationLog(req.query);
  return new ApiResponse(200, 'Verification log retrieved', { logs }, meta).send(res);
});

/**
 * GET /api/v1/verification/stats
 *
 * Aggregate stats (counts by result + top verified receipts) over a
 * date window.  Defaults to the last 30 days.
 *   ?from=2026-01-01  ?to=2026-06-30
 */
const getStats = asyncHandler(async (req, res) => {
  const from = req.query.from ? new Date(req.query.from) : undefined;
  const to   = req.query.to   ? new Date(req.query.to)   : undefined;

  const stats = await verificationService.getVerificationStats({ from, to });
  return new ApiResponse(200, 'Verification stats retrieved', stats).send(res);
});

module.exports = {
  verifyEnriched,
  getHistory,
  getLog,
  getStats,
};
