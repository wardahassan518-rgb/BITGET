/**
 * src/routes/client.routes.js
 * ────────────────────────────────────────────────────────────────
 * Client Management endpoints, mounted at /api/v1/clients in
 * routes/index.js. All routes require authentication.
 *
 *   GET    /clients      — list (search/filter/paginate)  [any role]
 *   GET    /clients/:id  — detail                          [any role]
 *   POST   /clients      — create                          [ADMIN, MANAGER, CASHIER]
 *   PUT    /clients/:id  — update                           [ADMIN, MANAGER, CASHIER]
 *   DELETE /clients/:id  — delete                           [ADMIN, MANAGER]
 *
 * Role assignment follows the hierarchy documented in
 * `constants/roles.js`: CASHIER needs to register/edit clients
 * in the course of taking transactions, but deletion is reserved
 * for ADMIN/MANAGER. AUDITOR is read-only everywhere.
 * ────────────────────────────────────────────────────────────────
 */

const express = require('express');

const clientController = require('../controllers/client.controller');
const authenticate = require('../middlewares/authenticate.middleware');
const authorize = require('../middlewares/authorize.middleware');
const validate = require('../middlewares/validate.middleware');

const { idParamSchema } = require('../validators/common.validator');
const {
  createClientSchema,
  updateClientSchema,
  listClientsQuerySchema,
} = require('../validators/client.validator');
const { ROLES } = require('../constants/roles');

const router = express.Router();

router.use(authenticate);

router.get('/', validate(listClientsQuerySchema, 'query'), clientController.listClients);

router.get('/:id', validate(idParamSchema, 'params'), clientController.getClient);

router.post(
  '/',
  authorize(ROLES.ADMIN, ROLES.MANAGER, ROLES.CASHIER),
  validate(createClientSchema),
  clientController.createClient,
);

router.put(
  '/:id',
  authorize(ROLES.ADMIN, ROLES.MANAGER, ROLES.CASHIER),
  validate(idParamSchema, 'params'),
  validate(updateClientSchema),
  clientController.updateClient,
);

router.delete(
  '/:id',
  authorize(ROLES.ADMIN, ROLES.MANAGER),
  validate(idParamSchema, 'params'),
  clientController.deleteClient,
);

module.exports = router;
