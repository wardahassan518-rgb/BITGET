/**
 * src/routes/index.js
 * ────────────────────────────────────────────────────────────────
 * Root router, mounted under `config.apiPrefix` (default /api/v1)
 * in `src/app.js`.
 *
 * Mounted routers:
 *   /health        — Phase 1 (Foundation)
 *   /auth          — Phase 2 (Authentication)
 *   /clients       — Phase 3 (Client Management)
 *   /transactions  — Phase 3 (Transaction Management)
 *   /integrity     — Phase 4 (Integrity Engine — authenticated endpoints)
 *   /dashboard     — Phase 5 (Dashboard & Reports — summary, charts, feeds)
 *   /reports       — Phase 5 (Dashboard & Reports — analytics & exports)
 *   /receipts      — Phase 6 (Receipts, PDFs, QR, Attachments)
 *   /verification  — Phase 6 (Enriched verification & audit log)
 *
 * The PUBLIC verification endpoint `GET /api/verify/:receipt` is mounted
 * directly on the Express app in `src/app.js` (outside this versioned
 * prefix) so it is accessible without auth at the exact URL the spec
 * requires.
 * ────────────────────────────────────────────────────────────────
 */

const express = require('express');
const healthRoutes         = require('./health.routes');
const authRoutes           = require('./auth.routes');
const clientRoutes         = require('./client.routes');
const transactionRoutes    = require('./transaction.routes');
const { integrityRouter }  = require('./integrity.routes');
const dashboardRoutes      = require('./dashboard.routes');   // Phase 5
const reportsRoutes        = require('./reports.routes');     // Phase 5
const receiptRoutes        = require('./receipt.routes');     // Phase 6
const verificationRoutes   = require('./verification.routes');// Phase 6

const router = express.Router();

router.use('/health',       healthRoutes);
router.use('/auth',         authRoutes);             // Phase 2 — Authentication
router.use('/clients',      clientRoutes);            // Phase 3 — Client Management
router.use('/transactions', transactionRoutes);       // Phase 3 — Transaction Management
router.use('/integrity',    integrityRouter);         // Phase 4 — Integrity Engine (auth)
router.use('/dashboard',    dashboardRoutes);         // Phase 5 — Dashboard
router.use('/reports',      reportsRoutes);           // Phase 5 — Reports
router.use('/receipts',     receiptRoutes);           // Phase 6 — Receipts & Attachments
router.use('/verification', verificationRoutes);      // Phase 6 — Verification Audit

module.exports = router;
