/**
 * src/routes/health.routes.js
 * ────────────────────────────────────────────────────────────────
 * GET /health      → liveness probe
 * GET /health/db   → readiness probe (checks Postgres connectivity)
 * ────────────────────────────────────────────────────────────────
 */

const express = require('express');
const { getLiveness, getReadiness } = require('../controllers/health.controller');

const router = express.Router();

router.get('/', getLiveness);
router.get('/db', getReadiness);

module.exports = router;
