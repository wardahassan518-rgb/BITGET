/**
 * src/routes/transaction.routes.js
 * ────────────────────────────────────────────────────────────────
 * Transaction Management endpoints, mounted at /api/v1/transactions
 * in routes/index.js. All routes require authentication.
 *
 *   GET    /transactions      — list (search/filter/paginate)  [any role]
 *   GET    /transactions/:id  — detail                          [any role]
 *   POST   /transactions      — create                          [ADMIN, MANAGER, CASHIER]
 *   PUT    /transactions/:id  — update                           [ADMIN, MANAGER]
 *   DELETE /transactions/:id  — delete                           [ADMIN, MANAGER]
 *
 * CASHIER can create transactions (their primary job) but cannot
 * edit or delete committed ledger entries — that requires MANAGER or
 * ADMIN, matching the "MANAGER approves voids/corrections" intent in
 * `constants/roles.js`. AUDITOR is read-only everywhere.
 * ────────────────────────────────────────────────────────────────
 */

const express = require('express');

const transactionController = require('../controllers/transaction.controller');
const authenticate = require('../middlewares/authenticate.middleware');
const authorize = require('../middlewares/authorize.middleware');
const validate = require('../middlewares/validate.middleware');

const { idParamSchema } = require('../validators/common.validator');
const {
  createTransactionSchema,
  updateTransactionSchema,
  listTransactionsQuerySchema,
} = require('../validators/transaction.validator');
const { ROLES } = require('../constants/roles');

const router = express.Router();

router.use(authenticate);

router.get(
  '/',
  validate(listTransactionsQuerySchema, 'query'),
  transactionController.listTransactions,
);

router.get('/:id', validate(idParamSchema, 'params'), transactionController.getTransaction);

router.post(
  '/',
  authorize(ROLES.ADMIN, ROLES.MANAGER, ROLES.CASHIER),
  validate(createTransactionSchema),
  transactionController.createTransaction,
);

router.put(
  '/:id',
  authorize(ROLES.ADMIN, ROLES.MANAGER),
  validate(idParamSchema, 'params'),
  validate(updateTransactionSchema),
  transactionController.updateTransaction,
);

router.delete(
  '/:id',
  authorize(ROLES.ADMIN, ROLES.MANAGER),
  validate(idParamSchema, 'params'),
  transactionController.deleteTransaction,
);

module.exports = router;
