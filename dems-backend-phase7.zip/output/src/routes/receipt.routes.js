/**
 * src/routes/receipt.routes.js
 * ────────────────────────────────────────────────────────────────
 * Receipt, PDF, QR, and Attachment endpoints (Phase 6).
 *
 * All routes require authentication.  Role guards are applied per
 * route where a restricted subset of users is appropriate.
 *
 * ── Receipt routes ────────────────────────────────────────────────
 *
 *   GET    /receipts                              — paginated list
 *                                                  [ADMIN, MANAGER, AUDITOR]
 *
 *   GET    /receipts/:receiptNumber               — full receipt detail
 *                                                  [any role]
 *
 *   POST   /receipts/ensure/:transactionId        — create/fetch receipt
 *                                                  [ADMIN, MANAGER, CASHIER]
 *
 *   POST   /receipts/:receiptNumber/pdf           — generate PDF
 *                                                  [any role]
 *
 *   GET    /receipts/:receiptNumber/pdf           — download PDF
 *                                                  [any role]
 *
 *   POST   /receipts/:receiptNumber/qr            — generate QR PNG
 *                                                  [any role]
 *
 *   POST   /receipts/:receiptNumber/print         — log print event
 *                                                  [any role]
 *
 *   POST   /receipts/:receiptNumber/share         — log share event
 *                                                  [any role]
 *
 * ── Attachment routes ─────────────────────────────────────────────
 *
 *   POST   /transactions/:txnId/attachments       — upload file
 *                                                  [ADMIN, MANAGER, CASHIER]
 *
 *   GET    /transactions/:txnId/attachments       — list attachments
 *                                                  [any role]
 *
 *   GET    /attachments/:attachmentId             — download file
 *                                                  [any role]
 *
 *   DELETE /attachments/:attachmentId             — delete file
 *                                                  [ADMIN, MANAGER]
 *
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const express  = require('express');

const receiptController = require('../controllers/receipt.controller');
const authenticate      = require('../middlewares/authenticate.middleware');
const authorize         = require('../middlewares/authorize.middleware');
const { upload }        = require('../config/multer.config');
const { ROLES }         = require('../constants/roles');

const router = express.Router();

// All receipt routes require a valid JWT
router.use(authenticate);

// ── Receipt list & detail ─────────────────────────────────────────

router.get(
  '/',
  authorize(ROLES.ADMIN, ROLES.MANAGER, ROLES.AUDITOR),
  receiptController.listReceipts,
);

// NOTE: /ensure/:transactionId must be declared BEFORE /:receiptNumber
// so Express does not swallow "ensure" as a receipt number token.
router.post(
  '/ensure/:transactionId',
  authorize(ROLES.ADMIN, ROLES.MANAGER, ROLES.CASHIER),
  receiptController.ensureReceipt,
);

router.get('/:receiptNumber', receiptController.getReceipt);

// ── PDF ───────────────────────────────────────────────────────────

router.post('/:receiptNumber/pdf',    receiptController.generatePdf);
router.get( '/:receiptNumber/pdf',    receiptController.downloadPdf);

// ── QR ────────────────────────────────────────────────────────────

router.post('/:receiptNumber/qr',     receiptController.generateQr);

// ── Print / Share counters ────────────────────────────────────────

router.post('/:receiptNumber/print',  receiptController.logPrint);
router.post('/:receiptNumber/share',  receiptController.logShare);

// ── Attachment routes (mounted under same router for cohesion) ────
// These are ultimately reachable as:
//   /api/v1/receipts/transactions/:txnId/attachments
//   /api/v1/receipts/attachments/:attachmentId
// The index.js mounts this router at /receipts so the final URLs are:
//   POST   /api/v1/receipts/transactions/:txnId/attachments
//   GET    /api/v1/receipts/transactions/:txnId/attachments
//   GET    /api/v1/receipts/attachments/:attachmentId
//   DELETE /api/v1/receipts/attachments/:attachmentId

router.post(
  '/transactions/:txnId/attachments',
  authorize(ROLES.ADMIN, ROLES.MANAGER, ROLES.CASHIER),
  upload.single('file'),
  receiptController.uploadAttachment,
);

router.get(
  '/transactions/:txnId/attachments',
  receiptController.listAttachments,
);

router.get(
  '/attachments/:attachmentId',
  receiptController.downloadAttachment,
);

router.delete(
  '/attachments/:attachmentId',
  authorize(ROLES.ADMIN, ROLES.MANAGER),
  receiptController.deleteAttachment,
);

module.exports = router;
