/**
 * src/routes/verification.routes.js
 * ────────────────────────────────────────────────────────────────
 * Authenticated Verification endpoints (Phase 6).
 *
 * The core PUBLIC verification endpoint
 *   GET /api/verify/:receipt
 * is handled by `integrity.routes.js` (Phase 4) and is NOT touched.
 *
 * This router is mounted at `/api/v1/verification` and provides
 * authenticated access to enriched verification data and audit logs.
 *
 * Route map:
 *
 *   GET /verification/log               — paginated scan log
 *                                         [ADMIN, AUDITOR]
 *
 *   GET /verification/stats             — aggregate stats window
 *                                         [ADMIN, AUDITOR, MANAGER]
 *
 *   GET /verification/:receiptNumber    — enriched verify result
 *                                         [any role]
 *
 *   GET /verification/:receiptNumber/history
 *                                       — per-receipt scan history
 *                                         [ADMIN, MANAGER, AUDITOR]
 *
 * NOTE: /log and /stats are declared BEFORE /:receiptNumber so
 * Express does not treat the literal strings "log" and "stats" as
 * receipt number captures.
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const express  = require('express');

const verificationController = require('../controllers/verification.controller');
const authenticate           = require('../middlewares/authenticate.middleware');
const authorize              = require('../middlewares/authorize.middleware');
const { ROLES }              = require('../constants/roles');

const router = express.Router();

router.use(authenticate);

// ── Admin / Auditor read-only views ──────────────────────────────

router.get(
  '/log',
  authorize(ROLES.ADMIN, ROLES.AUDITOR),
  verificationController.getLog,
);

router.get(
  '/stats',
  authorize(ROLES.ADMIN, ROLES.AUDITOR, ROLES.MANAGER),
  verificationController.getStats,
);

// ── Per-receipt endpoints ─────────────────────────────────────────

router.get(
  '/:receiptNumber/history',
  authorize(ROLES.ADMIN, ROLES.MANAGER, ROLES.AUDITOR),
  verificationController.getHistory,
);

router.get(
  '/:receiptNumber',
  verificationController.verifyEnriched,
);

module.exports = router;
