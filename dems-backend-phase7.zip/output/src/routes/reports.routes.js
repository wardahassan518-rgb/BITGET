/**
 * src/routes/reports.routes.js
 * ────────────────────────────────────────────────────────────────
 * Reports endpoints, mounted at /api/v1/reports (Phase 5).
 *
 * All routes require authentication.  Access is restricted to roles
 * that have legitimate need for aggregate/historical data:
 *
 *   ADMIN   — full access to all report endpoints
 *   MANAGER — full access to all report endpoints
 *   AUDITOR — full access to all report endpoints (read-only role)
 *   CASHIER — transaction report only (operational need)
 *
 * Route map:
 *   GET /reports/daily          — single-day summary + hourly breakdown
 *   GET /reports/monthly        — single-month summary + daily breakdown
 *   GET /reports/custom         — arbitrary date-range report
 *   GET /reports/clients        — paginated client list + top-N leaders
 *   GET /reports/transactions   — paginated transaction list + totals
 *   GET /reports/audit          — paginated audit log (ADMIN | AUDITOR only)
 *   GET /reports/statistics     — aggregates, rates, busy periods, comparison
 * ────────────────────────────────────────────────────────────────
 */

const express = require('express');

const reportsController = require('../controllers/reports.controller');
const authenticate      = require('../middlewares/authenticate.middleware');
const authorize         = require('../middlewares/authorize.middleware');
const validate          = require('../middlewares/validate.middleware');
const { ROLES }         = require('../constants/roles');

const {
  dailyReportQuerySchema,
  monthlyReportQuerySchema,
  customReportQuerySchema,
  clientReportQuerySchema,
  transactionReportQuerySchema,
  auditReportQuerySchema,
  statisticsQuerySchema,
} = require('../validators/reports.validator');

const router = express.Router();

// All reports routes require a valid JWT
router.use(authenticate);

// Convenience role sets
const REPORTING_ROLES = [ROLES.ADMIN, ROLES.MANAGER, ROLES.AUDITOR];

/**
 * GET /api/v1/reports/daily
 *
 * Single-day summary (totals, buy/sell split) + hourly transaction
 * breakdown for the target calendar day.
 *
 * Query: date (ISO date string; defaults to today)
 *
 * Access: ADMIN | MANAGER | AUDITOR
 */
router.get(
  '/daily',
  authorize(...REPORTING_ROLES),
  validate(dailyReportQuerySchema, 'query'),
  reportsController.getDailyReport,
);

/**
 * GET /api/v1/reports/monthly
 *
 * Single-month summary + per-day breakdown for the target calendar
 * month.
 *
 * Query: year (integer), month (1–12; both default to current month)
 *
 * Access: ADMIN | MANAGER | AUDITOR
 */
router.get(
  '/monthly',
  authorize(...REPORTING_ROLES),
  validate(monthlyReportQuerySchema, 'query'),
  reportsController.getMonthlyReport,
);

/**
 * GET /api/v1/reports/custom
 *
 * Arbitrary date-range report with optional type/client filters and
 * an optional per-day breakdown.
 *
 * Query: from, to, txnType, clientId, breakdown
 *
 * Access: ADMIN | MANAGER | AUDITOR
 */
router.get(
  '/custom',
  authorize(...REPORTING_ROLES),
  validate(customReportQuerySchema, 'query'),
  reportsController.getCustomReport,
);

/**
 * GET /api/v1/reports/clients
 *
 * Paginated client list with search, verification/flag filters,
 * flexible sorting, and an optional top-N leaderboard scoped to a
 * date window.
 *
 * Query: page, limit, search, isVerified, isFlagged, sortBy,
 *        sortOrder, from, to, topN
 *
 * Access: ADMIN | MANAGER | AUDITOR
 */
router.get(
  '/clients',
  authorize(...REPORTING_ROLES),
  validate(clientReportQuerySchema, 'query'),
  reportsController.getClientReport,
);

/**
 * GET /api/v1/reports/transactions
 *
 * Paginated transaction list with rich search/filter and optional
 * aggregate totals (volume, profit, buy/sell split).
 *
 * Query: page, limit, search, txnType, clientId, from, to,
 *        sortBy, sortOrder, includeTotals
 *
 * Access: any authenticated role
 *   CASHIER needs to see their own transactions; other roles need
 *   cross-operator visibility.  Service-level scoping by user role
 *   can be added in a future phase if required.
 */
router.get(
  '/transactions',
  validate(transactionReportQuerySchema, 'query'),
  reportsController.getTransactionReport,
);

/**
 * GET /api/v1/reports/audit
 *
 * Paginated audit log with optional action/user/date filters and
 * full-text search on action + detail fields.
 *
 * Query: page, limit, action, userId, from, to, search, sortOrder
 *
 * Access: ADMIN | AUDITOR (sensitive — restricted from MANAGER and CASHIER)
 */
router.get(
  '/audit',
  authorize(ROLES.ADMIN, ROLES.AUDITOR),
  validate(auditReportQuerySchema, 'query'),
  reportsController.getAuditReport,
);

/**
 * GET /api/v1/reports/statistics
 *
 * Comprehensive statistics for the given date window:
 *   • Aggregate volume & profit
 *   • Buy / sell type split
 *   • Exchange rate min / max / avg (buy & sell)
 *   • Busiest hours and days of the week
 *   • Period-over-period comparison (current vs equivalent prior period)
 *   • Verification log summary
 *   • Audit action frequency breakdown
 *
 * Query: from, to (both optional; default to last 30 days)
 *
 * Access: ADMIN | MANAGER | AUDITOR
 */
router.get(
  '/statistics',
  authorize(...REPORTING_ROLES),
  validate(statisticsQuerySchema, 'query'),
  reportsController.getStatistics,
);

module.exports = router;
