/**
 * src/routes/auth.routes.js
 * ────────────────────────────────────────────────────────────────
 * Authentication endpoints, mounted at /api/v1/auth in routes/index.js.
 *
 *   POST   /auth/login    — authenticate + receive tokens
 *   POST   /auth/logout   — revoke session         [protected]
 *   POST   /auth/refresh  — rotate refresh token
 *   GET    /auth/me       — current user profile   [protected]
 * ────────────────────────────────────────────────────────────────
 */

const express = require('express');
const authController = require('../controllers/auth.controller');
const authenticate = require('../middlewares/authenticate.middleware');
const validate = require('../middlewares/validate.middleware');
const { loginSchema } = require('../validators/auth.validator');

const router = express.Router();

// Public routes ────────────────────────────────────────────────
router.post('/login', validate(loginSchema), authController.login);
router.post('/refresh', authController.refresh);

// Protected routes ─────────────────────────────────────────────
router.post('/logout', authenticate, authController.logout);
router.get('/me', authenticate, authController.me);

module.exports = router;
