/**
 * src/routes/dashboard.routes.js
 * ────────────────────────────────────────────────────────────────
 * Dashboard endpoints, mounted at /api/v1/dashboard (Phase 5).
 *
 * All routes require authentication (JWT).
 * Audit-log feed is restricted to ADMIN, MANAGER, and AUDITOR since
 * CASHIER has no operational need for audit data.
 *
 * Route map:
 *   GET /dashboard/summary             — overall + period stats (any role)
 *   GET /dashboard/charts              — time-series chart data (any role)
 *   GET /dashboard/recent-transactions — last N transactions (any role)
 *   GET /dashboard/recent-audit-logs   — last N audit entries (admin/mgr/auditor)
 * ────────────────────────────────────────────────────────────────
 */

const express = require('express');

const dashboardController = require('../controllers/dashboard.controller');
const authenticate        = require('../middlewares/authenticate.middleware');
const authorize           = require('../middlewares/authorize.middleware');
const validate            = require('../middlewares/validate.middleware');
const { ROLES }           = require('../constants/roles');

const {
  dashboardSummaryQuerySchema,
  dashboardChartsQuerySchema,
  recentTransactionsQuerySchema,
  recentAuditLogsQuerySchema,
} = require('../validators/dashboard.validator');

const router = express.Router();

// All dashboard routes require a valid JWT
router.use(authenticate);

/**
 * GET /api/v1/dashboard/summary
 *
 * Full dashboard summary:
 *   • Lifetime totals (transactions, volume, buy/sell split)
 *   • Today vs yesterday comparison
 *   • This month vs last month comparison
 *   • Chain integrity signal
 *
 * Access: any authenticated role
 */
router.get(
  '/summary',
  validate(dashboardSummaryQuerySchema, 'query'),
  dashboardController.getSummary,
);

/**
 * GET /api/v1/dashboard/charts
 *
 * Time-series data for dashboard charts.
 * Query: days, from, to, granularity
 *
 * Access: any authenticated role
 */
router.get(
  '/charts',
  validate(dashboardChartsQuerySchema, 'query'),
  dashboardController.getCharts,
);

/**
 * GET /api/v1/dashboard/recent-transactions
 *
 * Most recent N transactions for the activity feed.
 * Query: limit (default 10, max 50)
 *
 * Access: any authenticated role
 */
router.get(
  '/recent-transactions',
  validate(recentTransactionsQuerySchema, 'query'),
  dashboardController.getRecentTransactions,
);

/**
 * GET /api/v1/dashboard/recent-audit-logs
 *
 * Most recent N audit log entries for the activity feed.
 * Query: limit (default 20, max 100)
 *
 * Access: ADMIN | MANAGER | AUDITOR (not CASHIER)
 */
router.get(
  '/recent-audit-logs',
  authorize(ROLES.ADMIN, ROLES.MANAGER, ROLES.AUDITOR),
  validate(recentAuditLogsQuerySchema, 'query'),
  dashboardController.getRecentAuditLogs,
);

module.exports = router;
