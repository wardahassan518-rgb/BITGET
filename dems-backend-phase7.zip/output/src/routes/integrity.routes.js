/**
 * src/routes/integrity.routes.js
 * ────────────────────────────────────────────────────────────────
 * Routes for the DEMS Integrity Engine (Phase 4).
 *
 * This router is mounted in TWO places by `src/app.js`:
 *
 *   1.  `/api/verify`
 *       Exports the PUBLIC sub-router (publicIntegrityRoutes) mounted
 *       directly on the Express app outside the versioned API prefix.
 *       This gives the exact URL `GET /api/verify/:receipt` required
 *       by the spec and makes the endpoint accessible to the frontend's
 *       verify.html page without any auth header.
 *
 *   2.  `/api/v1/integrity`
 *       Exports the PRIVATE sub-router (integrityRoutes) registered
 *       inside `src/routes/index.js` under the versioned prefix.
 *       Every route here requires a valid JWT + a permitted role.
 *
 * ────────────────────────────────────────────────────────────────
 * Route map
 * ────────────────────────────────────────────────────────────────
 *
 * PUBLIC (no auth)
 *   GET  /api/verify/:receipt            — verifyByReceipt
 *
 * PRIVATE (auth required)
 *   GET  /api/v1/integrity/transaction/:id — verifyTransaction (any role)
 *   GET  /api/v1/integrity/chain           — scanChain (ADMIN | AUDITOR)
 * ────────────────────────────────────────────────────────────────
 */

const express = require('express');

const integrityController = require('../controllers/integrity.controller');
const authenticate        = require('../middlewares/authenticate.middleware');
const authorize           = require('../middlewares/authorize.middleware');
const { ROLES }           = require('../constants/roles');

// ── Public router ────────────────────────────────────────────────
// Mounted at `/api/verify` in src/app.js.
const publicIntegrityRouter = express.Router();

/**
 * GET /api/verify/:receipt
 *
 * Public receipt verification.  No authentication required.
 * Returns one of:  Verified | Tampered | Not Found
 *
 * :receipt — the receipt number, e.g. EXC-2026-000001
 *            URL-encoding is handled by Express automatically.
 */
publicIntegrityRouter.get('/:receipt', integrityController.verifyByReceipt);

// ── Private router ───────────────────────────────────────────────
// Mounted at `/integrity` inside src/routes/index.js which is itself
// mounted at `config.apiPrefix` (default `/api/v1`).
const integrityRouter = express.Router();

/**
 * GET /api/v1/integrity/transaction/:id
 *
 * Verify the SHA-256 hash of a specific transaction by UUID.
 * Requires a valid JWT (any role).
 */
integrityRouter.get(
  '/transaction/:id',
  authenticate,
  integrityController.verifyTransaction,
);

/**
 * GET /api/v1/integrity/chain
 *
 * Full chain-integrity scan — walks every sealed record and checks
 * both self-hash correctness and the prevHash chain link.
 * Restricted to ADMIN and AUDITOR roles.
 */
integrityRouter.get(
  '/chain',
  authenticate,
  authorize(ROLES.ADMIN, ROLES.AUDITOR),
  integrityController.scanChain,
);

module.exports = {
  publicIntegrityRouter,
  integrityRouter,
};
