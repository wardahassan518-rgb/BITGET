/**
 * prisma/seed.js
 * ────────────────────────────────────────────────────────────────
 * Creates the initial Admin user so the system is usable immediately
 * after the first migration.  Safe to run multiple times — it uses
 * `upsert` so re-running it does not create duplicate rows.
 *
 * Run with:
 *   npm run db:seed
 *   # or
 *   npx prisma db seed
 *
 * Override credentials via environment variables before running:
 *   SEED_ADMIN_EMAIL=admin@example.com \
 *   SEED_ADMIN_PASSWORD=MyStr0ngP@ss \
 *   SEED_ADMIN_NAME="System Administrator" \
 *   npm run db:seed
 *
 * ⚠️  Change the default password immediately after the first login.
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');

const prisma = new PrismaClient();

// ── Seed config (override via env vars) ───────────────────────────
const ADMIN_EMAIL    = (process.env.SEED_ADMIN_EMAIL    ?? 'admin@dems.local').toLowerCase().trim();
const ADMIN_NAME     =  process.env.SEED_ADMIN_NAME     ?? 'System Administrator';
const ADMIN_PASSWORD =  process.env.SEED_ADMIN_PASSWORD ?? 'Admin@123!';
const SALT_ROUNDS    = Number(process.env.BCRYPT_SALT_ROUNDS ?? 12);

// ── Helpers ────────────────────────────────────────────────────────

function banner(msg) {
  // eslint-disable-next-line no-console
  console.log(msg);
}

// ── Main ───────────────────────────────────────────────────────────

async function main() {
  banner('\n🌱  DEMS — Phase 2 seed script');
  banner('─'.repeat(50));

  // ── Admin user ───────────────────────────────────────────────
  banner(`\n📋  Seeding admin user: ${ADMIN_EMAIL}`);

  const passwordHash = await bcrypt.hash(ADMIN_PASSWORD, SALT_ROUNDS);

  const admin = await prisma.user.upsert({
    where: { email: ADMIN_EMAIL },
    update: {
      // Only update non-destructive fields on re-run; leave role/isActive
      // alone so a manually downgraded account isn't silently re-promoted.
      fullName: ADMIN_NAME,
    },
    create: {
      email: ADMIN_EMAIL,
      fullName: ADMIN_NAME,
      passwordHash,
      role: 'ADMIN',
      isActive: true,
    },
    select: { id: true, email: true, role: true, fullName: true, createdAt: true },
  });

  banner(`\n✅  Admin user ready:`);
  banner(`    ID       : ${admin.id}`);
  banner(`    Name     : ${admin.fullName}`);
  banner(`    Email    : ${admin.email}`);
  banner(`    Role     : ${admin.role}`);
  banner(`    Created  : ${admin.createdAt.toISOString()}`);

  const isDefaultPassword = ADMIN_PASSWORD === 'Admin@123!';
  if (isDefaultPassword) {
    banner('\n⚠️   DEFAULT PASSWORD IN USE.');
    banner('    Log in and change it immediately:');
    banner(`    Email    : ${ADMIN_EMAIL}`);
    banner(`    Password : ${ADMIN_PASSWORD}`);
  }

  banner('\n─'.repeat(50));
  banner('🏁  Seed complete.\n');
}

main()
  .catch((err) => {
    // eslint-disable-next-line no-console
    console.error('\n❌  Seed failed:', err.message);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
