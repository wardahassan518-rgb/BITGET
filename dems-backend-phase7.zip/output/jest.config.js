/**
 * jest.config.js
 * ────────────────────────────────────────────────────────────────
 * Jest configuration for the DEMS backend test suite.
 *
 * Three test suites, each with its own naming convention:
 *   tests/unit/**      — Pure function tests, no I/O, no mocking
 *   tests/integration/ — HTTP-layer tests against the Express app
 *                        with Prisma mocked at the module level
 *   tests/api/         — End-to-end API contract tests (also Prisma-
 *                        mocked; named `*.api.test.js` for clarity)
 * ────────────────────────────────────────────────────────────────
 */

'use strict';

/** @type {import('jest').Config} */
const config = {
  // ── Environment ────────────────────────────────────────────────
  testEnvironment: 'node',

  // ── Setup: load .env.test BEFORE any module is required ────────
  // `setupFiles` runs in the test worker VM before the test framework
  // is installed and before any test file's `require()` calls fire.
  // This means env.config.js picks up DATABASE_URL / JWT_SECRET /
  // CHAIN_SALT etc. from .env.test instead of calling process.exit(1).
  setupFiles: ['./tests/setup/env.js'],

  // ── Test discovery ─────────────────────────────────────────────
  testMatch: [
    '<rootDir>/tests/unit/**/*.test.js',
    '<rootDir>/tests/integration/**/*.test.js',
    '<rootDir>/tests/api/**/*.test.js',
  ],

  // ── Coverage ───────────────────────────────────────────────────
  collectCoverageFrom: [
    'src/utils/**/*.js',
    'src/config/**/*.js',
    'src/middlewares/**/*.js',
    'src/controllers/**/*.js',
    '!src/**/*.spec.js',
  ],
  coverageDirectory: 'coverage',
  coverageReporters: ['text', 'lcov', 'html'],
  coverageThreshold: {
    global: {
      branches: 60,
      functions: 65,
      lines: 65,
      statements: 65,
    },
  },

  // ── Timing ─────────────────────────────────────────────────────
  testTimeout: 15_000,

  // ── Output ─────────────────────────────────────────────────────
  verbose: true,

  // ── Performance ────────────────────────────────────────────────
  // Run test files in band (sequentially) to avoid port conflicts
  // when multiple supertest servers start on the same PORT env var.
  runInBand: false,
  maxWorkers: '50%',
};

module.exports = config;
